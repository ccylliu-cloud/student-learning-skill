"""Synthetic-only integration; no model invocation or personal archive access."""
import argparse, copy, json, sys, tempfile, unittest, uuid
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode = True
import os
PACKAGE = Path(os.environ['STUDENT_LEARNING_TEST_PACKAGE'])
sys.path[:0] = [str(PACKAGE/'scripts')]
from PIL import Image
import study, pc_store as s, portable_conversation as p, vision_guard as v, codex_bridge as cb
study.SKILL = PACKAGE

class ConversationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='conversation-test-', dir=Path(__file__).parent)
        self.work = Path(self.tmp.name).resolve()
        self.root,self.db = study.connect(self.work/'archive')
        (self.root/'assets').mkdir()
        Image.new('RGB',(1000,1000),'white').save(self.root/'assets/p.png')
        self.g = {'id':'g','kind':'original','title':'Synthetic test','subject':'英语','grade':4,'date':'2026-10-09', 'pageIds':['p'],'questions':[],'recognized':False,'requested':False}
        s.put_meta(self.db,'pc_recognition',{'pages':[{'id':'p','url':'/files/p.png','date':'2026-10-09'}],'groups':[self.g]});self.db.commit()
        self.config = patch.object(p.config,'read_config',return_value={'workspace':str(self.work)})
        self.config.start()
        self.hostpatch=patch.object(p.config,'host',return_value='workbuddy');self.hostpatch.start()
        self.no_model = patch('subprocess.Popen',side_effect=AssertionError('Model subprocess forbidden'))
        self.no_model.start()
    def tearDown(self):
        self.hostpatch.stop();self.no_model.stop();self.config.stop();self.db.close();self.tmp.cleanup()
    def exp(self,mode='original',**kw):
        a=dict(cmd='conversation-export',group_id='g',out=str(self.work/uuid.uuid4().hex),retry_vision=False,mode=mode,consent=False,page_id=None,box=None);a.update(kw)
        return p.dispatch(self.root,self.db,argparse.Namespace(**a))
    def report(self,n=1):
        return {'status':'readable','pages':[{'page':i,'status':'readable','observation':'Synthetic visible item '+str(i)} for i in range(1,n+1)]}
    def vision(self,task,report=None):
        path=self.work/'vision.json';path.write_text(json.dumps(report or self.report(len(task['images']))),encoding='utf-8')
        return p.dispatch(self.root,self.db,argparse.Namespace(cmd='conversation-vision',manifest=task['manifest'],report=str(path)))
    def submit(self,task,data,cmd='conversation-submit'):
        if isinstance(data,dict):
            data=copy.deepcopy(data);data['vision']=self.report(len(task['images']))
            if data.get('protocol')=='student-scan-v3':data['paper']['scanned_pages']=list(range(1,len(task['images'])+1))
        path=self.work/'result.json';path.write_text(data if isinstance(data,str) else json.dumps(data),encoding='utf-8')
        return p.dispatch(self.root,self.db,argparse.Namespace(cmd=cmd,manifest=task['manifest'],result=str(path)))
    def retry(self,task):
        return p.dispatch(self.root,self.db,argparse.Namespace(cmd='conversation-retry',manifest=task['manifest'],result=None))
    def with_vision(self,task,data):return data
    def detect(self,status='marked',count=1):
        return {'protocol':'student-marks-v2','coordinate_space':'percent_0_100','vision':self.report(),'status':status,'candidates':[{'page':1,'number':str(i+1),'box':{'x':10,'y':i*3,'width':60,'height':20},'certainty':'wrong','evidence':'Synthetic teacher cross','context_boxes':[]} for i in range(count)]}
    def compact(self,n=1,full=False,start=1):
        return {'protocol':'student-scan-v3','vision':self.report(n), 'paper':{'assessment_mode':'teacher_marks','coverage':'full' if full else 'partial','expected_question_count':n if full else None,'scanned_pages':list(range(1,n+1))},'questions':[{'page':i,'number':str(start+i-1),'text':'Synthetic question '+str(start+i-1),'student_answer':'B','expected_answer':'A','explanation':'Synthetic explanation','verdict':'wrong','evidence':'Synthetic teacher evidence','basis':'teacher_mark','evidence_level':'A','knowledgeIds':[],'answerEvidence':{'printed_text':'Synthetic question '+str(start+i-1),'initial_steps':['B'],'correction_steps':[],'completeness':'complete','transcription_status':'clear','uncertain_tokens':[],'first_error':{'step':1,'kind':'unknown','detail':'Synthetic answer evidence differs'}},'knowledgeValidation':{'status':'insufficient','reason':'Synthetic task has no applicable verified knowledge','reviewed':[]},'observed_error':'Initial answer B differs from expected A','attributions':[{'knowledge_point_id':None,'error_cause_id':None,'status':'pending','evidence':'Visible answer B; synthetic evidence does not establish the cause'}]} for i in range(1,n+1)]}
    def group(self):return s.meta(self.db,'pc_recognition',{})['groups'][0]
    def initial(self,count=1):
        task=self.exp();self.vision(task);r=self.submit(task,self.detect(count=count))
        if count:
            child=r['tasks'][0];self.vision(child);self.submit(child,self.with_vision(child,self.compact(count)))
        return task
    def test_new_wrong_without_error_analysis_is_rejected(self):
        task=self.exp();self.vision(task);child=self.submit(task,self.detect())['tasks'][0];self.vision(child)
        bad=self.compact();bad['questions'][0].pop('observed_error');bad['questions'][0]['attributions']=[]
        with self.assertRaises(ValueError):self.submit(child,bad)
        self.assertNotIn('g',s.meta(self.db,'pc_drafts',{}))
        fixed=self.compact();self.submit(child,fixed,'conversation-retry')
        self.assertEqual(len(s.meta(self.db,'pc_drafts',{})['g']['questions']),1)
    def test_correct_with_error_attribution_is_rejected(self):
        self.initial(count=0);task=self.exp('report',consent=True);self.vision(task)
        bad=self.compact(full=True);bad['questions'][0]['verdict']='correct'
        with self.assertRaises(ValueError):self.submit(task,bad)
        fixed=copy.deepcopy(bad);fixed['questions'][0].update(observed_error='',attributions=[]);fixed['questions'][0]['answerEvidence']['first_error']=None
        self.submit(task,fixed,'conversation-retry')
        self.assertEqual(self.group()['reportTask']['status'],'completed')
    def test_selective_crops_and_pending(self):
        task=self.exp();self.assertIn('只定位',Path(task['prompt']).read_text());self.vision(task)
        next=self.submit(task,self.detect());self.assertFalse(self.group()['recognized'])
        child=next['tasks'][0]
        with Image.open(child['images'][0]) as img:self.assertEqual(img.size,(640,220))
        self.vision(child);r=self.submit(child,self.with_vision(child,self.compact()));self.assertEqual(r['autoConfirmed'],False)
        draft=s.meta(self.db,'pc_drafts',{})['g'];self.assertEqual(draft['paper']['recognition_scope'],'mistakes');self.assertEqual(draft['questions'][0]['box']['x'],10);self.assertEqual(draft['questions'][0]['decision_status'],'pending')
    def test_unmarked_no_full_without_consent(self):
        task=self.exp();self.vision(task);r=self.submit(task,self.detect('unmarked',0))
        self.assertEqual(self.group()['questions'],[]);self.assertIn('询问用户',r['next'])
        with self.assertRaisesRegex(ValueError,'同意'):self.exp('report')
        self.assertNotIn('reportTask',self.group())
    def test_save_retry_after_timeout_zero_view(self):
        task=self.exp();self.vision(task);child=self.submit(task,self.detect())['tasks'][0];self.vision(child)
        with patch.object(s,'put_results',side_effect=ValueError('synthetic save failure')):
            with self.assertRaisesRegex(ValueError,'synthetic'):self.submit(child,self.with_vision(child,self.compact()))
        self.assertTrue(self.group()['resultRecovery']['available'])
        with patch.object(v,'load',side_effect=AssertionError('Must not re-open expired vision session')),patch.object(p,'_images',side_effect=AssertionError('Must not re-view crop')):
            self.retry(child)
        self.assertTrue(self.group()['recognized'])
    def test_malformed_response_can_repair_locally(self):
        task=self.exp();self.vision(task)
        with self.assertRaises(ValueError):self.submit(task,'{broken json')
        r=self.submit(task,self.detect('unmarked',0),'conversation-retry');self.assertEqual(r['questions'],0)
    def test_source_change_blocks_saved_retry(self):
        task=self.exp();self.vision(task)
        with patch.object(s,'put_results',side_effect=ValueError('save')):
            with self.assertRaises(ValueError):self.submit(task,self.detect('unmarked',0))
        Image.new('RGB',(1000,1000),'blue').save(self.root/'assets/p.png')
        with self.assertRaisesRegex(ValueError,'变更'):self.retry(task)
    def test_report_and_supplement_preserve_manual(self):
        self.initial();draft=s.meta(self.db,'pc_drafts',{})['g'];draft['questions'][0]['text']='Manual corrected wording';s.put_meta(self.db,'pc_drafts',{'g':draft});self.db.commit();before=copy.deepcopy(draft['questions'][0])
        report=self.exp('report',consent=True);self.vision(report);self.submit(report,self.compact(full=True))
        self.assertEqual(s.meta(self.db,'pc_drafts',{})['g']['questions'][0],before)
        self.assertEqual(self.group()['reportTask']['status'],'completed')
        import supplement_recognition as sr
        task=sr.queue_task(self.root,self.db,{'groupId':'g','pageId':'p','box':{'x':10,'y':50,'width':60,'height':20},'requestId':str(uuid.uuid4())},s.revision(self.db))
        cb.Runner(self.root).submit_supplement('g',task['id'])
        supplement=self.exp('supplement');self.vision(supplement);self.submit(supplement,self.compact(start=99))
        self.assertEqual(self.group()['supplementTask']['status'],'completed');self.assertEqual(s.meta(self.db,'pc_drafts',{})['g']['questions'][0],before)
    def test_no_vision_blocks_and_no_reread(self):
        task=self.exp()
        with self.assertRaisesRegex(ValueError,'先实际看图'):self.submit(task,self.detect())
        bad={'status':'image_blocked','error':'cannot view images'}
        with self.assertRaises(ValueError):self.vision(task,bad)
        with self.assertRaises(ValueError):self.exp()
        self.assertFalse(self.group()['recognized']);self.assertEqual(self.group()['runStatus'],'failed')
    def test_manifest_tamper_and_image_tamper(self):
        task=self.exp();m=Path(task['manifest']);data=json.loads(m.read_text());data['mode']='report';m.write_text(json.dumps(data))
        with self.assertRaisesRegex(ValueError,'清单'):self.vision(task)
    def test_guard_all_native_boundaries(self):
        runner=cb.Runner(self.root)
        for fn,args in [(cb.command,('w','o',[])),(cb.executable,()),(runner.run,('g',)),(runner._execute,())]:
            with self.assertRaisesRegex(ValueError,'WorkBuddy'):fn(*args)
        self.assertTrue(runner.submit('g'));self.assertEqual(self.group()['runStatus'],'awaiting_conversation');runner.close()
    def test_multibatch_only_once(self):
        task=self.exp();self.vision(task);tasks=self.submit(task,self.detect(count=5))['tasks'];self.assertEqual(len(tasks),2)
        self.vision(tasks[0]);self.submit(tasks[0],self.compact(4));self.assertFalse(self.group()['recognized'])
        self.vision(tasks[1]);self.submit(tasks[1],self.compact(1,start=5));self.assertEqual(len(s.meta(self.db,'pc_drafts',{})['g']['questions']),5)
    def test_expired_stage_renew_is_explicit_and_keeps_prior_work(self):
        task=self.exp();self.vision(task);child=self.submit(task,self.detect())['tasks'][0]
        job,stage=p._load(self.root,child['manifest']);old=stage['manifest']['sessionId']
        with self.assertRaisesRegex(ValueError,'确认'):
            p.dispatch(self.root,self.db,argparse.Namespace(cmd='conversation-renew',manifest=child['manifest'],retry_vision=False))
        new=p.dispatch(self.root,self.db,argparse.Namespace(cmd='conversation-renew',manifest=child['manifest'],retry_vision=True))
        self.assertNotEqual(old,json.loads(Path(new['manifest']).read_text())['sessionId'])
        self.vision(new);self.submit(new,self.compact());self.assertTrue(self.group()['recognized'])
    def test_report_save_failure_local_retry(self):
        self.initial(count=0);task=self.exp('report',consent=True);self.vision(task)
        import report_recognition as rr
        with patch.object(rr,'save_report',side_effect=ValueError('Synthetic report save failure')):
            with self.assertRaises(ValueError):self.submit(task,self.compact(full=True))
        self.assertEqual(self.group()['reportTask']['status'],'failed')
        with patch.object(v,'load',side_effect=AssertionError('no new vision')):self.retry(task)
        self.assertEqual(self.group()['reportTask']['status'],'completed')
    def test_supplement_save_failure_local_retry(self):
        self.initial(count=0);task=self.exp('supplement',page_id='p',box=json.dumps({'x':10,'y':10,'width':60,'height':20}));self.vision(task)
        import supplement_recognition as sr
        with patch.object(sr,'save_question',side_effect=ValueError('Synthetic supplement save failure')):
            with self.assertRaises(ValueError):self.submit(task,self.compact())
        self.assertEqual(self.group()['supplementTask']['status'],'failed')
        with patch.object(v,'load',side_effect=AssertionError('no new vision')):self.retry(task)
        self.assertEqual(self.group()['supplementTask']['status'],'completed')
    def test_recover_stops_all_background_states(self):
        rec=s.meta(self.db,'pc_recognition',{});group=rec['groups'][0]
        group.update(requested=True,runStatus='running',reportTask={'id':'r','status':'running','progress':{}},supplementTask={'id':'s','status':'queued','progress':{}})
        s.put_meta(self.db,'pc_recognition',rec);self.db.commit()
        runner=cb.Runner(self.root);runner.recover();runner.close();g=self.group()
        self.assertFalse(g['requested']);self.assertEqual(g['runStatus'],'awaiting_conversation');self.assertEqual(g['reportTask']['status'],'awaiting_conversation');self.assertEqual(g['supplementTask']['status'],'awaiting_conversation')
    def test_changed_exported_image_rejected(self):
        task=self.exp();Path(task['images'][0]).write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError,'图片已变更'):self.vision(task)
    def test_http_report_and_supplement_keep_conversation_guidance(self):
        import threading, urllib.request
        from pc_server import make_server
        self.initial(count=0)
        server=make_server(self.root,0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        url='http://127.0.0.1:'+str(server.server_port)
        try:
            for kind,payload in [('report',{'consent':True}),('supplement',{'pageId':'p','box':{'x':10,'y':20,'width':60,'height':20}})]:
                state=json.load(urllib.request.urlopen(url+'/api/archive'))
                body={'groupId':'g','requestId':str(uuid.uuid4()),**payload}
                request=urllib.request.Request(url+'/api/recognition/'+kind,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','Origin':url,'X-Pc-Token':state['token'],'If-Match':state['revision']})
                response=urllib.request.urlopen(request);self.assertEqual(response.status,202);value=json.load(response)
                task=value['archive']['recognition']['groups'][0][kind+'Task']
                self.assertEqual(task['status'],'awaiting_conversation');self.assertIn('对话',task['progress']['message']);self.assertFalse(task.get('error'))
                self.assertEqual(server.runner.active,{})
        finally:server.shutdown();server.runner.close();server.server_close();thread.join(timeout=2)
    def test_practice_recognition_roundtrip_preserves_original(self):
        self.initial()
        rec=s.meta(self.db,'pc_recognition',{});rec['pages'][0].update(subject='英语',label='Synthetic page');s.put_meta(self.db,'pc_recognition',rec);self.db.commit()
        env=s.read_archive(self.root,self.db);scan=env['archive']['recognition']['groups'][0]['questions'][0]
        scan.update(verdict='wrong',decisionStatus='confirmed',status='saved')
        saved=s.apply_archive(self.root,self.db,env['archive'],env['revision'])
        canonical=saved['archive']['questions'][0]['id']
        original=self.db.execute('select payload from questions where id=?',(canonical,)).fetchone()[0]
        practice={'id':'p1','title':'Synthetic practice','subject':'英语','date':'2026-10-23','grade':4,'questionIds':[canonical],'status':'已生成','sources':[]}
        s.put_meta(self.db,'pc_practice',{'p1':practice});self.db.commit()
        import pc_practice
        staged=pc_practice.stage_practice_pages(self.root,self.db,[str(self.root/'assets/p.png')],'p1','2026-10-23')
        gid=staged['practiceRecognitionId']
        task=p.dispatch(self.root,self.db,argparse.Namespace(cmd='conversation-export',group_id=gid,out=str(self.work/uuid.uuid4().hex),retry_vision=False,mode='original',consent=False,page_id=None,box=None))
        self.vision(task)
        data={'protocol':'student-scan-v3','vision':self.report(),'paper':{'assessment_mode':'teacher_marks','coverage':'full','expected_question_count':1,'scanned_pages':[1]},'questions':[{'question_id':canonical,'page':1,'student_answer':'A','corrected_answer':None,'verdict':'correct','evidence':'Synthetic correct independent answer A','basis':'teacher_mark','evidence_level':'A','independent':True,'knowledge_point_ids':[]}]}
        self.submit(task,data)
        g=next(g for g in s.meta(self.db,'pc_recognition',{})['groups'] if g['id']==gid)
        self.assertTrue(g['recognized']);self.assertEqual(g['runStatus'],'completed')
        self.assertEqual(original,self.db.execute('select payload from questions where id=?',(canonical,)).fetchone()[0])
    def test_pending_supplement_not_overwritten(self):
        self.initial(count=0)
        import supplement_recognition as sr
        first=sr.queue_task(self.root,self.db,{'groupId':'g','pageId':'p','box':{'x':10,'y':20,'width':60,'height':20},'requestId':str(uuid.uuid4())},s.revision(self.db))
        cb.Runner(self.root).submit_supplement('g',first['id'])
        with self.assertRaisesRegex(ValueError,'上一道圈选'):
            sr.queue_task(self.root,self.db,{'groupId':'g','pageId':'p','box':{'x':20,'y':40,'width':60,'height':20},'requestId':str(uuid.uuid4())},s.revision(self.db))
        self.assertEqual(self.group()['supplementTask']['id'],first['id'])
        task=self.exp('supplement');self.vision(task);self.submit(task,self.compact());self.assertEqual(self.group()['supplementTask']['status'],'completed')
    def test_existing_results_cannot_be_replaced(self):
        task=self.initial();before=s.meta(self.db,'pc_drafts',{})
        self.assertEqual(self.retry(task)['status'],'already_saved')
        self.assertEqual(before,s.meta(self.db,'pc_drafts',{}))
        with self.assertRaisesRegex(ValueError,'已有识别'):self.exp()

if __name__=='__main__':unittest.main(verbosity=2)
