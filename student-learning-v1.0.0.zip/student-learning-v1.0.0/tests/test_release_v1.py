import os,sys,json,copy,tempfile,unittest,hashlib,threading,urllib.request,re
from pathlib import Path
sys.dont_write_bytecode=True
SKILL=Path(os.environ['STUDENT_LEARNING_TEST_PACKAGE']);sys.path.insert(0,str(SKILL/'scripts'))
from PIL import Image
import study,pc_store as s,evidence_contract as ec,selective_recognition as sel
from kb_lookup import details
class ReleaseTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.root,cls.db=study.connect(Path(cls.tmp.name)/'archive');cls.counts=study.init_kb(cls.db)
 @classmethod
 def tearDownClass(cls):cls.db.close();cls.tmp.cleanup()
 def q(self):
  return {'text':'A printed exercise','student_answer':'4625\n4626+325=4951','corrected_answer':'4625+325=4950','verdict':'wrong','evidence':'Synthetic observed digits','attributions':[{'status':'provisional'}],'knowledgeIds':[],'answerEvidence':{'printed_text':'A printed exercise','initial_steps':['4625','4626+325=4951'],'correction_steps':['4625+325=4950'],'completeness':'complete','transcription_status':'clear','uncertain_tokens':[],'first_error':{'step':2,'kind':'transcription','detail':'Reused number changed from 4625 to 4626'}},'knowledgeValidation':{'status':'insufficient','reason':'This is a synthetic transcription-only case','reviewed':[]}}
 def test_packaged_workflow_references_resolve(self):
  for page in SKILL.rglob('*.md'):
   for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',page.read_text(encoding='utf-8')):
    target=target.split('#')[0]
    if target and ':' not in target:self.assertTrue((page.parent/target).is_file(),str(page.relative_to(SKILL))+' -> '+target)
 def test_three_subject_counts(self):self.assertEqual(self.counts,{'math':1211,'english':355,'chinese':84})
 def test_three_subject_semantics(self):
  for subject,kid in [('math','MATH-K000026'),('english','EG-KP-000274'),('chinese','CHN-KP-001')]:
   if subject=='chinese':kid=self.db.execute("select id from knowledge where subject='chinese' order by id limit 1").fetchone()[0]
   card=details(self.db,subject,[kid])[0];self.assertEqual(card['id'],kid);self.assertTrue(any(len(v)>=8 for v in ec.semantic_strings(card)))
 def test_precise_initial_and_correction_survive(self):
  q=self.q();ec.validate(self.db,q,'math');self.assertIn('4626',q['student_answer']);self.assertIn('4950',q['corrected_answer']);self.assertEqual(q['causeStatus'],'pending')
 def test_modified_answer_not_silently_repaired(self):
  q=self.q();q['student_answer']=q['student_answer'].replace('4626','4625')
  with self.assertRaisesRegex(ValueError,'逐步证据'):ec.validate(self.db,q,'math')
 def test_printed_relation_preserved(self):
  q=self.q();q['text']='一个数除以98';q['answerEvidence']['printed_text']='一个数除98'
  with self.assertRaisesRegex(ValueError,'印刷题干'):ec.validate(self.db,q,'math')
 def test_incomplete_cannot_assert_wrong(self):
  q=self.q();q['answerEvidence']['completeness']='cropped';q['answerEvidence']['uncertain_tokens']=['missing final line']
  with self.assertRaisesRegex(ValueError,'不完整'):ec.validate(self.db,q,'math')
 def test_uncertain_can_save_pending(self):
  q=self.q();q['verdict']='pending';q['answerEvidence'].update(completeness='cropped',uncertain_tokens=['missing line']);ec.validate(self.db,q,'math')
 def test_first_error_requires_observed_step(self):
  q=self.q();q['answerEvidence']['first_error']['step']=99
  with self.assertRaisesRegex(ValueError,'首错'):ec.validate(self.db,q,'math')
 def test_fake_knowledge_quote_rejected(self):
  q=self.q();q['knowledgeIds']=['MATH-K000026'];q['knowledgeValidation']={'status':'matched','reason':'Synthetic selection test','reviewed':[{'id':'MATH-K000026','quote':'invented rule that never existed'}]}
  with self.assertRaisesRegex(ValueError,'知识引文'):ec.validate(self.db,q,'math')
 def test_provenance_metadata_cannot_stand_in_for_rule(self):
  for quote in ('依据来源重写，非教材逐字原句','S0615496bef:11','MATH-K000026-S001'):
   q=self.q();q['knowledgeIds']=['MATH-K000026'];q['knowledgeValidation']={'status':'matched','reason':'Synthetic metadata rejection','reviewed':[{'id':'MATH-K000026','quote':quote}]}
   with self.assertRaisesRegex(ValueError,'知识引文'):ec.validate(self.db,q,'math')
 def test_real_knowledge_quote_binds_each_subject(self):
  for subject in ('math','english','chinese'):
   kid=self.db.execute('select id from knowledge where subject=? order by id limit 1',(subject,)).fetchone()[0]
   card=details(self.db,subject,[kid])[0];quote=next(v for v in ec.semantic_strings(card) if len(v)>=8)
   q=self.q();q['knowledgeIds']=[kid];q['knowledgeValidation']={'status':'matched','reason':'Synthetic source-quote validation','reviewed':[{'id':kid,'quote':quote}]};ec.validate(self.db,q,subject);self.assertIn(kid,q['knowledgeValidation']['versions'])
 def test_no_match_without_lookup_cannot_claim_complete(self):
  q=self.q();q['knowledgeValidation']['status']='no_match'
  with self.assertRaisesRegex(ValueError,'实际核对'):ec.validate(self.db,q,'math')
 def test_wrong_missing_evidence_rejected_at_direct_import_boundary(self):
  with self.assertRaisesRegex(ValueError,'answerEvidence'):study.validate_question(self.db,{},'math',machine_import=True)
 def detect(self,boxes):
  return json.dumps({'protocol':'student-marks-v2','coordinate_space':'percent_0_100','vision':{'status':'readable','pages':[{'page':1,'status':'readable','observation':'Synthetic visible text and teacher marking'}]},'status':'marked','candidates':[{'page':1,'number':str(i),'box':b,'certainty':'suspected','evidence':'Synthetic uncertain marking','context_boxes':[]} for i,b in enumerate(boxes)]})
 def test_pixel_like_box_never_scaled_as_percent(self):
  raw=self.detect([{'x':410,'y':505,'width':190,'height':65}])
  with self.assertRaisesRegex(ValueError,'所有候选'):sel._detection(raw,1)
 def test_invalid_box_does_not_drop_valid_candidate(self):
  d,_,_=sel._detection(self.detect([{'x':410,'y':505,'width':190,'height':65},{'x':10,'y':10,'width':30,'height':20}]),1);self.assertEqual(len(d['candidates']),1);self.assertEqual(len(d['rejected_candidates']),1)
 def test_crops_have_margin_and_original_context(self):
  p=Path(self.tmp.name)/'page.png';Image.new('RGB',(1000,2000),'white').save(p)
  c={'page':1,'box':{'x':10,'y':10,'width':20,'height':20},'context_boxes':[],'local_id':'m'}
  paths,mapping=sel._crops(Path(self.tmp.name),[c],[str(p)]);self.assertEqual(len(paths),2);self.assertEqual(mapping[0]['page_context_image'],2)
  with Image.open(paths[0]) as im:self.assertEqual(im.size,(240,480))
 def test_small_source_quality_warning(self):
  from image_import import prepare
  p=Path(self.tmp.name)/'small.jpg';Image.new('RGB',(900,1200),'white').save(p);value=prepare(self.root,p);self.assertTrue(value['qualityWarnings']);self.assertFalse(value['resampledBySkill'])
 def test_readonly_lookup_never_initializes_missing_root(self):
  import subprocess
  p=Path(self.tmp.name)/'never-created';r=subprocess.run([sys.executable,str(SKILL/'scripts/kb_lookup.py'),'--root',str(p),'--subject','math','--ids','MATH-K000026'],capture_output=True);self.assertNotEqual(r.returncode,0);self.assertFalse(p.exists())
 def test_native_request_explicit_model_and_effort(self):
  import codex_bridge_native as n
  from unittest.mock import patch
  with patch.object(n,'executable',return_value='/synthetic/codex'):
   cmd=n.command('/work','/output',['/image'])
  self.assertEqual(cmd[cmd.index('--model')+1],'gpt-6-astra');self.assertIn('model_reasoning_effort="medium"',cmd);self.assertEqual(cmd[-2:],['--','-'])
 def test_unreviewed_diagram_blocks_print(self):
  from pc_word import check_questions
  asset=self.root/'assets'/'synthetic-diagram.png';asset.parent.mkdir(exist_ok=True);Image.new('RGB',(500,300),'white').save(asset)
  q={'number':'diagram','text':'Synthetic geometry','subject':'math','requires_image':True,'diagramReviewRequired':True,'content':{'version':1,'blocks':[{'type':'paragraph','runs':[{'text':'Synthetic geometry'}]},{'type':'image','asset':{'url':'/files/synthetic-diagram.png','label':'Synthetic reconstruction'}}]},'answerLayout':{'kind':'space','heightCm':4}}
  issues=check_questions(self.root,[q],'practice');self.assertTrue(issues);self.assertIn('核对',str(issues))
  q['diagramReviewRequired']=False;self.assertEqual(check_questions(self.root,[q],'practice'),[])
 def test_local_geometry_repair_preserves_original(self):
  import stage_repair
  folder=self.root/'drafts'/'selective-synthetic'/'stage-detect';folder.mkdir(parents=True,exist_ok=True)
  original=folder/'result.json';original.write_text(self.detect([{'x':410,'y':505,'width':190,'height':65}]))
  digest=hashlib.sha256(original.read_bytes()).hexdigest();(folder/'ready.json').write_text(json.dumps({'key':'synthetic-key','sha256':digest}))
  repaired=Path(self.tmp.name)/'repaired.json';repaired.write_text(self.detect([{'x':10,'y':20,'width':30,'height':40}]))
  result=stage_repair.repair_detection(self.root,folder,repaired);self.assertTrue(result['original_unchanged']);self.assertEqual(hashlib.sha256(original.read_bytes()).hexdigest(),digest)
  cached=sel._find_stage(self.root,'synthetic-key');self.assertIsNotNone(cached);self.assertIn('geometry-repair-',cached[0].name)
 def test_http_runtime_is_loopback_readonly(self):
  import pc_server
  server=pc_server.make_server(self.root,0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   data=json.load(urllib.request.urlopen('http://127.0.0.1:'+str(server.server_port)+'/api/runtime'));self.assertEqual(data['version'],'1.0.0');self.assertEqual(data['knowledge']['total'],1650)
  finally:server.shutdown();server.runner.close();server.server_close();thread.join()
if __name__=='__main__':unittest.main()
