# 学习记录册 Skill 1.0.0

面向单个学生的本地学习档案：原卷错题候选、逐步作答证据、三科知识点、人工复核、干净题面、组卷与复练、Word打印、历史与备份。学生档案留在本地；模型由宿主账号提供。

## 安装

解压后在本目录运行。Codex：`python install.py --host codex --target "新Skill绝对目录"`。WorkBuddy：`python install.py --host workbuddy --workspace "项目绝对目录" --target "项目绝对目录/.workbuddy/skills/student-learning"`。现有目录拒绝覆盖。后续按student-learning/references/trial-installation.md准备独立环境并启动。直接GitHub安装student-learning文件夹默认Codex；WorkBuddy须通过安装器选择host。

首用由家长填写学生姓名、年级、路径。默认不接管已有正式档案、不安装常驻服务、不自动上传整目录。升级先backup，明确复用旧目录，不复制运行中的数据库。停止服务用Ctrl+C，保留素材和运行环境。

## 操作与差异

Codex网页可调用现有CLI，默认请求gpt-6-astra/medium，用户可配置；WorkBuddy网页保存请求后回当前对话执行导出/识别/提交，再回网页复核。两者共享坐标和证据校验，实际识图依赖宿主模型。不能保证各模型输出完全一致；不能看图、条件不足或字迹不清应停止或待核。

三科已接入：数学0.6.0-body-review 1211点，英语1.2 355条，语文1.0 84节点。其他学科待开放。数学仍内部审校，语文为分类/能力定位；版本1.0不代表知识库经外部教师或大规模学生验证。

## 发布内容与许可

student-learning/为可安装payload，install.py为安装器；前端源码与回归测试随source仓库发布，真实试卷、学生数据库、会话日志、运行环境不进入仓库。个人及家庭非商业用途可免费下载、安装、使用，无需另行申请；允许分享官方下载链接，商业使用另行授权。允许个人本地修改，不授予镜像包/修改版公开再分发或转售许可。没有激活、付费校验或强制注册。详见LICENSE与NOTICE.md；第三方知识材料来源权利单独保留。未配置收款、密钥、支付或许可证服务器；收费由发布者另行管理。

## 验证

`python student-learning/scripts/release_checks.py`只读检查完整性；自动测试使用独立空档案和合成材料，不接触个人档案。[验收记录](ACCEPTANCE.md)说明已执行和未执行的范围；[复测方案](TESTING.md)提供合成试卷生成器与A/B步骤。Windows与WorkBuddy新版本真实宿主回归仍应由用户复测，不把Python模拟当实机通过。
