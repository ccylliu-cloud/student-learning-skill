#!/usr/bin/env python3
"""Install a new Skill 1.0.0 without modifying any existing installation or archive."""
import argparse
import json
import os
from pathlib import Path
import shutil
import sys


def safe_path(value):
    path = Path(value).expanduser().absolute()
    for node in (path, *path.parents):
        if node.is_symlink():
            raise ValueError('拒绝符号链接路径：' + str(node))
    return path.resolve()


def inspect_tree(root):
    for current, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            path = Path(current) / name
            if path.is_symlink() or not (path.is_dir() or path.is_file()):
                raise ValueError('安装源包含符号链接或特殊文件：' + str(path))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', help='解压包中的 student-learning 目录')
    parser.add_argument('--host', required=True, choices=('codex', 'workbuddy'))
    parser.add_argument('--target', help='全新安装目录；WorkBuddy 必须明确指定')
    parser.add_argument('--workspace', help='WorkBuddy 当前项目的绝对目录；不猜测 cwd')
    parser.add_argument('--reuse-existing', action='store_true', help='已核对工作区默认目录的既有学习档案并明确复用')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--check', action='store_true', help='检查来源、目标和运行环境，不写文件')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise ValueError('需要 Python 3.10 或以上版本')
    if args.host == 'workbuddy' and not args.target:
        raise ValueError('WorkBuddy 请用 --target 明确指定它可以读取的全新 Skill 安装目录')
    source = safe_path(args.source or Path(__file__).parent / 'student-learning')
    target = safe_path(args.target or '~/.codex/skills/student-learning')
    if args.workspace and not Path(args.workspace).expanduser().is_absolute():
        raise ValueError('--workspace 必须是明确的项目绝对路径')
    workspace = safe_path(args.workspace) if args.workspace else None
    if workspace is None and target.parent.name == 'skills' and target.parent.parent.name in ('.codebuddy','.workbuddy'):
        workspace = target.parent.parent.parent
    if args.host == 'workbuddy':
        if workspace is None or not workspace.is_dir():
            raise ValueError('WorkBuddy 需要 --workspace 指定已存在项目目录，或将 target 放在项目/.codebuddy/skills/student-learning')
        if workspace not in target.parents:
            raise ValueError('WorkBuddy 安装目录也必须位于指定工作区内')
        data_root = workspace / '学习档案'
        if data_root == target or data_root in target.parents or target in data_root.parents:
            raise ValueError('Skill 安装目录与工作区/学习档案必须分开')
        if (data_root/'study.sqlite3').exists() and not args.reuse_existing:
            raise ValueError('工作区/学习档案已有数据；核对后加 --reuse-existing 明确复用，安装不会覆盖数据库')
    if source == target or source in target.parents or target in source.parents:
        raise ValueError('来源与目标不能相同或互相嵌套')
    if target.exists():
        raise ValueError('目标已存在，拒绝覆盖。请用 --target 选择一个全新目录：' + str(target))
    if not (source / 'SKILL.md').is_file() or not (source / 'scripts/study.py').is_file():
        raise ValueError('来源不是完整 student-learning Skill')
    inspect_tree(source)
    import hashlib
    release=json.loads((source/'distribution-manifest.json').read_text(encoding='utf-8'))
    for item in release['files']:
        path=source/item['file']
        if source not in path.resolve().parents or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
            raise ValueError('安装源校验失败：'+item['file'])
    if (source/'runtime').exists():
        raise ValueError('来源包含本机 runtime，请使用干净发行包；不复制本地配置或环境')
    marker = json.loads((source / 'trial-install.json').read_text(encoding='utf-8'))
    if marker.get('version') != 1 or marker.get('host') not in ('codex',args.host):
        raise ValueError('来源的 host 与 --host 不符，请选择对应产品包')
    for name in ('portable.py', 'portable_config.py', 'codex_bridge.py', 'codex_bridge_native.py', 'pc_server.py'):
        if not (source / 'scripts' / name).is_file():
            raise ValueError('完整安装包缺少适配文件：' + name)
    summary = {'workspace':str(workspace) if workspace else None,'host': args.host, 'source': str(source), 'target': str(target), 'python': sys.executable, 'writes': not(args.check or args.dry_run)}
    if not summary['writes']:
        print(json.dumps(summary, ensure_ascii=False)); return
    target.parent.mkdir(parents=True, exist_ok=True)
    # mkdir is exclusive: a second concurrent installer cannot replace the target.
    target.mkdir()
    try:
        shutil.copytree(source, target, dirs_exist_ok=True, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.DS_Store'))
        (target/'trial-install.json').write_text(json.dumps({'version':1,'host':args.host,'release':'1.0.0'}),encoding='utf-8')
        # Host marker is an installation setting, excluded from immutable payload manifest.
        (target / '启动学习档案.command').chmod(0o755)
        if workspace:
            runtime = target/'runtime'; runtime.mkdir()
            (runtime/'runtime.json').write_text(json.dumps({'version':1,'workspace':str(workspace),'root':str(workspace/'学习档案')},ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception:
        # Keep a failed new installation reviewable; do not recursively delete paths.
        print('安装未完成，保留新目录供检查；请选择其他新目录重试：' + str(target), file=sys.stderr)
        raise
    summary['next'] = [sys.executable, str(target / 'scripts/setup_runtime.py'), '--install-deps']
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError) as exc:
        print('安装失败：' + str(exc), file=sys.stderr); sys.exit(1)
