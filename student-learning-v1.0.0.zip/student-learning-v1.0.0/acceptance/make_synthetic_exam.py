"""Generate a synthetic, non-student exam. Generate once and copy the same PNG for A/B."""
import argparse,hashlib,json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);args=p.parse_args()
im=Image.new('RGB',(1800,2200),'white');draw=ImageDraw.Draw(im);font=ImageFont.load_default(size=40)
lines=[(90,70,'SYNTHETIC EXAM - NO STUDENT DATA'),(90,160,'1. Each pack has 25 pencils. There are 185 packs.'),(90,220,'   Plus 325 pencils. How many pencils in total?'),(120,330,'185 x 25 = 4625'),(120,400,'4626 + 325 = 4951'),(120,470,'Answer: 4951 pencils.'),(90,590,'Correction: 4625 + 325 = 4950 pencils.'),(90,950,'2. Calculate: 48 + 72 / 12'),(120,1060,'48 / 12 + 72 = 4 + 72 = 76'),(90,1200,'Correction: 48 + 6 = 54')]
for x,y,t in lines:draw.text((x,y),t,fill='black',font=font)
for y in (405,1075):
 draw.line((1450,y-35,1520,y+35),fill='red',width=10);draw.line((1520,y-35,1450,y+35),fill='red',width=10)
args.out.parent.mkdir(parents=True,exist_ok=True);im.save(args.out)
print(json.dumps({'path':str(args.out),'size':im.size,'sha256':hashlib.sha256(args.out.read_bytes()).hexdigest(),'kind':'synthetic'},ensure_ascii=False))
