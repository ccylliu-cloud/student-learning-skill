import {useState} from 'react';
import type {PcAsset} from './model';
export default function PcAssetImage({asset}:{asset:PcAsset}){
  const [ratio,setRatio]=useState(1);
  const src=asset.url,b=asset.box;
  if(!b)return <img src={src} alt={asset.label}/>;
  return <span className="study-crop-image" style={{aspectRatio:ratio*b.width/b.height}}><img src={src} alt={asset.label} onLoad={e=>{const image=e.currentTarget;if(image.naturalHeight)setRatio(image.naturalWidth/image.naturalHeight);}} style={{width:`${10000/b.width}%`,left:`${-b.x/b.width*100}%`,top:`${-b.y/b.height*100}%`}}/></span>;
}
