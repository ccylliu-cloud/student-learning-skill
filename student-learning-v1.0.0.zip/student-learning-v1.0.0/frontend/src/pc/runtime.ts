import {useEffect,useState} from 'react';
export type PcRuntime={version:string;host:'codex'|'workbuddy';recognition:{model:string|null;reasoning_effort:string|null;source:string;mode:'codex-cli'|'conversation'};capabilities:{automaticRecognition:boolean;conversationRecognition:boolean};knowledge?:unknown};
export const conversationInstruction='已保存，请回对话说“处理待识别试卷”。圈选范围和已有结果会保留。';
export function usePcRuntime(){
 const [runtime,setRuntime]=useState<PcRuntime|null>(null);
 useEffect(()=>{let live=true;fetch('/api/runtime',{cache:'no-store'}).then(async r=>{if(!r.ok)return null;return await r.json() as PcRuntime;}).then(v=>{if(live&&v&&typeof v.version==='string'&&v.capabilities&&v.recognition)setRuntime(v);}).catch(()=>{});return()=>{live=false;};},[]);
 return runtime;
}
