import type {PcAnswerEvidence,PcKnowledgeValidation} from './model';
export function CorrectionEvidence({correctedAnswer,answerEvidence}:{correctedAnswer?:string;answerEvidence?:PcAnswerEvidence}){
 const correction=correctedAnswer||answerEvidence?.correction_steps?.join('；');
 return <>{correction&&<><h3>订正记录</h3><p className="study-prose">{correction}</p></>}{answerEvidence?.completeness&&answerEvidence.completeness!=='complete'&&<p className="scan-note">作答证据尚不完整，请对照原图核对。</p>}</>;
}
export function CauseReview({status,hasCause}:{status?:string;hasCause:boolean}){return hasCause&&status!=='confirmed'?<p className="study-muted" role="status">错因待复核；确认正误不会确认错因。</p>:null;}

export function KnowledgeReview({value}:{value?:PcKnowledgeValidation}){return value&&value.status!=='matched'?<p className="study-muted">{value.status==='insufficient'?'知识关联未完成':'未匹配'}：{value.reason}</p>:null;}
