import {useEffect, useRef, useState} from 'react';
import type {ReactNode} from 'react';
import type {PcAsset} from './model';
import PcAssetImage from './PcAssetImage';
import './rich-question.css';

export type RichRun = {text:string;underline?:boolean;bold?:boolean;italic?:boolean};
export type RichBlock = {type:'paragraph';runs:RichRun[]} | {type:'image';asset:PcAsset;widthCm?:number};
export type QuestionContent = {version:1;blocks:RichBlock[]};
export type AnswerLayout = {kind:'inline'|'lines'|'space';lines?:number;heightCm?:number};
export type QuestionLayout = {sectionTitle?:string;sharedContext?:string;answerLayout?:AnswerLayout};
export const contentPlainText=(content?:QuestionContent)=>content?.blocks.filter((b):b is Extract<RichBlock,{type:'paragraph'}>=>b.type==='paragraph').map(b=>b.runs.map(r=>r.text).join('')).join('\n')||'';
export const textContent=(text:string):QuestionContent=>({version:1,blocks:text.split('\n').map(text=>({type:'paragraph',runs:[{text}]}))});

export function hasQuestionContent(content:QuestionContent|undefined,fullText:string){
  return !!fullText.trim()||!!content?.blocks.some(b=>b.type==='image'?!!b.asset?.url:b.runs.some(r=>!!r.text.trim()));
}
// Only turn answer placeholders into writable shapes; circled item numbers and defined symbols stay unchanged.
export function writableAnswerText(text:string,context:string):ReactNode{
  if(!/(填|横线|空格|合适的|适当的)/.test(context))return text;
  return text.split(/(\n)/).map((line,lineIndex)=>{
    if(!/[=＝+＋−－×÷]/.test(line)||/已知|代表|表示|设[□○〇]/.test(line))return line;
    return <span key={lineIndex}>{line.split(/([□○〇])/).map((part,index)=>/^[□○〇]$/.test(part)?<span key={index} className={`rich-answer-placeholder ${part==='□'?'is-square':'is-circle'}`} role="img" aria-label={part==='□'?'方框填空':'圆圈填空'}/>:part)}</span>;
  });
}

export function RichQuestion({content,fullText,sectionTitle,sharedContext}:{content?:QuestionContent;fullText:string;sectionTitle?:string;sharedContext?:string}){
  const context=[sectionTitle,sharedContext,contentPlainText(content)||fullText].filter(Boolean).join("\n");
  return <div className="rich-question">{sectionTitle&&<p className="rich-section-title">{sectionTitle}</p>}{sharedContext&&<p className="rich-shared-context">{sharedContext}</p>}{content?.blocks.length?content.blocks.map((b,i)=>b.type==='image'?<figure className="rich-question-image" key={i} style={{maxWidth:`${b.widthCm||12}cm`}}><PcAssetImage asset={b.asset}/></figure>:<p key={i}>{b.runs.map((r,j)=><span key={j} style={{textDecoration:r.underline?'underline':undefined,textUnderlineOffset:'3px',fontWeight:r.bold?650:undefined,fontStyle:r.italic?'italic':undefined}}>{writableAnswerText(r.text,context)}</span>)}{!b.runs.some(r=>r.text)&&<br/>}</p>):<p>{writableAnswerText(fullText,context)}</p>}</div>;
}

// Read only the supported inline marks, never persist pasted HTML or remote images.
function readRuns(root:Node):RichRun[]{
  const runs:RichRun[]=[];
  function visit(node:Node,marks:Omit<RichRun,'text'>){
    if(node.nodeType===Node.TEXT_NODE){if(node.textContent)runs.push({text:node.textContent,...marks});return;}
    if(!(node instanceof Element)){node.childNodes.forEach(n=>visit(n,marks));return;}
    if(node.tagName==='BR'){runs.push({text:'\n',...marks});return;}
    if(['IMG','SCRIPT','STYLE'].includes(node.tagName))return;
    const style=node instanceof HTMLElement?node.style:undefined;
    const next={...marks,...(node.tagName==='U'||style?.textDecoration.includes('underline')?{underline:true}:{}),...(['B','STRONG'].includes(node.tagName)||style?.fontWeight==='bold'?{bold:true}:{}),...(['I','EM'].includes(node.tagName)||style?.fontStyle==='italic'?{italic:true}:{})};
    if(['DIV','P'].includes(node.tagName)&&runs.length&&runs.at(-1)?.text.slice(-1)!=='\n')runs.push({text:'\n'});
    node.childNodes.forEach(n=>visit(n,next));
  }
  root.childNodes.forEach(n=>visit(n,{}));
  return runs.length?runs:[{text:''}];
}
function ParagraphEditor({runs,disabled,onChange,onPasteImage,onActive}:{runs:RichRun[];disabled:boolean;onChange:(runs:RichRun[])=>void;onPasteImage:(file:File)=>void;onActive:(el:HTMLDivElement)=>void}){
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{const el=ref.current;if(!el||document.activeElement===el)return;el.replaceChildren(...runs.map(r=>{const span=document.createElement('span');span.textContent=r.text;if(r.underline)span.style.textDecoration='underline';if(r.bold)span.style.fontWeight='bold';if(r.italic)span.style.fontStyle='italic';return span;}));},[runs]);
  return <div ref={ref} className="rich-paragraph-editor" role="textbox" aria-label="题干文字" aria-multiline="true" contentEditable={!disabled} suppressContentEditableWarning onFocus={e=>onActive(e.currentTarget)} onInput={e=>onChange(readRuns(e.currentTarget))} onPaste={e=>{e.preventDefault();const file=Array.from(e.clipboardData.files).find(f=>f.type.startsWith('image/'));if(file){onPasteImage(file);return;}document.execCommand('insertText',false,e.clipboardData.getData('text/plain'));onChange(readRuns(e.currentTarget));}}/>;
}

export function RichQuestionEditor({content,fullText,onChange,token,disabled=false,onBusy}:{content?:QuestionContent;fullText:string;onChange:(content:QuestionContent,fullText:string)=>void;token?:string;disabled?:boolean;onBusy?:(busy:boolean)=>void}){
  const value=content?.blocks.length?content:textContent(fullText);
  const [uploading,setUploading]=useState(false),[error,setError]=useState('');
  const active=useRef<{el:HTMLDivElement;index:number}|null>(null),selection=useRef<Range|null>(null),fileInput=useRef<HTMLInputElement>(null);
  const latest=useRef(value);latest.current=value;
  const busy=disabled||uploading;
  useEffect(()=>{onBusy?.(uploading);return()=>onBusy?.(false);},[uploading,onBusy]);
  function emit(blocks:RichBlock[]){const next:QuestionContent={version:1,blocks:blocks.length?blocks:[{type:'paragraph',runs:[{text:''}]}]};onChange(next,contentPlainText(next));}
  function remember(){const s=window.getSelection();if(s?.rangeCount&&active.current?.el.contains(s.anchorNode))selection.current=s.getRangeAt(0).cloneRange();}
  function mark(command:string){const s=window.getSelection();if(!active.current||!selection.current)return;active.current.el.focus();s?.removeAllRanges();s?.addRange(selection.current);document.execCommand(command);const blocks=[...latest.current.blocks];blocks[active.current.index]={type:'paragraph',runs:readRuns(active.current.el)};emit(blocks);remember();}
  async function upload(file:File){
    if(busy)return;if(!/^image\/(png|jpeg|webp)$/.test(file.type)){setError('请选择 PNG、JPG 或 WebP 图片。');return;}if(file.size>10*1024*1024){setError('图片请控制在 10 MB 以内。');return;}
    remember();const original=[...latest.current.blocks];let index=active.current?.index??original.length-1;
    // Split the paragraph at the insertion point so the picture stays at the caret.
    let split:RichBlock[]|null=null;
    if(active.current&&selection.current&&active.current.el.contains(selection.current.startContainer)){
      const before=document.createRange(),after=document.createRange();before.selectNodeContents(active.current.el);before.setEnd(selection.current.startContainer,selection.current.startOffset);after.selectNodeContents(active.current.el);after.setStart(selection.current.endContainer,selection.current.endOffset);
      split=[{type:'paragraph',runs:readRuns(before.cloneContents())},{type:'paragraph',runs:readRuns(after.cloneContents())}];
    }
    setUploading(true);setError('');
    try{const dataUrl=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(Error('图片读取失败'));reader.readAsDataURL(file);});
      let auth=token;if(!auth){const r=await fetch('/api/archive');if(!r.ok)throw Error('无法连接本地档案');auth=(await r.json()).token;}
      const res=await fetch('/api/assets',{method:'POST',headers:{'Content-Type':'application/json','X-Pc-Token':auth||''},body:JSON.stringify({dataUrl,name:file.name||'粘贴的题图.png'})});const body=await res.json();if(!res.ok)throw Error(body.error||'图片保存失败');if(!body.asset?.url)throw Error('图片保存结果不完整');
      const block:RichBlock={type:'image',asset:body.asset,widthCm:10};
      if(split)original.splice(index,1,split[0],block,split[1]);else original.splice(index+1,0,block,{type:'paragraph',runs:[{text:''}]});emit(original);active.current=null;selection.current=null;
    }catch(e){setError(e instanceof Error?e.message:'图片保存失败，请重试');}finally{setUploading(false);}
  }
  return <div className="rich-editor" onMouseUp={remember} onKeyUp={remember}>
    <div className="rich-editor-toolbar"><button type="button" disabled={busy} onMouseDown={e=>e.preventDefault()} onClick={()=>mark('underline')}><u>下划线</u></button><button type="button" disabled={busy} onMouseDown={e=>e.preventDefault()} onClick={()=>mark('bold')}><b>加粗</b></button><button type="button" disabled={busy} onMouseDown={e=>e.preventDefault()} onClick={()=>{remember();fileInput.current?.click();}}>插入题图</button><button type="button" disabled={busy} onClick={()=>emit([...value.blocks,{type:'paragraph',runs:[{text:''}]}])}>添加文字段落</button><span>{uploading?'正在保存图片…':'选中文字可加下划线，也可直接粘贴题图'}</span><input type="file" ref={fileInput} hidden accept="image/png,image/jpeg,image/webp" onChange={e=>{const f=e.target.files?.[0];if(f)void upload(f);e.target.value='';}}/></div>
    <div className="rich-editor-blocks">{value.blocks.map((block,index)=>block.type==='paragraph'?<ParagraphEditor key={index} runs={block.runs} disabled={busy} onActive={el=>{active.current={el,index};}} onChange={runs=>{const blocks=[...value.blocks];blocks[index]={type:'paragraph',runs};emit(blocks);}} onPasteImage={file=>void upload(file)}/>:<figure className="rich-editor-image" key={index}><div style={{maxWidth:`${block.widthCm||10}cm`}}><PcAssetImage asset={block.asset}/></div><figcaption><label>图片宽度 <input type="number" min="2" max="16" step="0.5" value={block.widthCm||10} disabled={busy} onChange={e=>{const blocks=[...value.blocks];blocks[index]={...block,widthCm:Math.max(2,Math.min(16,Number(e.target.value)||10))};emit(blocks);}}/> cm</label><button type="button" disabled={busy||index===0} onClick={()=>{const blocks=[...value.blocks];[blocks[index-1],blocks[index]]=[blocks[index],blocks[index-1]];emit(blocks);}}>上移</button><button type="button" disabled={busy||index===value.blocks.length-1} onClick={()=>{const blocks=[...value.blocks];[blocks[index+1],blocks[index]]=[blocks[index],blocks[index+1]];emit(blocks);}}>下移</button><button type="button" disabled={busy} onClick={()=>emit(value.blocks.filter((_,i)=>i!==index))}>移除图片</button></figcaption></figure>)}</div>{error&&<p className="study-field-error" role="alert">{error}</p>}
  </div>;
}

export function QuestionLayoutFields({value,onChange,disabled=false}:{value:QuestionLayout;onChange:(value:QuestionLayout)=>void;disabled?:boolean}){
  const layout=value.answerLayout;
  return <div className="question-layout-fields"><label>大题说明<input className="study-input" value={value.sectionTitle||''} disabled={disabled} placeholder="如：Rewrite the following sentences as required" onChange={e=>onChange({...value,sectionTitle:e.target.value})}/></label><label>共用材料<textarea className="study-input" value={value.sharedContext||''} rows={2} disabled={disabled} placeholder="仅填写同组小题共用的阅读材料或条件" onChange={e=>onChange({...value,sharedContext:e.target.value})}/></label><div className="question-layout-controls"><label>作答空间<select className="study-input" value={layout?.kind||'auto'} disabled={disabled} onChange={e=>onChange({...value,answerLayout:e.target.value==='auto'?undefined:e.target.value==='lines'?{kind:'lines',lines:2}:e.target.value==='space'?{kind:'space',heightCm:3}:{kind:'inline'}})}><option value="auto">按题型和原卷安排</option><option value="inline">题内填空</option><option value="lines">题下横线</option><option value="space">题下空白</option></select></label>{layout?.kind==='lines'&&<label>横线行数<input className="study-input" type="number" min={1} max={12} disabled={disabled} value={layout.lines||2} onChange={e=>onChange({...value,answerLayout:{kind:'lines',lines:Math.max(1,Math.min(12,Number(e.target.value)||1))}})}/></label>}{layout?.kind==='space'&&<label>空白高度（厘米）<input className="study-input" type="number" min={1} max={15} step={.5} disabled={disabled} value={layout.heightCm||3} onChange={e=>onChange({...value,answerLayout:{kind:'space',heightCm:Math.max(1,Math.min(15,Number(e.target.value)||1))}})}/></label>}</div></div>;
}
