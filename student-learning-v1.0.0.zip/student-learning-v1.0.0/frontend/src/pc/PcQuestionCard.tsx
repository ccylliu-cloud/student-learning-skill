import type { PcQuestion } from './model';
import './overview.css';
import {RichQuestion} from './RichQuestion';

export function questionTags(question: PcQuestion, kind: 'knowledgePoint' | 'reason'): string[] {
  const values = kind === 'knowledgePoint' ? question.knowledgePoints : question.reasons;
  return [...new Set((values?.length ? values : [question[kind]]).filter(Boolean))];
}

type Props = {
  question: PcQuestion;
  index?: number;
  showAnswer?: boolean;
  selectMode?: boolean;
  selected?: boolean;
  onOpen: () => void;
  onSelect?: () => void;
  onTag?: (kind: 'knowledgePoint' | 'reason', value: string) => void;
};

export default function PcQuestionCard({ question, index, showAnswer = false, selectMode = false, selected = false, onOpen, onSelect, onTag }: Props) {
  const knowledge = questionTags(question, 'knowledgePoint');
  const reasons = questionTags(question, 'reason');
  return (
    <article className={`study-question-card${selectMode && selected ? ' study-question-selected' : ''}`}>
      <div className="study-question-topline">
        <div className="study-question-number">
          {selectMode && <input type="checkbox" checked={selected} onChange={onSelect} aria-label={`${selected ? '取消选择' : '选择'}第 ${index === undefined ? question.id : index + 1} 题`} />}
          {index !== undefined && <span>第 {index + 1} 题</span>}
        </div>
        <span className={`study-status study-question-status${question.mastery === '已掌握' ? ' study-question-mastered' : ''}`}>{question.mastery}</span>
      </div>
      <button
        type="button"
        className="study-question-body"
        onClick={selectMode ? onSelect : onOpen}
        aria-pressed={selectMode ? selected : undefined}
      >
        <RichQuestion content={question.content} fullText={question.fullText} sectionTitle={question.sectionTitle} sharedContext={question.sharedContext}/>
        <span className="study-question-action" aria-hidden="true">{selectMode ? (selected ? '已选择' : '选择此题') : '查看详情'} <span>→</span></span>
      </button>
      {showAnswer && <div className="study-prose"><strong>正确答案</strong><p>{question.answer || "暂未记录答案"}</p></div>}
      <div className="study-question-metadata">
        <div className="study-question-tagline">
          <span className="study-question-tag-label">知识点</span>
          <div className="study-question-tags">
            {knowledge.map(value => onTag
              ? <button type="button" key={value} className="study-tag study-question-knowledge" onClick={() => onTag('knowledgePoint', value)} aria-label={`筛选知识点：${value}`}>{value}</button>
              : <span key={value} className="study-tag study-question-knowledge">{value}</span>)}
            {knowledge.length === 0 && <span className="study-muted">未标注</span>}
          </div>
        </div>
        <div className="study-question-tagline">
          <span className="study-question-tag-label">错题原因</span>
          <div className="study-question-tags">
            {reasons.map(value => onTag
              ? <button type="button" key={value} className="study-tag study-question-reason" onClick={() => onTag('reason', value)} aria-label={`筛选错题原因：${value}`}>{value}</button>
              : <span key={value} className="study-tag study-question-reason">{value}</span>)}
            {reasons.length === 0 && <span className="study-muted">未标注</span>}
          </div>
        </div>
      </div>
      <footer className="study-question-footer">
        <span className="study-tag study-question-date">上传时间：{question.uploadTime}</span>
        <span className="study-question-counts">错 {question.wrongCount} 次<span aria-hidden="true"> · </span>对 {question.correctCount} 次<span aria-hidden="true"> · </span>组卷 {question.groupedCount} 次</span>
      </footer>
    </article>
  );
}
