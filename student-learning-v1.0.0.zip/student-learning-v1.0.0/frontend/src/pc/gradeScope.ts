import type {PcArchive,PcQuestion,PcSubject} from './model';

export type GradeView=number|'unknown'|'all';
export function recordGrade(value:unknown):number|null{return typeof value==='number'&&Number.isInteger(value)&&value>=1&&value<=12?value:null;}
export function questionGrade(q:PcQuestion,archive:PcArchive):number|null{
  return recordGrade(q.grade)??recordGrade(archive.papers.find(p=>p.id===q.originalId&&p.kind==='original')?.grade);
}
const matches=(grade:number|null,view:GradeView)=>view==='all'||(view==='unknown'?grade===null:grade===view);
/** Rendering projection only. Mutations must always start from the complete archive. */
export function scopeArchiveByGrade(archive:PcArchive,view:GradeView):PcArchive{
  if(view==='all')return archive;
  const recognition=archive.recognition;
  const groups=recognition?.groups.filter(g=>matches(recordGrade(g.grade),view));
  const pages=recognition?.pages.filter(page=>{
    const owners=recognition.groups.filter(group=>group.pageIds.includes(page.id));
    return owners.length?owners.some(group=>matches(recordGrade(group.grade),view)):matches(recordGrade(page.grade),view);
  });
  return {...archive,questions:archive.questions.filter(q=>matches(questionGrade(q,archive),view)),papers:archive.papers.filter(p=>matches(recordGrade(p.grade),view)),...(recognition?{recognition:{...recognition,groups:groups!,pages:pages!}}:{})};
}
export function hasUnassignedGrade(archive:PcArchive,subject?:PcSubject):boolean{
  const unknown=scopeArchiveByGrade(archive,'unknown');
  return [...unknown.questions,...unknown.papers,...(unknown.recognition?.groups||[]),...(unknown.recognition?.pages||[])].some(item=>!subject||item.subject===subject);
}
