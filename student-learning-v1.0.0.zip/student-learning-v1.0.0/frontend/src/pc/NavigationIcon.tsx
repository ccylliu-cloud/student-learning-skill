import type {ReactNode} from 'react';
export type NavigationIconName='home'|'questions'|'recognition'|'dashboard'|'papers'|'originals'|'brand';
const paths:Record<NavigationIconName,ReactNode>={
  home:<><path d="m3.5 10 8.5-7 8.5 7v9.5a1 1 0 0 1-1 1h-5v-7h-5v7h-5a1 1 0 0 1-1-1Z"/></>,
  questions:<><rect x="5" y="3" width="15" height="18" rx="2"/><path d="M8 3v18M3 7h4M3 12h4M3 17h4M11.5 8h5M11.5 12h5M11.5 16h3"/></>,
  recognition:<><path d="M8 3H5a2 2 0 0 0-2 2v3m13-5h3a2 2 0 0 1 2 2v3M3 16v3a2 2 0 0 0 2 2h3m8 0h3a2 2 0 0 0 2-2v-3M3 12h18"/><path d="M8 8h8M8 16h5"/></>,
  dashboard:<><path d="M10 3.5a8.5 8.5 0 1 0 10.5 10.5H10Z"/><path d="M14 3.5V10h6.5A8.5 8.5 0 0 0 14 3.5Z"/></>,
  papers:<><path d="M8 3h8l4 4v12a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M15 3v5h5M10 12h6M10 16h6M3 6v13"/></>,
  originals:<><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/><path d="m7 17 3-3 3 3 2-2 3 3"/><circle cx="15.5" cy="11.5" r="1"/></>,
  brand:<><path d="M12 5c-3-2-6-2-9-1v15c3-1 6-1 9 1 3-2 6-2 9-1V4c-3-1-6-1-9 1Z"/><path d="M12 5v15M6 8h3M15 8h3M6 12h3M15 12h3"/></>
};
export default function NavigationIcon({name}:{name:NavigationIconName}){return <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false">{paths[name]}</svg>;}
