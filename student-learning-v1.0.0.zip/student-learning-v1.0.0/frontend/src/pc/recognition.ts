import type {PcArchive,PcRecognition,PcScanGroup,PcScanQuestion,PcSubject} from './model';
import {hasQuestionContent} from './RichQuestion';
export function readRecognition(a:PcArchive):PcRecognition{return a.recognition??{pages:[],groups:[]};}
export function groupPages(r:PcRecognition,ids:string[],subject:PcSubject,target:string,title:string):PcRecognition{
  const pages=r.pages.filter(p=>ids.includes(p.id)&&p.subject===subject);if(!pages.length)throw Error('请先选择图片');
  const selected=new Set(pages.map(p=>p.id));
  if(r.groups.some(g=>(g.recognized||g.requested)&&g.pageIds.some(id=>selected.has(id))))throw Error('已有识别结果的图片暂不调整分组');
  if(target!=='ungrouped'&&r.groups.some(g=>g.id===target&&(g.recognized||g.requested)))throw Error('请选择尚未识别的试卷');
  let groups=r.groups.map(g=>({...g,pageIds:g.pageIds.filter(id=>!selected.has(id))}));
  if(target!=='ungrouped'){
    const existing=groups.find(g=>g.id===target);
    if(existing&&existing.subject!==subject)throw Error('不能跨学科分组');
    if(existing)groups=groups.map(g=>g.id===target?{...g,pageIds:[...g.pageIds,...pages.map(p=>p.id)]}:g);
    else groups.push({id:target,title:title.trim()||`${subject}试卷`,subject,pageIds:pages.map(p=>p.id),questions:[],recognized:false});
  }
  return {...r,groups:groups.filter(g=>g.pageIds.length||g.recognized)};
}
export function validScanQuestion(q:PcScanQuestion){return hasQuestionContent(q.content,q.fullText)&&q.knowledgePoints.length<=3&&q.reasons.length<=2;}
export function saveScanQuestions(archive:PcArchive,groupId:string,onlyId?:string):PcArchive{
 const r=readRecognition(archive),g=r.groups.find(g=>g.id===groupId);if(!g?.recognized)throw Error('请先识别试卷');
 const ids=new Set(g.questions.filter(q=>q.status!=='excluded'&&q.decisionStatus!=='confirmed'&&(!onlyId||q.id===onlyId)&&(q.verdict==='wrong'||!!onlyId&&q.verdict==='correct')).map(q=>q.id));
 if(g.questions.some(q=>ids.has(q.id)&&!validScanQuestion(q)))throw Error('请补全题干后确认');
 return {...archive,recognition:{...r,groups:r.groups.map(group=>group.id===groupId?{...group,finalized:true,questions:group.questions.map(q=>ids.has(q.id)?{...q,status:'saved',decisionStatus:'confirmed',savedQuestionId:q.verdict==='wrong'?q.canonicalId:undefined}:q)}:group)}};
}

// Upload date is stable when recognition is retried. Array order breaks same-day ties.
export function scanGroupDate(r:PcRecognition,g:PcScanGroup){
  return r.pages.filter(p=>g.pageIds.includes(p.id)).map(p=>p.date).filter(Boolean).sort((a,b)=>a.replace(/\D/g,'').localeCompare(b.replace(/\D/g,''))).at(-1)||'';
}
export function newestScanGroups(r:PcRecognition,subject:PcSubject){
  return r.groups.map((group,index)=>({group,index,date:scanGroupDate(r,group).replace(/\D/g,'')})).filter(x=>x.group.subject===subject).sort((a,b)=>b.date.localeCompare(a.date)||b.index-a.index).map(x=>x.group);
}
export function scanReviewState(g:PcScanGroup){
  const candidates=g.questions.filter(q=>q.verdict!=='correct'||q.decisionStatus==='confirmed');
  const reviewed=candidates.filter(q=>q.decisionStatus==='confirmed'||q.status==='excluded'&&q.exclusionKind==='invalid').length;
  return {label:reviewed&&reviewed===candidates.length?'已人工复核':reviewed?'部分复核':'待人工复核',reviewed,total:candidates.length};
}

// New projections separate valid geometry from human verification; old records retain their prior behavior.
export function scanBoxLocated(q:Pick<PcScanQuestion,'boxLocated'|'boxVerified'>){return q.boxLocated===undefined?q.boxVerified!==false:q.boxLocated;}
