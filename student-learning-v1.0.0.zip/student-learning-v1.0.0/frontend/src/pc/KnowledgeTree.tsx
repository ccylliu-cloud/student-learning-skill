import {useEffect,useRef,useState} from 'react';
import type {PcQuestion} from './model';
import './knowledge-tree.css';
export type KnowledgeNode={id:string;label:string;level:1|2|3;children?:KnowledgeNode[]};
export function knowledgeLeaves(node:KnowledgeNode):KnowledgeNode[]{return node.children?.length?node.children.flatMap(knowledgeLeaves):[node];}
export function flattenKnowledge(nodes:KnowledgeNode[]):KnowledgeNode[]{return nodes.flatMap(n=>[n,...flattenKnowledge(n.children||[])]);}
function TriCheck({checked,mixed,disabled,onChange,label}:{checked:boolean;mixed:boolean;disabled?:boolean;onChange:()=>void;label:string}){const ref=useRef<HTMLInputElement>(null);useEffect(()=>{if(ref.current)ref.current.indeterminate=mixed;},[mixed]);return <input ref={ref} type="checkbox" aria-label={label} checked={checked} disabled={disabled} onChange={onChange}/>;}
export function KnowledgeTreeFilter({nodes,selected,onChange,disabled=false,leafOnly=false,max}:{nodes:KnowledgeNode[];selected:string[];onChange:(ids:string[])=>void;disabled?:boolean;leafOnly?:boolean;max?:number}){
  const [search,setSearch]=useState(''),[expanded,setExpanded]=useState<Set<string>>(new Set()),[error,setError]=useState('');
  const all=flattenKnowledge(nodes),selectedLeaves=new Set(selected.flatMap(id=>{const node=all.find(n=>n.id===id);return node?knowledgeLeaves(node).map(n=>n.id):[id];}));
  function toggle(node:KnowledgeNode){const descendants=knowledgeLeaves(node).map(n=>n.id),next=new Set(selectedLeaves);if(descendants.every(id=>next.has(id)))descendants.forEach(id=>next.delete(id));else descendants.forEach(id=>next.add(id));if(max&&next.size>max){setError(`最多选择 ${max} 个知识点`);return;}setError('');onChange([...next]);}
  function matches(n:KnowledgeNode):boolean{return n.label.toLowerCase().includes(search.trim().toLowerCase())||!!n.children?.some(matches);}
  function branch(node:KnowledgeNode,ancestorMatched=false){const selfMatches=!!search.trim()&&node.label.toLowerCase().includes(search.trim().toLowerCase());if(search.trim()&&!ancestorMatched&&!matches(node))return null;const ids=knowledgeLeaves(node).map(n=>n.id),count=ids.filter(id=>selectedLeaves.has(id)).length,children=!!node.children?.length,open=!!search.trim()||expanded.has(node.id);return <li key={node.id}><div className="knowledge-tree-option" style={{paddingLeft:(node.level-1)*18}}>{children?<button type="button" className="knowledge-tree-expand" aria-label={`${open?'收起':'展开'}${node.label}`} aria-expanded={open} onClick={()=>setExpanded(old=>{const n=new Set(old);if(n.has(node.id))n.delete(node.id);else n.add(node.id);return n;})}>{open?'⌄':'›'}</button>:<span className="knowledge-tree-spacer"/>}<label>{(!leafOnly||!children)&&<TriCheck checked={count===ids.length} mixed={count>0&&count<ids.length} disabled={disabled} onChange={()=>toggle(node)} label={`选择${node.label}`}/>}<span>{node.label}</span></label></div>{children&&open&&<ul>{node.children!.map(n=>branch(n,ancestorMatched||selfMatches))}</ul>}</li>;}
  return <div className="knowledge-tree-filter"><input className="study-input" type="search" aria-label="搜索知识点" value={search} placeholder="搜索知识点" onChange={e=>setSearch(e.target.value)}/><div className="knowledge-tree-summary"><span>已选 {selectedLeaves.size} 个考点</span>{selected.length>0&&<button type="button" className="study-link" disabled={disabled} onClick={()=>onChange([])}>清除</button>}</div><ul className="knowledge-tree-options">{nodes.map(n=>branch(n))}</ul>{search&&!nodes.some(matches)&&<p className="study-muted">没有匹配的知识点</p>}{error&&<p className="study-field-error" role="status">{error}</p>}</div>;
}

type Item={id:string;knowledgeIds?:string[];knowledgePoints?:string[];knowledgePoint?:string;mastery?:string;result?:'correct'|'wrong'|'pending'|'ungradable'};
type Row={node:KnowledgeNode;count:number;positive:number;negative:number;pending:number};
export function knowledgeRows(nodes:KnowledgeNode[],questions:Item[],mode:'mastery'|'result'='mastery'):Row[]{return flattenKnowledge(nodes).map(node=>{const leaves=knowledgeLeaves(node),ids=new Set(leaves.map(n=>n.id)),labels=new Set(leaves.map(n=>n.label));const matching=[...new Map(questions.filter(q=>q.knowledgeIds?.length?q.knowledgeIds.some(id=>ids.has(id)):(q.knowledgePoints||[q.knowledgePoint||'']).some(label=>labels.has(label))).map(q=>[q.id,q])).values()];const positive=matching.filter(q=>mode==='mastery'?q.mastery==='已掌握':q.result==='correct').length,negative=matching.filter(q=>mode==='mastery'?q.mastery!=='已掌握':q.result==='wrong').length;return {node,count:matching.length,positive,negative,pending:matching.length-positive-negative};}).filter(row=>row.count>0);}
export function KnowledgeDistributionChart({nodes,questions,onFilter,mode='mastery'}:{nodes:KnowledgeNode[];questions:(PcQuestion|Item)[];onFilter?:(id:string)=>void;mode?:'mastery'|'result'}){
  const [firstId,setFirstId]=useState(''),[secondId,setSecondId]=useState('');
  const rows=knowledgeRows(nodes,questions,mode),byId=new Map(rows.map(row=>[row.node.id,row]));
  const withData=(items:KnowledgeNode[])=>items.filter(node=>byId.has(node.id));
  const first=withData(nodes.filter(node=>node.level===1));
  const selectedFirst=first.find(node=>node.id===firstId)||first[0];
  const second=withData((selectedFirst?.children||nodes).filter(node=>node.level===2));
  const selectedSecond=second.find(node=>node.id===secondId)||second[0];
  const third=withData(selectedSecond?.children||selectedFirst?.children?.filter(node=>node.level===3)||nodes.filter(node=>node.level===3));
  const labels=mode==='mastery'?['错题总数','已掌握','未掌握']:['做对','做错','待确认'];
  const tones=mode==='mastery'?['total','positive','unmastered']:['positive','negative','pending'];
  const knownIds=new Set(flattenKnowledge(nodes).map(n=>n.id)),knownLabels=new Set(flattenKnowledge(nodes).map(n=>n.label));
  const unmapped=questions.filter(q=>q.knowledgeIds?.length?q.knowledgeIds.some(id=>!knownIds.has(id)):!(q.knowledgePoints||[q.knowledgePoint||'']).some(label=>knownLabels.has(label))).length;
  const hasThirdLevel=flattenKnowledge(nodes).some(node=>node.level===3);
  const columns=[{title:'一级知识点',items:first,selected:selectedFirst?.id,parent:''},{title:'二级知识点',items:second,selected:selectedSecond?.children?.length?selectedSecond.id:undefined,parent:selectedFirst?.id},...(hasThirdLevel?[{title:'三级知识点',items:third,selected:undefined,parent:selectedSecond?.id}]:[])];
  return <div className="knowledge-chart">
    <div className="knowledge-number-legend" aria-label="数字顺序">{labels.map((label,i)=><span key={label}>{i>0&&<span className="knowledge-number-divider" aria-hidden="true"> / </span>}<span className={`knowledge-number-${tones[i]}`}>{label}</span></span>)}</div>
    {rows.length?<div className="knowledge-columns-scroll"><div className={`knowledge-columns ${hasThirdLevel?'':'has-two-levels'}`}>{columns.map((column,index)=><section className="knowledge-column" key={column.title} aria-label={column.title}>
      <h4>{column.title}<span>（{column.items.length} 项）</span></h4>
      <div className="knowledge-column-list" key={column.parent||'root'} tabIndex={0} aria-label={`${column.title}列表`}>{column.items.length?column.items.map(node=>{
        const row=byId.get(node.id)!;const counts=mode==='mastery'?[row.count,row.positive,row.negative]:[row.positive,row.negative,row.pending];
        const description=`${node.label}：${labels.map((label,i)=>`${label} ${counts[i]}`).join('，')}`;
        const isLeaf=!node.children?.length;
        return <button type="button" key={node.id} className={`knowledge-cascade-row ${column.selected===node.id?'is-selected':''}`} disabled={isLeaf&&!onFilter} aria-pressed={!isLeaf?column.selected===node.id:undefined} aria-label={`${description}；${isLeaf?'查看对应错题':'查看下级知识点'}`} title={description} onClick={()=>{if(isLeaf){onFilter?.(node.id);return;}if(index===0){setFirstId(node.id);setSecondId('');}else if(index===1)setSecondId(node.id);}}>
          <span className="knowledge-node-dot" aria-hidden="true"/><span className="knowledge-node-name">{node.label}</span>
          <span className="knowledge-inline-counts" aria-hidden="true">{counts.map((count,i)=><span key={labels[i]}>{i>0&&<span className="knowledge-number-divider">/</span>}<strong className={`knowledge-number-${tones[i]}`}>{count}</strong></span>)}</span>
          {!isLeaf&&<span className="knowledge-node-arrow" aria-hidden="true">›</span>}
        </button>;
      }):<p className="knowledge-column-empty">暂无相关知识点</p>}</div>
    </section>)}</div></div>:<p className="study-empty">暂无已关联知识库的记录</p>}
    {unmapped>0&&<p className="study-muted knowledge-chart-note">另有 {unmapped} 道题的知识点尚未完整关联知识库。</p>}
    <p className="study-muted knowledge-chart-note">每个节点按题目去重统计；一道题涉及多个考点时，各考点分别计入。</p>
  </div>;
}
