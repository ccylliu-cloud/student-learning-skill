import {useEffect,useRef,useState} from 'react';
import type {PcArchive,PcSubject} from './model';
import './settings.css';

export const availableSubjects:PcSubject[]=['数学','语文','英语'];
export const gradeNames=['一年级','二年级','三年级','四年级','五年级','六年级','七年级','八年级','九年级','高一','高二','高三'];
export type StudentSettingsValue={name:string;grade:number;selectedSubjects:PcSubject[];storageRoot:string};
type Props={profile:NonNullable<PcArchive['profile']>;mode:'profile'|'subjects';required:boolean;saving:boolean;onClose:()=>void;onSave:(value:StudentSettingsValue)=>Promise<void>;onChooseFolder:()=>Promise<string|null>};
export function selectedSubjectNames(profile?:PcArchive['profile']):PcSubject[]{const values=availableSubjects.filter(s=>profile?.selectedSubjects?.includes(s));return values.length?values:[...availableSubjects];}
export default function StudentSettings({profile,mode,required,saving,onClose,onSave,onChooseFolder}:Props){
  const dialog=useRef<HTMLDialogElement>(null);
  const [name,setName]=useState(profile.name||''),[grade,setGrade]=useState(Number(profile.grade)||0);
  const [subjects,setSubjects]=useState<PcSubject[]>(()=>selectedSubjectNames(profile));
  const [storageRoot,setStorageRoot]=useState(profile.storageRoot||''),[folderConfirmed,setFolderConfirmed]=useState(false);
  const [error,setError]=useState(''),[choosing,setChoosing]=useState(false),[submitting,setSubmitting]=useState(false);
  const busy=saving||choosing||submitting,showProfile=required||mode==='profile';
  const folderChanged=storageRoot.trim()!==(profile.storageRoot||'').trim();
  const needFolderConfirmation=required||folderChanged;
  useEffect(()=>{const el=dialog.current;el?.showModal();return()=>el?.close();},[]);
  function toggle(subject:PcSubject){setSubjects(old=>old.includes(subject)?old.filter(s=>s!==subject):[...old,subject]);setError('');}
  async function chooseFolder(){setChoosing(true);setError('');try{const path=await onChooseFolder();if(path){setStorageRoot(path);setFolderConfirmed(false);}}catch(e){setError(e instanceof Error?e.message:'无法选择文件夹，请直接填写路径。');}finally{setChoosing(false);}}
  async function save(){
    if(busy)return;
    if(!name.trim()){setError('请填写孩子姓名。');return;}
    if(!Number.isInteger(grade)||grade<1||grade>12){setError('请选择当前年级。');return;}
    if(!subjects.length){setError('请至少保留一个科目。');return;}
    if(!storageRoot.trim()){setError('请填写本地档案保存文件夹。');return;}
    if(needFolderConfirmation&&!folderConfirmed){setError('请确认本地档案保存位置后再保存。');return;}
    setSubmitting(true);setError('');
    try{await onSave({name:name.trim(),grade,selectedSubjects:availableSubjects.filter(s=>subjects.includes(s)),storageRoot:storageRoot.trim()});}catch(e){setError(e instanceof Error?e.message:'设置保存失败，请重试。');}finally{setSubmitting(false);}
  }
  return <dialog ref={dialog} className="student-settings-dialog" aria-labelledby="student-settings-title" onCancel={e=>{e.preventDefault();if(!required&&!busy)onClose();}}>
    <form onSubmit={e=>{e.preventDefault();void save();}}>
      <header className="student-settings-heading"><div><h2 id="student-settings-title">{required?'建立孩子的学习档案':mode==='subjects'?'科目管理':'学生设置'}</h2><p>{required?'先确认孩子信息与保存位置，再开始整理习题。':mode==='subjects'?'选择顶部显示的科目。移除科目会保留已有学习记录。':'可随时修正当前年级，包括留级或复读。'}</p></div>{!required&&<button type="button" className="student-settings-close" aria-label="关闭设置" disabled={busy} onClick={onClose}>×</button>}</header>
      <fieldset disabled={busy}>
        {showProfile&&<><div className="student-settings-fields"><label>孩子姓名<input className="study-input" value={name} maxLength={60} onChange={e=>setName(e.target.value)} autoComplete="off" autoFocus/></label><label>当前年级<select className="study-input" value={grade} onChange={e=>setGrade(Number(e.target.value))}><option value={0} disabled>请选择当前年级</option>{gradeNames.map((label,i)=><option key={label} value={i+1}>{label}</option>)}</select></label></div><p className="student-settings-note">每年 9 月 1 日自动升年级；高三保持不再自动升级，可手动修正。如有留级或复读，请在这里调整。</p></>}
        <section className="student-settings-subjects"><h3>已选科目 <small>{subjects.length} 个</small></h3><div className="student-subject-tags">{subjects.length?availableSubjects.filter(s=>subjects.includes(s)).map(s=><button type="button" className="student-subject-tag is-selected" key={s} aria-label={`移除${s}`} onClick={()=>toggle(s)}>{s}<span aria-hidden="true">×</span></button>):<span className="student-settings-note">尚未选择科目</span>}</div><h3>所有科目</h3><div className="student-subject-tags">{availableSubjects.map(s=><button type="button" key={s} className={`student-subject-tag ${subjects.includes(s)?'is-selected':''}`} aria-pressed={subjects.includes(s)} onClick={()=>toggle(s)}>{s}{subjects.includes(s)&&<span aria-hidden="true">✓</span>}</button>)}</div>{grade>=7&&<><h4>{grade>=10?'高中其他科目':'初中其他科目'} · 待开放</h4><div className="student-subject-tags">{['地理','化学','历史','生物','物理',...(grade>=10?['思想政治']:[])].map(s=><button type="button" disabled className="student-subject-tag" key={s}>{s}</button>)}</div></>}<p className="student-settings-note">其他科目的知识库尚未接入，暂不能选择。</p></section>
        {showProfile&&<section className="student-settings-storage"><h3>本地档案保存位置</h3><div className="student-settings-folder"><input aria-label="本地档案保存文件夹" className="study-input" value={storageRoot} onChange={e=>{setStorageRoot(e.target.value);setFolderConfirmed(false);}} spellCheck={false}/><button type="button" className="study-button study-button-secondary" onClick={()=>void chooseFolder()}>{choosing?'选择中…':'选择文件夹'}</button></div><p className="student-settings-note">照片、错题和练习记录保存在此文件夹。更换位置会复制完整档案并切换使用，原文件夹仍保留。</p>{needFolderConfirmation&&<label className="student-settings-confirm"><input type="checkbox" checked={folderConfirmed} onChange={e=>setFolderConfirmed(e.target.checked)}/>我确认将学习档案保存到上方文件夹</label>}</section>}
      </fieldset>
      {error&&<p className="student-settings-error" role="alert">{error}</p>}
      <footer className="student-settings-actions">{!required&&<button type="button" className="study-button study-button-secondary" disabled={busy} onClick={onClose}>取消</button>}<button className="study-button" disabled={busy} type="submit">{submitting||saving?'正在保存…':required?'确认并开始':'保存设置'}</button></footer>
    </form>
  </dialog>;
}
