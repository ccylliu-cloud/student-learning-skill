import type { QuestionFilters } from '../types';
import type { PcArchive, PcContext, PcFilterKind, PcPaper, PcQuestion, PcVerdict, PcKnowledgeNode } from './model';
export const freshFilters = (): QuestionFilters => ({uploadTime:[],mastery:[],knowledgePoint:[],reason:[]});
export function filterPcQuestions(items:PcQuestion[], filters:QuestionFilters, tree:PcKnowledgeNode[]=[]) {
  return items.filter(q => (!filters.uploadTime.length || filters.uploadTime.includes(q.uploadTime)) && (!filters.mastery.length || filters.mastery.includes(q.mastery)) && (!filters.knowledgePoint.length || filters.knowledgePoint.some(k=>matchesKnowledge(q,k,tree))) && (!filters.reason.length || filters.reason.some(k=>(q.reasons ?? [q.reason]).includes(k))));
}
export function presetFilters(kind:PcFilterKind,value:string) { const f=freshFilters(); if(kind==='mastery') { if(value==='已掌握'||value==='未掌握') f.mastery=[value]; } else f[kind]=[value]; return f; }
export function selectionAfterToggleAll(selected:string[],visible:string[]) { return visible.length && visible.every(id=>selected.includes(id)) ? selected.filter(id=>!visible.includes(id)) : [...new Set([...selected,...visible])]; }
export function filtersForAdd(context:PcContext|undefined,q:PcQuestion,current:QuestionFilters) { if(context?.type==='questions') return structuredClone(context.filters ?? current); if(context?.type==='original'||context?.type==='practice') return {...freshFilters(),uploadTime:[context.sourceDate || q.uploadTime]}; return structuredClone(current); }
export function makePaper(archive:PcArchive,ids:string[],subject:PcQuestion['subject'],id:string,date:string):PcArchive {
  const unique=[...new Set(ids)];const selected=archive.questions.filter(q=>unique.includes(q.id)&&q.subject===subject);
  if(!selected.length)throw Error('请选择组卷题目');
  const paper:PcPaper={id,title:`${subject}复习卷 ${date}`,subject,date,kind:'practice',questionIds:selected.map(q=>q.id),status:'已生成',sources:[],beforeMastery:Object.fromEntries(selected.map(q=>[q.id,q.mastery]))};
  return {...archive,questions:archive.questions.map(q=>paper.questionIds.includes(q.id)?{...q,groupedCount:q.groupedCount+1}:q),papers:[paper,...archive.papers]};
}
export function applyResults(archive:PcArchive,paper:PcPaper,results:Record<string,PcVerdict>,_date:string):PcArchive {
  if(!paper.questionIds.length || paper.questionIds.some(id=>!results[id])) throw Error('尚未收到完整批改结果');
  return {...archive,papers:archive.papers.map(p=>p.id===paper.id?{...p,status:'已批改',savedResults:{...results}}:p)};
}

export function knowledgeLeaves(nodes:PcKnowledgeNode[],id:string):string[]{
 for(const node of nodes){if(node.id===id)return node.children?.length?node.children.flatMap(n=>knowledgeLeaves([n],n.id)):[node.id];const found=knowledgeLeaves(node.children||[],id);if(found.length)return found;}return [];
}
export function matchesKnowledge(q:Pick<PcQuestion,'knowledgeIds'|'knowledgePoints'|'knowledgePoint'>,value:string,tree:PcKnowledgeNode[]){const ids=knowledgeLeaves(tree,value);return ids.some(id=>q.knowledgeIds?.includes(id))||(q.knowledgePoints??[q.knowledgePoint]).includes(value);}
export function knowledgeLabel(nodes:PcKnowledgeNode[],id:string):string{for(const n of nodes){if(n.id===id)return n.label;const found=knowledgeLabel(n.children||[],id);if(found!==id)return found;}return id;}
