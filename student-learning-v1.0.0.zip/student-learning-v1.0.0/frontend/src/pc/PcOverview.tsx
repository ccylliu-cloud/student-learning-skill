import type { PcFilterKind, PcQuestion } from './model';
import PcQuestionCard from './PcQuestionCard';
import { StudyDistributions, StudySummary } from './PcDashboard';
import './overview.css';
import type {KnowledgeNode} from './KnowledgeTree';

type Props = {
  questions: PcQuestion[];
  knowledgeTree?: KnowledgeNode[];
  onFilter: (kind: PcFilterKind, value: string) => void;
  onQuestions: () => void;
  onDashboard: () => void;
  onOpenQuestion: (id: string) => void;
};

export default function PcOverview({ questions, onFilter, onQuestions, onDashboard, onOpenQuestion, knowledgeTree }: Props) {
  return <div className="study-overview-content">
    <section className="study-panel study-overview-summary">
      <div className="study-section-heading"><h2>学习总览</h2></div>
      <StudySummary questions={questions} onFilter={onFilter} />
    </section>
    <section className="study-panel study-overview-questions">
      <div className="study-section-heading">
        <h2>错题库</h2>
        <button type="button" className="study-button study-button-secondary" onClick={onQuestions}>查看全部 <span aria-hidden="true">→</span></button>
      </div>
      {questions.length === 0 ? <p className="study-empty">暂无错题记录</p> : <div className="study-question-stack">
        {questions.slice(0, 3).map((question, index) => <PcQuestionCard key={question.id} question={question} index={index} onOpen={() => onOpenQuestion(question.id)} onTag={onFilter} />)}
      </div>}
    </section>
    <section className="study-panel study-overview-dashboard">
      <div className="study-section-heading">
        <h2>错题仪表盘</h2>
        <button type="button" className="study-button study-button-secondary" onClick={onDashboard}>查看仪表盘 <span aria-hidden="true">→</span></button>
      </div>
      <StudyDistributions questions={questions} onFilter={onFilter} knowledgeTree={knowledgeTree} />
    </section>
  </div>;
}
