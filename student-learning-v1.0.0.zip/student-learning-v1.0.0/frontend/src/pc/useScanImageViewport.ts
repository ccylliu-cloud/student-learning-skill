import {useEffect,useLayoutEffect,useRef,useState} from 'react';
import type {RefObject} from 'react';

type Drag={pointerId:number;x:number;y:number;left:number;top:number;moved:boolean};
const clamp=(value:number,min:number,max:number)=>Math.max(min,Math.min(max,value));

/** View-only interaction: never changes recognition boxes or archive records. */
export function useScanImageViewport(surface:RefObject<HTMLDivElement|null>,viewKey:string,drawing:boolean){
  const viewport=useRef<HTMLDivElement>(null);
  const [zoom,setZoom]=useState(1),[panning,setPanning]=useState(false);
  const zoomRef=useRef(1),drawingRef=useRef(drawing),drag=useRef<Drag|null>(null);
  const suppressClick=useRef(false),clickTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  drawingRef.current=drawing;

  function stopDrag(){
    const old=drag.current;drag.current=null;setPanning(false);
    if(old&&viewport.current?.hasPointerCapture(old.pointerId))viewport.current.releasePointerCapture(old.pointerId);
  }
  function resetView(){
    stopDrag();suppressClick.current=false;
    if(clickTimer.current)clearTimeout(clickTimer.current);
    zoomRef.current=1;setZoom(1);
    if(surface.current)surface.current.style.width='100%';
    viewport.current?.scrollTo({left:0,top:0,behavior:'instant'});
  }
  function zoomTo(next:number,clientX?:number,clientY?:number){
    const el=viewport.current,img=surface.current;
    if(!el||!img||drawingRef.current||drag.current?.moved)return;
    const value=clamp(next,.5,3);if(value===zoomRef.current)return;
    const rect=img.getBoundingClientRect(),view=el.getBoundingClientRect();
    if(!rect.width||!rect.height)return;
    const x=clientX??view.left+el.clientLeft+el.clientWidth/2;
    const y=clientY??view.top+el.clientTop+el.clientHeight/2;
    const u=clamp((x-rect.left)/rect.width,0,1),v=clamp((y-rect.top)/rect.height,0,1);
    // Measure after changing width: auto margins, padding, and scroll bounds all matter.
    // Applying the width synchronously also keeps consecutive native wheel events coherent.
    zoomRef.current=value;img.style.width=`${value*100}%`;setZoom(value);
    const scaled=img.getBoundingClientRect();
    el.scrollLeft+=scaled.left+u*scaled.width-x;
    el.scrollTop+=scaled.top+v*scaled.height-y;
  }
  const zoomToRef=useRef(zoomTo);zoomToRef.current=zoomTo;

  useLayoutEffect(()=>{resetView();},[viewKey]);
  useEffect(()=>{if(drawing)stopDrag();},[drawing]);
  useEffect(()=>{
    const el=viewport.current;if(!el)return;
    function down(e:PointerEvent){
      if(drawingRef.current||!e.isPrimary||e.button!==0||drag.current)return;
      const rect=el!.getBoundingClientRect();
      // Leave native scrollbar interaction alone.
      if(e.clientX>=rect.left+el!.clientLeft+el!.clientWidth||e.clientY>=rect.top+el!.clientTop+el!.clientHeight)return;
      suppressClick.current=false;if(clickTimer.current)clearTimeout(clickTimer.current);
      drag.current={pointerId:e.pointerId,x:e.clientX,y:e.clientY,left:el!.scrollLeft,top:el!.scrollTop,moved:false};
    }
    function move(e:PointerEvent){
      const d=drag.current;if(!d||d.pointerId!==e.pointerId||drawingRef.current)return;
      const dx=e.clientX-d.x,dy=e.clientY-d.y;
      if(!d.moved){
        if(Math.hypot(dx,dy)<6)return;
        d.moved=true;suppressClick.current=true;setPanning(true);
        el!.setPointerCapture(e.pointerId);
      }
      if(e.cancelable)e.preventDefault();
      el!.scrollLeft=d.left-dx;el!.scrollTop=d.top-dy;
    }
    function end(e:PointerEvent){
      if(drag.current?.pointerId!==e.pointerId)return;
      const moved=drag.current.moved;stopDrag();
      if(moved){suppressClick.current=true;clickTimer.current=setTimeout(()=>{suppressClick.current=false;},500);}
    }
    function cancel(e:PointerEvent){
      if(drag.current?.pointerId!==e.pointerId)return;
      stopDrag();suppressClick.current=false;
    }
    function click(e:MouseEvent){
      if(!suppressClick.current)return;
      e.preventDefault();e.stopPropagation();suppressClick.current=false;
    }
    function wheel(e:WheelEvent){
      // A drawing gesture owns the surface; do not pan or zoom behind its coordinates.
      if(e.cancelable)e.preventDefault();
      if(drawingRef.current||drag.current||e.deltaY===0)return;
      const pixels=e.deltaY*(e.deltaMode===1?16:e.deltaMode===2?el!.clientHeight:1);
      zoomToRef.current(zoomRef.current*Math.exp(-clamp(pixels,-120,120)*.0025),e.clientX,e.clientY);
    }
    el.addEventListener('pointerdown',down);
    window.addEventListener('pointermove',move,{passive:false});
    window.addEventListener('pointerup',end);
    window.addEventListener('pointercancel',cancel);
    el.addEventListener('lostpointercapture',cancel);
    el.addEventListener('click',click,true);
    el.addEventListener('wheel',wheel,{passive:false});
    return()=>{
      stopDrag();if(clickTimer.current)clearTimeout(clickTimer.current);
      el.removeEventListener('pointerdown',down);
      window.removeEventListener('pointermove',move);
      window.removeEventListener('pointerup',end);
      window.removeEventListener('pointercancel',cancel);
      el.removeEventListener('lostpointercapture',cancel);
      el.removeEventListener('click',click,true);
      el.removeEventListener('wheel',wheel);
    };
  },[viewKey]);
  return {viewport,zoom,panning,zoomBy:(step:number)=>zoomTo(zoomRef.current+step),resetView};
}
