import type { PcFilterKind, PcQuestion } from './model';
import { questionTags } from './PcQuestionCard';
import './overview.css';
import {KnowledgeDistributionChart} from './KnowledgeTree';
import type {KnowledgeNode} from './KnowledgeTree';

type Props = { questions: PcQuestion[]; knowledgeTree?: KnowledgeNode[]; onFilter: (kind: PcFilterKind, value: string) => void };
type Distribution = { label: string; count: number; mastered: number };
const reasonColors = ['#7d8dca', '#d9aa83', '#81ad97', '#b095c7', '#779faf', '#ce929d', '#b8b475', '#94a2b8'];

export function ReasonPie({ reasons, onFilter }: { reasons: Distribution[]; onFilter: Props['onFilter'] }) {
  const total = reasons.reduce((sum, item) => sum + item.count, 0);
  if (total === 0) return <p className="study-empty">暂无错题原因记录</p>;
  let accumulated = 0;
  const slices = reasons.map((item, index) => {
    const start = accumulated / total * Math.PI * 2 - Math.PI / 2;
    accumulated += item.count;
    const end = accumulated / total * Math.PI * 2 - Math.PI / 2;
    const point = (angle: number) => `${110 + 94 * Math.cos(angle)} ${110 + 94 * Math.sin(angle)}`;
    return {
      ...item,
      percentage: `${(item.count / total * 100).toFixed(1).replace(/\.0$/, '')}%`,
      color: reasonColors[index] ?? `hsl(${Math.round(index * 137.508) % 360} 32% 61%)`,
      path: `M 110 110 L ${point(start)} A 94 94 0 ${end - start > Math.PI ? 1 : 0} 1 ${point(end)} Z`,
    };
  });
  return <div className="study-reason-chart">
    <div className="study-reason-pie-layout">
      <svg className="study-reason-pie" viewBox="0 0 220 220" role="group" aria-label={`错因分布，共 ${total} 个错因标签；${slices.map(item => `${item.label} ${item.count} 题，占 ${item.percentage}`).join('；')}`}>
        {slices.map(item => slices.length === 1
          ? <circle key={item.label} cx="110" cy="110" r="94" fill={item.color} role="button" tabIndex={0} aria-label={`${item.label}，${item.count} 题，查看错题`} onClick={() => onFilter('reason', item.label)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onFilter('reason',item.label);}}}><title>{`${item.label}：${item.count} 题（${item.percentage}）`}</title></circle>
          : <path key={item.label} d={item.path} fill={item.color} stroke="#fff" strokeWidth="2" strokeLinejoin="round" role="button" tabIndex={0} aria-label={`${item.label}，${item.count} 题，查看错题`} onClick={() => onFilter('reason', item.label)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onFilter('reason',item.label);}}}><title>{`${item.label}：${item.count} 题（${item.percentage}）`}</title></path>)}
      </svg>
      <div className="study-reason-pie-legend">
        {slices.map(item => <button type="button" key={item.label} className="study-reason-legend-row" onClick={() => onFilter('reason', item.label)} aria-label={`${item.label}，${item.count} 题，占 ${item.percentage}，查看错题`}>
          <span className="study-reason-swatch" style={{ background: item.color }} aria-hidden="true" />
          <span className="study-reason-name">{item.label}</span>
          <span className="study-reason-share">{item.count} 题 <strong>{item.percentage}</strong></span>
        </button>)}
      </div>
    </div>
    <p className="study-reason-count-note">占比按错因标签总数计算，同题的不同错因分别计入。</p>
  </div>;
}

export function aggregateQuestionTags(questions: PcQuestion[], kind: 'knowledgePoint' | 'reason'): Distribution[] {
  const counts = new Map<string, Distribution>();
  for (const question of questions) {
    for (const label of questionTags(question, kind)) {
      const item = counts.get(label) ?? { label, count: 0, mastered: 0 };
      item.count += 1;
      if (question.mastery === '已掌握') item.mastered += 1;
      counts.set(label, item);
    }
  }
  return [...counts.values()].sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, 'zh-CN'));
}

export function StudySummary({ questions, onFilter }: Props) {
  const mastered = questions.filter(question => question.mastery === '已掌握').length;
  const metrics = [
    { label: '错题', value: questions.length, filter: '全部', tone: 'all' },
    { label: '已掌握', value: mastered, filter: '已掌握', tone: 'mastered' },
    { label: '未掌握', value: questions.length - mastered, filter: '未掌握', tone: 'unmastered' },
  ];
  return <div className="study-summary-grid">
    {metrics.map(metric => <button type="button" className={`study-summary-item study-summary-${metric.tone}`} key={metric.label} onClick={() => onFilter('mastery', metric.filter)}>
      <span className="study-summary-label">{metric.label}</span>
      <span className="study-summary-value">{metric.value}<span>题</span></span>
      <span className="study-summary-arrow" aria-hidden="true">→</span>
    </button>)}
  </div>;
}

export function StudyDistributions({ questions, onFilter, knowledgeTree }: Props) {
  const knowledge = aggregateQuestionTags(questions, 'knowledgePoint');
  const reasons = aggregateQuestionTags(questions, 'reason');
  return <div className={`study-distributions ${knowledgeTree?.length?'has-knowledge-columns':''}`}>
    <section className="study-distribution" aria-label="知识点分布">
      <div className="study-distribution-heading">
        <h3>知识点分布</h3>
        {!knowledgeTree?.length && knowledge.length > 0 && <div className="knowledge-number-legend"><span className="knowledge-number-total">错题总数</span> / <span className="knowledge-number-positive">已掌握</span> / <span className="knowledge-number-unmastered">未掌握</span></div>}
      </div>
      {knowledgeTree?.length ? <KnowledgeDistributionChart nodes={knowledgeTree} questions={questions} onFilter={id=>onFilter('knowledgePoint',id)}/> : knowledge.length === 0 ? <p className="study-empty">暂无知识点记录</p> : <div className="study-distribution-list">
        {knowledge.map(item => <button type="button" key={item.label} className="study-distribution-row knowledge-flat-row" onClick={() => onFilter('knowledgePoint', item.label)} aria-label={`${item.label}，共 ${item.count} 题，已掌握 ${item.mastered} 题，未掌握 ${item.count - item.mastered} 题，查看错题`}>
          <span className="knowledge-node-name" title={item.label}>{item.label}</span>
          <span className="knowledge-inline-counts" aria-hidden="true"><strong className="knowledge-number-total">{item.count}</strong><span className="knowledge-number-divider">/</span><strong className="knowledge-number-positive">{item.mastered}</strong><span className="knowledge-number-divider">/</span><strong className="knowledge-number-unmastered">{item.count-item.mastered}</strong></span>
        </button>)}
      </div>}
    </section>
    <section className="study-distribution" aria-label="错题原因分析">
      <div className="study-distribution-heading"><h3>错题原因分析</h3></div>
      <ReasonPie reasons={reasons} onFilter={onFilter} />
    </section>
  </div>;
}

export default function PcDashboard({ questions, onFilter, knowledgeTree }: Props) {
  return <div className="study-dashboard-content">
    <section className="study-panel study-overview-summary">
      <div className="study-section-heading"><h2>错题概览</h2></div>
      <StudySummary questions={questions} onFilter={onFilter} />
    </section>
    <section className="study-panel study-dashboard-charts">
      <StudyDistributions questions={questions} onFilter={onFilter} knowledgeTree={knowledgeTree} />
    </section>
  </div>;
}
