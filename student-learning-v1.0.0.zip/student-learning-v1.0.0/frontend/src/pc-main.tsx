import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import PcApp from './PcApp';

createRoot(document.getElementById('root')!).render(
  <StrictMode><PcApp /></StrictMode>,
);
