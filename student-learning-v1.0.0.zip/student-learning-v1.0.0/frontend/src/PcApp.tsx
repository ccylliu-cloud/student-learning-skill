import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { FilterKey, MasteryStatus, QuestionFilters } from './types';
import NavigationIcon from './pc/NavigationIcon';
import PcOverview from './pc/PcOverview';
import PcRecognition from './pc/PcRecognition';
import PcAssetImage from './pc/PcAssetImage';
import PcDashboard, {ReasonPie,aggregateQuestionTags} from './pc/PcDashboard';
import {RichQuestion,RichQuestionEditor,QuestionLayoutFields,hasQuestionContent} from './pc/RichQuestion';
import type {QuestionContent,QuestionLayout} from './pc/RichQuestion';
import {KnowledgeTreeFilter,KnowledgeDistributionChart,flattenKnowledge} from './pc/KnowledgeTree';
import PcQuestionCard from './pc/PcQuestionCard';
import StudentSettings,{selectedSubjectNames,gradeNames} from './pc/StudentSettings';
import type {StudentSettingsValue} from './pc/StudentSettings';
import type { PcArchive, PcAsset, PcBox, PcContext, PcFilterKind, PcPaper, PcQuestion, PcRoute, PcSubject, PcVerdict } from './pc/model';
import { applyResults, filterPcQuestions, filtersForAdd, freshFilters, makePaper, presetFilters, selectionAfterToggleAll, knowledgeLabel } from './pc/state';
import './pc/product.css';
import {usePcRuntime,conversationInstruction} from './pc/runtime';
import {CorrectionEvidence,CauseReview,KnowledgeReview} from './pc/AnswerEvidence';
import {scopeArchiveByGrade,hasUnassignedGrade,recordGrade} from './pc/gradeScope';
import type {GradeView} from './pc/gradeScope';
import './pc/gradeScope.css';

type Envelope={archive:PcArchive;revision:string;token:string};
const names:Record<PcRoute['page'],string>={recognition:'错题识别',home:'首页',questions:'错题库',detail:'错题详情',edit:'编辑题目',dashboard:'错题仪表盘',papers:'组卷列表','paper-detail':'组卷详情','practice-results':'复练批改结果','paper-report':'试卷报告',originals:'历史原件','original-view':'查看原件','source-questions':'本次错题'};
const filterNames:Record<FilterKey,string>={uploadTime:'上传时间',mastery:'掌握程度',knowledgePoint:'知识点',reason:'错题原因'};
const fieldNames={fullText:'题干',answer:'答案',analysis:'答案解析'};
const dateToday=()=>new Date().toLocaleDateString('sv-SE').replaceAll('-','.');
const unique=(values:string[])=>[...new Set(values)];
const copyFilters=(f:QuestionFilters)=>structuredClone(f);

export default function PcApp(){
  const runtime=usePcRuntime();
  const conversation=runtime?.capabilities.automaticRecognition===false;
  const [envelope,setEnvelope]=useState<Envelope|null>(null);
  const [loadError,setLoadError]=useState('');
  const [reportConsent,setReportConsent]=useState<string|null>(null);
  const [settingsMode,setSettingsMode]=useState<'profile'|'subjects'|null>(null);
  const [subject,setSubject]=useState<PcSubject>('数学');
  const [gradeView,setGradeView]=useState<GradeView|null>(null);
  const profileGradeRef=useRef<number|null|undefined>(undefined);
  const [stack,setStack]=useState<PcRoute[]>([{page:'home'}]);
  const [filters,setFilters]=useState<QuestionFilters>(freshFilters);
  const [selections,setSelections]=useState<Record<string,string[]>>({});
  const [selectMode,setSelectMode]=useState(false);
  const [showDeletedPapers,setShowDeletedPapers]=useState(false);
  const [draft,setDraft]=useState('');
  const [draftContent,setDraftContent]=useState<QuestionContent>();
  const [draftLayout,setDraftLayout]=useState<QuestionLayout>({});
  const [wordIssues,setWordIssues]=useState<{questionId:string;number:string;message:string}[]>([]);
  const [grading,setGrading]=useState<Record<string,PcVerdict>>({});
  const [saving,setSaving]=useState(false);
  const [message,setMessage]=useState('');
  const [image,setImage]=useState<PcAsset|null>(null);
  const [zoom,setZoom]=useState(1);
  const [recognitionEditing,setRecognitionEditing]=useState(false);
  const [printing,setPrinting]=useState<PcPaper|null>(null);
  const saveLock=useRef(false), timer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  const main=useRef<HTMLElement>(null), imageDialog=useRef<HTMLDialogElement>(null);
  const route=stack[stack.length-1];
  const data=envelope?.archive;
  const viewingGrade:GradeView=gradeView??recordGrade(data?.profile?.grade)??'unknown';
  const scopedData=data?scopeArchiveByGrade(data,viewingGrade):undefined;
  const hasUnknown=!!data&&hasUnassignedGrade(data);
  const subjectHasUnknown=!!data&&hasUnassignedGrade(data,subject);
  const needsSetup=!!data&&(data.profile?.needsSetup===true||data.profile?.onboardingComplete===false);
  const settingsOpen=needsSetup||settingsMode!==null;
  const settingsOpenRef=useRef(settingsOpen);settingsOpenRef.current=settingsOpen;
  const visibleSubjects=selectedSubjectNames(data?.profile);
  const questions=(scopedData?.questions||[]).filter(q=>q.subject===subject);
  const papers=(scopedData?.papers||[]).filter(p=>p.subject===subject);
  const selected=selections[subject]||[];
  const question=data?.questions.find(q=>q.id===route.id&&q.subject===subject);
  const reportDraft=scopedData?.recognition?.groups.find(g=>'scan-original-'+g.id===route.id);
  const basePaper:PcPaper|undefined=papers.find(p=>p.id===route.id)||(reportDraft&&route.page==='paper-report'?{id:'scan-original-'+reportDraft.id,title:reportDraft.title,subject:reportDraft.subject,date:'',kind:'original',questionIds:[],status:'待复核',sources:[],coverage:reportDraft.coverage||'partial',reviewComplete:reportDraft.reviewComplete,totalQuestions:reportDraft.expectedQuestionCount,allQuestions:reportDraft.questions.map(q=>({id:q.canonicalId||q.id,number:q.number,text:q.fullText,verdict:q.verdict||'pending',decisionStatus:q.decisionStatus||'pending',reportResult:q.reportResult,reportInferredCorrect:q.reportInferredCorrect,knowledgeIds:q.knowledgeIds||[],knowledgePoints:q.knowledgePoints,excluded:q.status==='excluded',exclusionKind:q.exclusionKind}))}:undefined);
  const paper:PcPaper|undefined=basePaper&&reportDraft?.reportData?{...basePaper,...reportDraft.reportData}:basePaper;
  const say=(text:string)=>{clearTimeout(timer.current);setMessage(text);timer.current=setTimeout(()=>setMessage(''),5000);};
  const fetchArchive=async()=>{
    const response=await fetch('/api/archive',{cache:'no-store'});const result=await response.json();
    if(!response.ok)throw Error(result.error||'无法读取记录');return result as Envelope;
  };
  useEffect(()=>{let live=true;fetchArchive().then(x=>{if(live)setEnvelope(x)}).catch(e=>{if(live)setLoadError(e.message)});return()=>{live=false;clearTimeout(timer.current);};},[]);
  useEffect(()=>{let live=true;const onFocus=()=>{if(saveLock.current||settingsOpenRef.current||route.page==='edit'||route.page==='practice-results'||recognitionEditing)return;fetchArchive().then(x=>{if(!live||saveLock.current||settingsOpenRef.current)return;setEnvelope(x);setLoadError('');}).catch(()=>{if(live&&!saveLock.current&&!settingsOpenRef.current)setLoadError('本地服务暂未连接，正在重试…');});};window.addEventListener('focus',onFocus);const poll=setInterval(()=>{if(!document.hidden)onFocus();},5000);return()=>{live=false;clearInterval(poll);window.removeEventListener('focus',onFocus);};},[route.page,recognitionEditing,settingsOpen]);
  useEffect(()=>{if(data&&!selectedSubjectNames(data.profile).includes(subject)){setSubject(selectedSubjectNames(data.profile)[0]);setFilters(freshFilters());setSelectMode(false);setStack([{page:'home'}]);}},[data?.profile?.selectedSubjects,subject]);
  useEffect(()=>{if(!data)return;const actual=recordGrade(data.profile?.grade);if(profileGradeRef.current!==actual){profileGradeRef.current=actual;setGradeView(actual??'unknown');clearGradeContext();}},[data?.profile?.grade,!!data]);
  useEffect(()=>{window.scrollTo({top:0,behavior:'instant'});},[stack.length,route.page,route.id]);
  useEffect(()=>{if(image)imageDialog.current?.showModal();else imageDialog.current?.close();},[image]);
  useEffect(()=>{if(!printing)return;let canceled=false;const id=requestAnimationFrame(async()=>{try{const imgs=[...document.querySelectorAll<HTMLImageElement>('.study-print-document img')];await Promise.all(imgs.map(img=>img.complete?(img.naturalWidth?Promise.resolve():Promise.reject(Error('题图加载失败'))):new Promise<void>((resolve,reject)=>{img.onload=()=>resolve();img.onerror=()=>reject(Error('题图加载失败'));})));if(!canceled)window.print();}catch{if(!canceled){setPrinting(null);say('题图未能加载，请重试打印。');}}});const done=()=>setPrinting(null);window.addEventListener('afterprint',done);return()=>{canceled=true;cancelAnimationFrame(id);window.removeEventListener('afterprint',done);};},[printing]);

  async function commit(update:(archive:PcArchive)=>PcArchive):Promise<boolean>{
    if(!envelope||saveLock.current)return false;
    saveLock.current=true;setSaving(true);
    try{const response=await fetch('/api/archive',{method:'POST',headers:{'Content-Type':'application/json','If-Match':envelope.revision,'X-Pc-Token':envelope.token},body:JSON.stringify(update(envelope.archive))});const result=await response.json();
      if(!response.ok){if(response.status===409)setEnvelope(await fetchArchive());throw Error(result.error||'保存失败');}setEnvelope(result);return true;
    }catch(e){say(e instanceof Error?e.message:'保存失败');return false;}finally{saveLock.current=false;setSaving(false);}
  }
  async function supplement(groupId:string,pageId:string,box:PcBox,requestId:string):Promise<boolean>{
    if(!envelope||saveLock.current)return false;
    saveLock.current=true;setSaving(true);
    try{
      const response=await fetch('/api/recognition/supplement',{method:'POST',headers:{'Content-Type':'application/json','If-Match':envelope.revision,'X-Pc-Token':envelope.token},body:JSON.stringify({groupId,pageId,box,requestId})});
      const result=await response.json();
      if(!response.ok){if(response.status===409)setEnvelope(await fetchArchive());throw Error(result.error||'补充题识别请求未能提交');}
      setEnvelope(result);if(conversation)say(conversationInstruction);return true;
    }catch(e){say(e instanceof Error?e.message:'补充题识别请求未能提交');return false;}
    finally{saveLock.current=false;setSaving(false);}
  }
  function clearGradeContext(){
    setSelections({});setFilters(freshFilters());setSelectMode(false);setGrading({});setWordIssues([]);setShowDeletedPapers(false);setImage(null);setPrinting(null);
    const topPages:PcRoute['page'][]=['home','questions','recognition','dashboard','papers','originals'];
    setStack([{page:topPages.includes(route.page)?route.page:activeSection}]);
  }
  function changeViewingGrade(next:GradeView){
    if(saving||saveLock.current||settingsOpen)return;
    if(recognitionEditing||route.page==='edit'||route.page==='practice-results'){say('请先保存或取消当前修改，再切换查看年级。');return;}
    if(next===viewingGrade)return;
    setGradeView(next);clearGradeContext();
  }
  function openSettings(mode:'profile'|'subjects'){
    if(saving||saveLock.current)return;
    if(recognitionEditing||route.page==='edit'||route.page==='practice-results'){say('请先保存或取消当前修改，再打开设置。');return;}
    settingsOpenRef.current=true;setSettingsMode(mode);
  }
  async function saveSettings(value:StudentSettingsValue){
    if(!envelope||saveLock.current)throw Error('正在保存其他修改，请稍后重试。');
    saveLock.current=true;setSaving(true);
    try{
      const response=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json','If-Match':envelope.revision,'X-Pc-Token':envelope.token},body:JSON.stringify(value)});
      const result=await response.json();
      if(!response.ok){if(response.status===409)setEnvelope(await fetchArchive());throw Error(result.error||'设置保存失败，请重试。');}
      setEnvelope(result);setLoadError('');setFilters(freshFilters());setSelectMode(false);
      const nextSubjects=selectedSubjectNames(result.archive.profile);
      if(!nextSubjects.includes(subject)){setSubject(nextSubjects[0]);setStack([{page:'home'}]);}
      setSettingsMode(null);say('设置已保存。');
    }finally{saveLock.current=false;setSaving(false);}
  }
  async function chooseSettingsFolder(){
    const response=await fetch('/api/settings/choose-folder',{method:'POST',headers:{'Content-Type':'application/json','X-Pc-Token':envelope?.token||''},body:'{}'});
    const result=await response.json();if(!response.ok)throw Error(result.error||'无法选择文件夹，请直接填写路径。');return result.path as string|null;
  }
  const navigate=(next:PcRoute)=>setStack(old=>[...old,next]);
  async function finishEdit(cancel=false){
    if(!question||!route.field)return true;
    if(!cancel&&(draft!==(question[route.field]||'')||route.field==='fullText'&&(JSON.stringify(draftContent)!==JSON.stringify(question.content)||JSON.stringify(draftLayout)!==JSON.stringify({sectionTitle:question.sectionTitle,sharedContext:question.sharedContext,answerLayout:question.answerLayout})))){
      if(route.field==='fullText'?!hasQuestionContent(draftContent,draft):!draft.trim()){say('内容不能为空；题干可以填写文字或插入题图。');return false;}
      const field=route.field;
      const ok=await commit(a=>({...a,questions:a.questions.map(q=>q.id===question.id?{...q,[field]:draft.trim(),...(field==='fullText'?{title:draft.trim()||q.title||'图片题',content:draftContent,...draftLayout}: {})}:q)}));if(!ok)return false;
    }return true;
  }
  async function setPaperDeleted(paper:PcPaper,deleted:boolean){
    if(deleted&&!window.confirm(`删除“${paper.title}”？这份组卷会移入“已删除”，可以随时恢复。错题详情和已有复练记录都会保留。`))return;
    const ok=await commit(a=>({...a,papers:a.papers.map(p=>p.id===paper.id?{...p,deleted}:p)}));
    if(ok)say(deleted?'组卷已移入已删除，可随时恢复。':'组卷已恢复。');
  }
  async function back(cancel=false){if(recognitionEditing){say('请先保存或取消识别内容修改。');return;}if(route.page==='edit'&&!await finishEdit(cancel))return;setStack(old=>old.length>1?old.slice(0,-1):[{page:'home'}]);}
  async function mainNavigate(page:PcRoute['page']){if(recognitionEditing){say('请先保存或取消识别内容修改。');return;}if(route.page==='edit'&&!await finishEdit())return;setStack([{page}]);if(page==='questions')setFilters(freshFilters());}
  async function changeSubject(next:PcSubject){if(recognitionEditing){say('请先保存或取消识别内容修改。');return;}if(next===subject)return;if(route.page==='edit'&&!await finishEdit())return;setSubject(next);setFilters(freshFilters());setSelectMode(false);const destination=(['home','questions','dashboard','papers','originals','recognition'] as PcRoute['page'][]).includes(route.page)?route.page:'home';setStack([{page:destination}]);}
  function filterFrom(kind:PcFilterKind,value:string){if(kind==='knowledgePoint')value=flattenKnowledge(data?.knowledgeTree?.[subject]||[]).find(n=>!n.children?.length&&n.label===value)?.id||value;setFilters(presetFilters(kind,value));navigate({page:'questions',sourceId:route.page==='paper-report'&&paper?.kind==='original'?paper.id:route.sourceId});}
  function tagFilter(kind:'knowledgePoint'|'reason',value:string){if(kind==='knowledgePoint')value=flattenKnowledge(data?.knowledgeTree?.[subject]||[]).find(n=>!n.children?.length&&n.label===value)?.id||value;setFilters(f=>({...f,[kind]:[value]}));}
  function toggleFilter(key:FilterKey,value:string){setFilters(f=>({...f,[key]:(f[key] as string[]).includes(value)?f[key].filter(x=>x!==value):[...f[key],value]}));}
  function openQuestion(q:PcQuestion,context:PcContext){navigate({page:'detail',id:q.id,context});}
  const setSelected=(ids:string[])=>setSelections(old=>({...old,[subject]:ids}));
  function toggleQuestion(id:string){setSelected(selected.includes(id)?selected.filter(x=>x!==id):[...selected,id]);}
  function addToPaper(q:PcQuestion){
    setSelected(unique([...selected,q.id]));setSelectMode(true);setFilters(filtersForAdd(route.context,q,filters));
    const existing=stack.map(r=>r.page).lastIndexOf('questions');setStack(old=>existing>=0?[...old.slice(0,existing+1)]:[{page:'home'},{page:'questions'}]);say('已加入组卷选择，可以继续勾选其他题目。');
  }
  async function generatePaper(){
    const id=crypto.randomUUID();const ok=await commit(a=>{const next=makePaper(a,selected,subject,id,dateToday());return viewingGrade==='all'?next:{...next,papers:next.papers.map(p=>p.id===id?{...p,grade:viewingGrade==='unknown'?null:viewingGrade}:p)};});
    if(ok){setSelectMode(false);setSelected([]);navigate({page:'paper-detail',id});}
  }
  async function editTags(q:PcQuestion,key:'mastery'|'knowledgePoints'|'reasons',value:MasteryStatus|string[]){
    await commit(a=>({...a,questions:a.questions.map(item=>item.id===q.id?{...item,[key]:value,...(key==='knowledgePoints'?{knowledgePoint:(value as string[])[0]}:key==='reasons'?{reason:(value as string[])[0]}:{})}:item)}));
  }
  function startResults(p:PcPaper){setGrading({...p.results,...p.savedResults});navigate({page:'practice-results',id:p.id});}
  async function saveResults(p:PcPaper){if(!data)return;const ok=await commit(a=>applyResults(a,p,grading,dateToday()));if(ok){say('已保存批改结果。');setStack(old=>[...old.slice(0,-1),{page:'paper-report',id:p.id}]);}}
  async function download(p:PcPaper){
    try{setSaving(true);setWordIssues([]);const check=await fetch('/api/archive/check-word/'+encodeURIComponent(p.id),{headers:{'X-Pc-Token':envelope?.token||''}});const checked=await check.json();if(!check.ok)throw Error(checked.error||'无法检查题面');if(checked.issues?.length){setWordIssues(checked.issues);throw Error('请先补齐下方列出的题面，再生成 Word。');}const response=await fetch('/api/archive/word/'+encodeURIComponent(p.id),{headers:{'X-Pc-Token':envelope?.token||''}});if(!response.ok){const err=await response.json();throw Error(err.error||'Word 生成失败');}const blob=await response.blob();const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=p.title+'.docx';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);say('Word 文件已生成。');}catch(e){say(e instanceof Error?e.message:'生成失败');}finally{setSaving(false);}
  }
  async function confirmDiagram(q:PcQuestion){
    if(!q.diagramReviewRequired||saving)return;
    const ok=await commit(a=>({...a,questions:a.questions.map(item=>item.id===q.id?{...item,diagramReviewConfirmed:true}:item)}));
    if(ok)say('题图核对已保存。');
  }
  function openImage(asset:PcAsset){setZoom(1);setImage(asset);}
  const filterOptions:Record<FilterKey,string[]>={uploadTime:unique(questions.map(q=>q.uploadTime)).sort().reverse(),mastery:['未掌握','已掌握'],knowledgePoint:unique(questions.flatMap(q=>q.knowledgePoints??[q.knowledgePoint])),reason:unique(questions.flatMap(q=>q.reasons??[q.reason]))};
  const paperQuestions=(p:PcPaper)=>p.questions||p.questionIds.map(id=>data?.questions.find(q=>q.id===id)).filter((q):q is PcQuestion=>!!q);
  const knowledgeTree=data?.knowledgeTree?.[subject]||[];
  function reportGroup(id:string){
    const group=data?.recognition?.groups.find(g=>g.id===id);if(!group)return;
    if(group.reportData||group.coverage==='full'||['queued','running','awaiting_conversation'].includes(group.reportTask?.status||''))navigate({page:'paper-report',id:'scan-original-'+id});
    else setReportConsent(id);
  }
  function openPaperReport(p:PcPaper){
    const g=data?.recognition?.groups.find(g=>'scan-original-'+g.id===p.id&&g.kind!=='practice');
    if(g)reportGroup(g.id);else navigate({page:'paper-report',id:p.id});
  }
  async function requestReport(){
    if(!envelope||!reportConsent||saveLock.current)return;
    const gid=reportConsent;saveLock.current=true;setSaving(true);
    try{
      const response=await fetch('/api/recognition/report',{method:'POST',headers:{'Content-Type':'application/json','If-Match':envelope.revision,'X-Pc-Token':envelope.token},body:JSON.stringify({groupId:gid,requestId:crypto.randomUUID(),consent:true})});
      const result=await response.json();if(!response.ok){if(response.status===409)setEnvelope(await fetchArchive());throw Error(result.error||'整卷分析未能启动');}
      setEnvelope(result);setReportConsent(null);navigate({page:'paper-report',id:'scan-original-'+gid});
    }catch(e){say(e instanceof Error?e.message:'整卷分析未能启动');}finally{saveLock.current=false;setSaving(false);}
  }
  function composeGroup(id:string){const originalId='scan-original-'+id;setSelected(questions.filter(q=>q.originalId===originalId).map(q=>q.id));setSelectMode(true);setFilters(freshFilters());navigate({page:'questions',sourceId:originalId});}
  const listCard=(q:PcQuestion,index:number,context:PcContext,showAnswer=false)=><PcQuestionCard showAnswer={showAnswer} key={q.id} question={q} index={index} onOpen={()=>openQuestion(q,context)} onTag={(kind,value)=>filterFrom(kind,value)}/>;
  const activeSection=route.page==='recognition'?'recognition':route.page==='home'?'home':['papers','paper-detail','practice-results'].includes(route.page)||route.page==='paper-report'&&paper?.kind==='practice'?'papers':['originals','original-view','source-questions'].includes(route.page)||route.page==='paper-report'&&paper?.kind==='original'?'originals':route.page==='dashboard'?'dashboard':'questions';

  function renderPage(){
    if(!data)return <div className="study-empty">{loadError||'正在读取学习记录…'}</div>;
    if(route.page==='recognition')return <PcRecognition runtime={runtime} onSupplement={supplement} key={`${subject}:${viewingGrade}`} archive={scopedData!} subject={subject} saving={saving} commit={commit} say={say} onEditing={setRecognitionEditing} token={envelope?.token} onPracticeResults={id=>{const p=data.papers.find(p=>p.id===id&&p.kind==='practice');if(p)startResults(p);}} onReport={reportGroup} onCompose={composeGroup} onQuestions={()=>{setFilters(freshFilters());navigate({page:'questions'});}}/>;
    if(route.page==='home')return <PcOverview knowledgeTree={knowledgeTree} questions={questions} onFilter={filterFrom} onQuestions={()=>{setFilters(freshFilters());navigate({page:'questions'})}} onDashboard={()=>navigate({page:'dashboard'})} onOpenQuestion={id=>{const q=questions.find(x=>x.id===id);if(q)openQuestion(q,{type:'home'})}}/>;
    if(route.page==='dashboard')return <PcDashboard questions={questions} onFilter={filterFrom} knowledgeTree={knowledgeTree}/>;
    if(route.page==='questions'){
      const visible=filterPcQuestions(questions.filter(q=>!route.sourceId||q.originalId===route.sourceId),filters,knowledgeTree);const allSelected=visible.length>0&&visible.every(q=>selected.includes(q.id));
      return <><section className="study-panel"><div className="study-filters">{(Object.keys(filterNames) as FilterKey[]).map(key=><details className="study-filter" key={key}><summary>{filterNames[key]}{filters[key].length>0&&<span>{filters[key].length}</span>}<b>⌄</b></summary><fieldset><legend className="study-sr-only">{filterNames[key]}</legend>{key==='knowledgePoint'&&knowledgeTree.length?<><KnowledgeTreeFilter nodes={knowledgeTree} selected={filters.knowledgePoint} onChange={ids=>setFilters(f=>({...f,knowledgePoint:ids}))}/>{filterOptions.knowledgePoint.filter(label=>!flattenKnowledge(knowledgeTree).some(n=>n.label===label)).map(label=><label key={label}><input type="checkbox" checked={filters.knowledgePoint.includes(label)} onChange={()=>toggleFilter('knowledgePoint',label)}/>{label}（待映射）</label>)}</>:filterOptions[key].length?filterOptions[key].map(value=><label key={value}><input type="checkbox" checked={(filters[key] as string[]).includes(value)} onChange={()=>toggleFilter(key,value)}/>{value}</label>):<p>暂无可选记录</p>}</fieldset></details>)}</div>{Object.values(filters).some(v=>v.length>0)&&<div className="study-filter-chips">{(Object.keys(filterNames) as FilterKey[]).flatMap(key=>filters[key].map(value=><button className="study-tag" key={key+value} onClick={()=>toggleFilter(key,value)}>{filterNames[key]}：{key==='knowledgePoint'?knowledgeLabel(knowledgeTree,value):value} ×</button>))}<button className="study-link" onClick={()=>setFilters(freshFilters())}>清空筛选</button></div>}</section>
        <section className="study-panel"><div className="study-section-heading"><h2>{route.sourceId?'本次错题':'错题库'}</h2><span className="study-muted">共 {visible.length} 题</span></div><div className="study-question-list">{visible.length?visible.map((q,i)=><PcQuestionCard key={q.id} question={q} index={i} selectMode={selectMode} selected={selected.includes(q.id)} onSelect={()=>toggleQuestion(q.id)} onOpen={()=>openQuestion(q,{type:'questions',filters:copyFilters(filters)})} onTag={tagFilter}/>):<Empty>当前筛选下没有错题。</Empty>}</div></section>
        <div className="study-selection-bar"><span>{selectMode?`已选择 ${selected.length} 题${selected.some(id=>!visible.some(q=>q.id===id))?'（含当前筛选外的题目）':''}`:'选择错题，组成一份复习卷'}</span><div>{selectMode?<><button className="study-button study-button-secondary" onClick={()=>setSelectMode(false)}>退出勾选</button><button className="study-button study-button-secondary" onClick={()=>setSelected(selectionAfterToggleAll(selected,visible.map(q=>q.id)))} disabled={!visible.length}>{allSelected?'取消全选':'全选'}</button><button className="study-button" disabled={!selected.length||saving} onClick={generatePaper}>已选择 {selected.length} 题，生成组卷</button></>:<button className="study-button" disabled={!questions.length} onClick={()=>setSelectMode(true)}>请选择组卷题目</button>}</div></div></>;
    }
    if(route.page==='detail'&&question)return <div className="study-detail-layout"><div><Panel title="原题图片"><Images assets={question.images||[]} onOpen={openImage}/></Panel>{question.diagramReviewRequired&&<Panel title="待核对题图"><Images assets={diagramAssets(question)} onOpen={openImage}/><p className="study-prose">请对照原题图片逐项核对图形、尺寸、标注与条件。题图核对与确认正误分开，核对后才能用于练习卷。</p><button className="study-button" disabled={saving||!diagramAssets(question).length} onClick={()=>void confirmDiagram(question)}>我已对照原图核对题图</button></Panel>}<Panel title="题干" action={<button className="study-link" onClick={()=>{setDraft(question.fullText);setDraftContent(question.content);setDraftLayout({sectionTitle:question.sectionTitle,sharedContext:question.sharedContext,answerLayout:question.answerLayout});navigate({...route,page:'edit',field:'fullText'})}}>编辑题干</button>}><RichQuestion {...question}/>{question.studentAnswer&&<><h3 style={{marginTop:22,marginBottom:8}}>学生作答</h3><p className="study-prose">{question.studentAnswer}</p></>}<CorrectionEvidence correctedAnswer={question.correctedAnswer} answerEvidence={question.answerEvidence}/></Panel><Panel title="答案" action={<button className="study-link" onClick={()=>{setDraft(question.answer||'');navigate({...route,page:'edit',field:'answer'})}}>编辑答案</button>}><p className="study-prose">{question.answer||'暂未记录答案'}</p></Panel><Panel title="答案解析" action={<button className="study-link" onClick={()=>{setDraft(question.analysis||'');navigate({...route,page:'edit',field:'analysis'})}}>编辑解析</button>}><p className="study-prose">{question.analysis||'暂未记录解析'}</p></Panel><Panel title="错因分析"><CauseReview status={question.causeStatus} hasCause={!!question.causeAnalysis||!!question.reasons?.length}/><p className="study-prose">{question.causeAnalysis||'暂未记录具体错因分析'}</p></Panel></div><aside><Panel title="标签"><label className="study-form-label" htmlFor="mastery">掌握程度</label><select id="mastery" className="study-input" value={question.mastery} disabled={saving} onChange={e=>void editTags(question,'mastery',e.target.value as MasteryStatus)}><option>未掌握</option><option>已掌握</option></select>{knowledgeTree.length?<div className="study-tag-editor"><h3>知识点</h3><KnowledgeReview value={question.knowledgeValidation}/><KnowledgeTreeFilter nodes={knowledgeTree} selected={question.knowledgeIds||[]} leafOnly max={3} disabled={saving} onChange={ids=>void commit(a=>({...a,questions:a.questions.map(q=>q.id===question.id?{...q,knowledgeIds:ids,knowledgePoints:ids.map(id=>knowledgeLabel(knowledgeTree,id))}:q)}))}/>{!question.knowledgeIds?.length&&<p className="study-muted">{question.knowledgePoints?.join('、')} · 待映射</p>}</div>:<TagEditor title="知识点" values={question.knowledgePoints??[question.knowledgePoint]} options={unique([...(data.knowledgeOptions?.[subject]||[]),...filterOptions.knowledgePoint])} max={3} disabled={saving} onChange={values=>void editTags(question,'knowledgePoints',values)}/>}<TagEditor title="错题原因" values={question.reasons??[question.reason]} options={unique([...(data.causeOptions?.[subject]||[]),...filterOptions.reason])} max={2} disabled={saving} onChange={values=>void editTags(question,'reasons',values)}/></Panel><Panel title="练习记录">{question.attempts?.length?<ol className="study-attempts">{question.attempts.map(a=><li key={a.id}><strong>{a.result==='correct'?'对':'错'}</strong><time>{a.date}</time><p>{a.label}</p>{a.answer&&<p>{a.answer}</p>}</li>)}</ol>:<p className="study-muted">暂未保存详细练习记录。</p>}<p className="study-muted">错 {question.wrongCount} 次 · 对 {question.correctCount} 次 · 组卷 {question.groupedCount} 次</p><button className="study-button study-full" onClick={()=>addToPaper(question)}>加入组卷</button></Panel></aside></div>;
    if(route.page==='edit'&&question&&route.field)return <div className="study-editor-layout"><Panel title="题图参考"><Images assets={question.images||[]} onOpen={openImage}/><p className="study-muted">{question.fullText}</p></Panel><Panel title={`编辑${fieldNames[route.field]}`}><label className="study-sr-only" htmlFor="question-editor">{fieldNames[route.field]}</label>{route.field==='fullText'?<><RichQuestionEditor content={draftContent} fullText={draft} token={envelope?.token} onChange={(c,t)=>{setDraftContent(c);setDraft(t);}} disabled={saving} onBusy={setRecognitionEditing}/><QuestionLayoutFields value={draftLayout} onChange={setDraftLayout}/></>:<textarea id="question-editor" className="study-editor" value={draft} onChange={e=>setDraft(e.target.value)} rows={route.field==='answer'?7:14}/>}<div className="study-actions"><button className="study-button study-button-secondary" onClick={()=>void back(true)} disabled={saving}>取消</button><button className="study-button" onClick={()=>void back()} disabled={saving}>保存</button></div></Panel></div>;
    if(route.page==='papers'){
      const listed=papers.filter(p=>p.kind==='practice'&&!!p.deleted===showDeletedPapers);
      const deletedCount=papers.filter(p=>p.kind==='practice'&&p.deleted).length;
      return <div className="study-paper-list"><div className="study-actions"><button className="study-button study-button-secondary" aria-pressed={showDeletedPapers} onClick={()=>setShowDeletedPapers(v=>!v)}>{showDeletedPapers?'返回组卷列表':`查看已删除（${deletedCount}）`}</button></div>{showDeletedPapers&&<p className="study-muted">删除的组卷保留原有题目和复练记录，可随时恢复。</p>}{listed.length?listed.map(p=>{const results=p.savedResults;const correct=Object.values(results||{}).filter(v=>v==='correct').length;return <Panel key={p.id} title={p.title}><div className="study-info-grid"><Info label="题目数" value={`${p.questionIds.length} 题`}/><Info label="状态" value={p.deleted?'已删除':p.status}/><Info label="正确率" value={results&&p.questionIds.length?`${Math.round(correct/p.questionIds.length*100)}%`:'待上传复练结果'}/></div><div className="study-actions"><button className="study-button" onClick={()=>navigate({page:'paper-detail',id:p.id})}>组卷详情</button><button className="study-button study-button-secondary" onClick={()=>openPaperReport(p)}>试卷报告</button><button className="study-button study-button-secondary" disabled={saving} onClick={()=>void setPaperDeleted(p,!p.deleted)}>{p.deleted?'恢复组卷':'删除组卷'}</button></div></Panel>}):<Empty>{showDeletedPapers?'没有已删除的组卷。':'还没有生成复习卷。可在错题库选择题目后组卷。'}</Empty>}</div>;
    }
    if(route.page==='paper-detail'&&paper){const qs=paperQuestions(paper);return <><div className="study-two-columns"><Panel title="试卷信息"><Info label="学科" value={paper.subject}/><Info label="年级" value={paper.grade?gradeNames[paper.grade-1]||'未分年级':'未分年级'}/><Info label="题目数" value={`${qs.length} 题`}/><Info label="状态" value={paper.status}/></Panel><Panel title="本卷题目统计"><p>共 {qs.length} 题</p><p>未掌握 {qs.filter(q=>q.mastery==='未掌握').length} 题 · 已掌握 {qs.filter(q=>q.mastery==='已掌握').length} 题</p><div className="study-tag-list">{unique(qs.flatMap(q=>q.knowledgePoints??[q.knowledgePoint])).map(k=><button className="study-tag" key={k} onClick={()=>filterFrom('knowledgePoint',k)}>{k}</button>)}</div></Panel></div><Panel title="卷内题目">{wordIssues.length>0&&<div className="study-field-error"><strong>需要补齐题面</strong>{wordIssues.map(issue=><p key={issue.questionId}>{issue.number}：{issue.message} <button className="study-link" onClick={()=>{const q=data.questions.find(q=>q.id===issue.questionId);if(q)openQuestion(q,{type:'practice',sourceId:paper.id});}}>编辑题面 / 粘贴题图</button></p>)}</div>}{qs.map((q,i)=>listCard(q,i,{type:'practice',sourceId:paper.id,sourceDate:q.uploadTime},true))}</Panel><div className="study-actions study-bottom-actions"><button className="study-button study-button-secondary" onClick={()=>void download(paper)} disabled={saving||!qs.length}>生成 Word</button><button className="study-button study-button-secondary" onClick={()=>{if(qs.some(q=>(q.requiresImage&&!q.cleanImages?.length&&!q.content?.blocks.some(b=>b.type==='image'))||/\\(?:frac|sqrt|begin)|\$\$/.test(q.fullText))){say('本卷包含题图或复杂公式，请在 Codex 对话中确认打印版式。');return;}setPrinting(paper);}} disabled={!qs.length}>打印</button><button className="study-button" onClick={()=>startResults(paper)}>查看批改结果</button></div></>}
    if(route.page==='originals')return <div className="study-paper-list">{papers.filter(p=>p.kind==='original').length?papers.filter(p=>p.kind==='original').map(p=><Panel title={p.title} key={p.id}><div className="study-info-grid"><Info label="原件图片" value={p.sources.length?`${p.sources.length} 页`:'暂未保存'}/><Info label="已加入错题" value={`${p.questionIds.length} 题`}/><Info label="上传时间" value={p.date}/></div><div className="study-actions"><button className="study-button study-button-secondary" onClick={()=>navigate({page:'original-view',id:p.id})}>查看原件</button><button className="study-button study-button-secondary" onClick={()=>navigate({page:'source-questions',id:p.id})}>本次错题</button><button className="study-button" onClick={()=>openPaperReport(p)}>试卷报告</button></div></Panel>):<Empty>当前学科还没有历史原件。</Empty>}</div>;
    if(route.page==='original-view'&&paper)return <><div className="study-actions study-top-actions"><button className="study-button study-button-secondary" onClick={()=>navigate({page:'source-questions',id:paper.id})}>查看识别错题</button><button className="study-button" onClick={()=>openPaperReport(paper)}>查看试卷报告</button></div><Panel title={paper.title}><Images assets={paper.sources} onOpen={openImage}/></Panel></>;
    if(route.page==='source-questions'&&paper)return <Panel title={paper.title}><p className="study-muted">本次共保存 {paper.questionIds.length} 道错题</p>{paperQuestions(paper).map((q,i)=>listCard(q,i,{type:'original',sourceId:paper.id,sourceDate:paper.date}))}</Panel>;
    if(route.page==='practice-results'&&paper){const qs=paperQuestions(paper);const complete=qs.length>0&&qs.every(q=>grading[q.id]);const hasResults=Object.keys(grading).length>0||Object.keys(paper.resultDetails||{}).length>0;return <><Panel title="卷面批改">{paper.resultDate&&<p className="study-muted">作答日期：{paper.resultDate}</p>}<Images assets={paper.sources} onOpen={openImage}/></Panel><Panel title="批改结果">{hasResults?<><div className="study-result-summary"><span>正确 <strong>{qs.filter(q=>grading[q.id]==='correct').length}</strong> 题</span><span>错误 <strong>{qs.filter(q=>grading[q.id]==='incorrect').length}</strong> 题</span><span>待确认 <strong>{qs.filter(q=>!grading[q.id]).length}</strong> 题</span></div>{qs.map((q,i)=><article className="study-result-question" key={q.id}><h3>第 {i+1} 题</h3><RichQuestion content={q.content} fullText={q.fullText} sectionTitle={q.sectionTitle} sharedContext={q.sharedContext}/><h4>本次作答</h4><p className="study-prose">{paper.resultDetails?.[q.id]?.answer||'未记录可辨认的作答'}</p><h4>正确答案</h4><p className="study-prose">{q.answer||'暂未记录答案'}</p>{q.analysis&&<><h4>答案解析</h4><p className="study-prose">{q.analysis}</p></>}<label>本次判定 <select value={grading[q.id]||''} onChange={e=>setGrading(g=>{const next={...g};if(e.target.value)next[q.id]=e.target.value as PcVerdict;else delete next[q.id];return next;})}><option value="">待确认</option><option value="correct">正确</option><option value="incorrect">错误</option></select></label></article>)}</>:<Empty>尚未收到这份复习卷的批改结果。</Empty>}<button className="study-button" disabled={!complete||saving} onClick={()=>void saveResults(paper)}>保存批改结果</button></Panel></>}

    if(route.page==='paper-report'&&reportDraft&&!reportDraft.reportData&&reportDraft.coverage!=='full'){
      const task=reportDraft.reportTask,busy=task?.status==='queued'||task?.status==='running',waiting=task?.status==='awaiting_conversation';
      return <Panel title={waiting?'等待对话生成报告':busy?'整卷分析中':'整卷报告尚未生成'}><p role="status" className="study-prose">{waiting?conversationInstruction:busy?(task.progress?.message||'正在识别整卷题目与知识点，可离开本页，完成后再查看。'):task?.error||'当前只识别了错题候选，还没有读取其余题目，因此暂不计算整卷正确率。'}</p>{!busy&&!waiting&&<button className="study-button" disabled={saving} onClick={()=>setReportConsent(reportDraft.id)}>{task?.resultRecovery?.available?'重试保存报告':conversation?'在对话中生成报告':'生成整卷报告'}</button>}<button className="study-button study-button-secondary" onClick={()=>navigate({page:'recognition'})}>返回错题识别</button></Panel>;
    }
    if(route.page==='paper-report'&&paper)return <>{reportDraft?.reportData?.notes?.map((n,i)=><p className="study-muted" key={i}>{n}</p>)}<PaperReport knowledgeTree={knowledgeTree} paper={paper} questions={paperQuestions(paper)} onFilter={filterFrom} onQuestion={q=>openQuestion(q,{type:paper.kind==='original'?'original':'practice',sourceId:paper.id,sourceDate:paper.kind==='original'?paper.date:q.uploadTime})}/></>;
    return <Empty>当前记录不存在，请返回上一级查看。</Empty>;
  }

  return <div className="study-app"><a className="study-skip" href="#study-main">跳到主要内容</a><aside className="study-sidebar"><div className="study-brand"><span><NavigationIcon name="brand"/></span><strong>学习记录册</strong></div>{data&&<div className="study-student"><div><strong>{data.profile?.name||'学习档案'}</strong><div className="student-grade-control"><select id="viewing-grade" aria-label="查看年级" value={viewingGrade} disabled={saving||settingsOpen} onChange={e=>changeViewingGrade(e.target.value==='all'||e.target.value==='unknown'?e.target.value:Number(e.target.value))}>{gradeNames.map((label,i)=><option key={label} value={i+1}>{label}</option>)}{(hasUnknown||viewingGrade==='unknown')&&<option value="unknown">未分年级</option>}<option value="all">全部年级</option></select><span aria-hidden="true">⌄</span></div></div></div>}<nav aria-label="主要导航">{([{page:'home',label:'首页'},{page:'questions',label:'错题库'},{page:'recognition',label:'错题识别'},{page:'dashboard',label:'错题仪表盘'},{page:'papers',label:'组卷列表'},{page:'originals',label:'历史原件'}] as const).map(n=><button type="button" aria-current={activeSection===n.page?'page':undefined} className={activeSection===n.page?'is-active':''} key={n.page} onClick={()=>void mainNavigate(n.page)}><NavigationIcon name={n.page}/>{n.label}</button>)}<button type="button" onClick={()=>openSettings('profile')} disabled={saving}><span className="student-settings-nav-icon" aria-hidden="true">⚙</span>学生设置</button></nav><div className="study-sidebar-footer">个人学习记录</div></aside><div className="study-workspace"><header className="study-topbar"><div><strong>{names[route.page]}</strong><span className="study-version">本地档案{runtime?` · ${runtime.version}`:''}</span></div><div className="study-subjects" role="group" aria-label="学科">{visibleSubjects.map(s=><button key={s} aria-pressed={subject===s} className={subject===s?'is-active':''} onClick={()=>void changeSubject(s)}>{s}</button>)}<button type="button" className="student-add-subject" aria-label="科目管理" title="科目管理" disabled={saving} onClick={()=>openSettings('subjects')}>＋</button></div></header><main className="study-main" id="study-main" ref={main}><div className="study-page-heading"><div>{stack.length>1&&<button className="study-back" onClick={()=>void back()} disabled={saving}>← 返回</button>}<h1>{route.page==='edit'&&route.field?`编辑${fieldNames[route.field]}`:route.page==='home'?`${subject}学习记录`:names[route.page]}</h1>{paper&&route.page!=='original-view'&&<p className="study-muted">{paper.title}</p>}</div></div>{envelope&&loadError&&<p role="status" className="study-field-error">{loadError}</p>}{data&&<div className="grade-scope-note"><span>正在查看：{viewingGrade==='all'?'全部年级':viewingGrade==='unknown'?'未分年级':gradeNames[viewingGrade-1]}{viewingGrade==='unknown'?'。这些记录缺少年级信息，保留在此处，不推定为当前年级。':''}</span>{subjectHasUnknown&&viewingGrade!=='unknown'&&<><span>另有未注明年级的历史记录。</span><button className="study-link" onClick={()=>changeViewingGrade('unknown')}>查看未分年级</button></>}</div>}{runtime&&route.page==='recognition'&&<p className="study-muted study-runtime-note">{conversation?'由当前对话识别，完成后回到这里复核。':`识别模型：${runtime.recognition.model||'未指定'}${runtime.recognition.reasoning_effort?` · ${runtime.recognition.reasoning_effort}`:''}`}</p>}{renderPage()}</main></div>{reportConsent&&<ReportConsent saving={saving} recovery={!!data?.recognition?.groups.find(g=>g.id===reportConsent)?.reportTask?.resultRecovery?.available} onClose={()=>setReportConsent(null)} onConfirm={()=>void requestReport()}/>} {settingsOpen&&envelope&&<StudentSettings profile={data?.profile||{}} mode={needsSetup?'profile':settingsMode||'profile'} required={needsSetup} saving={saving} onClose={()=>setSettingsMode(null)} onSave={saveSettings} onChooseFolder={chooseSettingsFolder}/>}{message&&<div className="study-toast" role="status">{message}</div>}<dialog ref={imageDialog} className="study-image-dialog" aria-label="放大查看图片" onClose={()=>setImage(null)}><div className="study-image-toolbar"><strong>{image?.label}</strong><div><button onClick={()=>setZoom(z=>Math.max(.5,z-.25))} aria-label="缩小图片">−</button><span>{Math.round(zoom*100)}%</span><button onClick={()=>setZoom(z=>Math.min(3,z+.25))} aria-label="放大图片">＋</button><button onClick={()=>setImage(null)} aria-label="关闭图片">×</button></div></div><div className="study-image-scroll">{image&&<div style={{width:`${zoom*100}%`,margin:'auto'}}><PcAssetImage asset={image}/></div>}</div></dialog>{printing&&<section className="study-print-document"><h1>{printing.title}</h1>{paperQuestions(printing).map((q,i)=><article key={q.id}><div>{i+1}. <RichQuestion {...q}/></div>{!q.content?.blocks.some(b=>b.type==='image')&&q.cleanImages?.map((a,j)=><PcAssetImage key={j} asset={a}/>)}{q.answerLayout?.kind!=='inline'&&<div className="study-print-space" style={{minHeight:`${q.answerLayout?.heightCm||3}cm`}}/>}</article>)}</section>}</div>;
}

function diagramAssets(q:PcQuestion):PcAsset[]{
  const values=[...(q.cleanImages||[]),...(q.content?.blocks.flatMap(b=>b.type==='image'?[b.asset]:[])||[])];
  return values.filter((a,i)=>values.findIndex(b=>b.url===a.url)===i);
}
function Panel({title,children,action}:{title?:string;children:ReactNode;action?:ReactNode}){return <section className="study-panel">{title&&<div className="study-section-heading"><h2>{title}</h2>{action}</div>}{children}</section>}
function Empty({children}:{children:ReactNode}){return <div className="study-empty">{children}</div>}
function Info({label,value}:{label:string;value:string}){return <div className="study-info"><span>{label}</span><strong>{value}</strong></div>}
function Images({assets,onOpen}:{assets:PcAsset[];onOpen:(asset:PcAsset)=>void}){return assets.length?<div className="study-images">{assets.map((asset,i)=><figure key={asset.url+i}>{/\.pdf($|\?)/i.test(asset.url)?<a className="study-button study-button-secondary" href={asset.url} target="_blank" rel="noreferrer">打开 PDF 原件</a>:<button className="study-image-button" onClick={()=>onOpen(asset)} aria-label={`放大查看${asset.label}`}><PcAssetImage asset={asset}/></button>}<figcaption>{asset.label} · 点击放大</figcaption></figure>)}</div>:<div className="study-empty">暂未保存对应图片。</div>}
function TagEditor({title,values,options,max,disabled,onChange}:{title:string;values:string[];options:string[];max:number;disabled:boolean;onChange:(values:string[])=>void}){
  const [search,setSearch]=useState('');const [open,setOpen]=useState(false);const [error,setError]=useState('');
  function toggle(value:string){const selected=values.includes(value);if(selected&&values.length===1){setError(`至少保留 1 个${title}`);return;}if(!selected&&values.length>=max){setError(`最多选择 ${max} 个${title}`);return;}setError('');onChange(selected?values.filter(v=>v!==value):[...values,value]);}
  const matches=unique([...options,...values]).filter(v=>v.includes(search.trim()));
  return <div className="study-tag-editor"><div className="study-section-heading"><h3>{title} <small>1–{max} 个</small></h3><button className="study-link" onClick={()=>setOpen(o=>!o)}>{open?'收起':'修改'}</button></div><div className="study-tag-list">{values.map(v=><span className="study-tag" key={v}>{v}</span>)}</div>{open&&<div><label className="study-form-label">搜索{title}<input className="study-input" value={search} onChange={e=>setSearch(e.target.value)} placeholder={`搜索或添加${title}`}/></label><div className="study-tag-options">{matches.map(v=><label key={v}><input type="checkbox" checked={values.includes(v)} disabled={disabled} onChange={()=>toggle(v)}/>{v}</label>)}</div>{search.trim()&&!matches.includes(search.trim())&&<button className="study-link" disabled={disabled} onClick={()=>{toggle(search.trim());setSearch('');}}>添加“{search.trim()}”</button>}</div>}{error&&<p role="status" className="study-field-error">{error}</p>}</div>;
}
function PaperReport({paper,questions,onFilter,onQuestion,knowledgeTree}:{paper:PcPaper;questions:PcQuestion[];onFilter:(kind:PcFilterKind,value:string)=>void;onQuestion:(q:PcQuestion)=>void;knowledgeTree:import('./pc/model').PcKnowledgeNode[]}){
  const practice=paper.kind==='practice',results=paper.savedResults;
  const all=practice?questions.map(q=>({id:q.id,number:q.title,text:q.fullText,knowledgeIds:q.knowledgeIds||[],knowledgePoints:q.knowledgePoints||[],result:results?.[q.id]==='correct'?'correct':results?.[q.id]==='incorrect'?'wrong':'pending'})):(paper.allQuestions||[]).filter(q=>q.exclusionKind!=='invalid').map(q=>({...q,result:q.reportResult??(q.excluded||q.decisionStatus!=='confirmed'?'pending':q.verdict)}));
  const inferredCorrect=!practice&&(paper.allQuestions||[]).some(q=>q.exclusionKind!=='invalid'&&q.reportInferredCorrect&&q.reportResult==='correct');
  const correct=all.filter(q=>q.result==='correct').length,wrong=all.filter(q=>q.result==='wrong').length,pending=all.length-correct-wrong;
  const wrongQs=practice?questions.filter(q=>results?.[q.id]==='incorrect'):questions;
  const mapped=all.filter(q=>q.knowledgeIds.length||q.knowledgePoints.length),unmapped=all.length-mapped.length;
  const reasons=aggregateQuestionTags(wrongQs,'reason');
  return <><Panel title={practice?'本次复练表现':'整卷表现'}><div className="study-info-grid"><Info label="有效题目" value={`${all.length} 题`}/><Info label={inferredCorrect?'做对':'已确认做对'} value={`${correct} 题`}/><Info label="已确认做错" value={`${wrong} 题`}/><Info label="待复核 / 无法判定" value={`${pending} 题`}/><Info label={inferredCorrect?'已统计题目正确率':'已确认题目正确率'} value={correct+wrong?`${Math.round(correct/(correct+wrong)*100)}%`:'暂不计算'}/></div>{inferredCorrect&&<p className="study-muted">错题候选已全部人工复核，其余待确认考点按做对统计；不改变原判定记录。</p>}{paper.coverage==='partial'&&<p className="study-muted">当前只覆盖已提供的部分卷面，不能代表完整试卷。</p>}{pending>0&&<p className="study-muted">尚有 {pending} 道题待复核，报告随确认结果更新。待复核题不算作做错。</p>}</Panel>
    <Panel title="考点表现"><p className="study-muted">按本次作答的正确、错误与待复核统计；同题涉及多个考点时，各考点分别计入，父级按题目去重。</p><KnowledgeDistributionChart nodes={knowledgeTree} questions={mapped.map(q=>({...q,result:q.result as 'correct'|'wrong'|'pending'|'ungradable'}))} mode="result" onFilter={id=>onFilter('knowledgePoint',id)}/>{unmapped>0&&<p className="study-muted">还有 {unmapped} 道题未关联考点，补齐后计入分布。</p>}</Panel>
    <Panel title="易错点分析"><ReasonPie reasons={reasons} onFilter={onFilter}/>{wrongQs.filter(q=>q.causeAnalysis).map(q=><p key={q.id} className="study-prose"><button className="study-link" onClick={()=>onQuestion(q)}>{q.knowledgePoints?.join('、')||'查看错题'}</button>：{q.causeAnalysis}</p>)}</Panel>
    <Panel title={practice?'本次复练题目':'本次错题'}>{questions.map((q,i)=><div key={q.id}>{practice&&<p className="study-muted">本次：{results?.[q.id]==='correct'?'正确':results?.[q.id]==='incorrect'?'错误':'尚未批改'}</p>}<PcQuestionCard question={q} index={i} onOpen={()=>onQuestion(q)} onTag={onFilter}/></div>)}</Panel></>;
}

function ReportConsent({saving,recovery,onClose,onConfirm}:{saving:boolean;recovery:boolean;onClose:()=>void;onConfirm:()=>void}){
  const ref=useRef<HTMLDialogElement>(null);
  useEffect(()=>{const el=ref.current;el?.showModal();return()=>el?.close();},[]);
  return <dialog ref={ref} className="student-settings-dialog" aria-labelledby="report-consent-title" onCancel={e=>{e.preventDefault();if(!saving)onClose();}}><div style={{padding:24}}><header className="student-settings-heading"><h2 id="report-consent-title">{recovery?'重试保存整卷报告':'是否进行整卷分析？'}</h2></header><p className="study-prose">{recovery?'已识别的内容会直接复用，只重试本地校验和保存，不重新调用 AI。':'将识别全部题目、验算作答并关联知识点，Token 消耗会明显高于只识别错题。未批改的试卷也会自动寻找错题，结果仍需人工复核。'}</p><p className="study-muted">生成后保存结果，再次查看直接打开。已有人工修改和错题记录会保留。</p><footer className="student-settings-actions"><button className="study-button study-button-secondary" disabled={saving} onClick={onClose}>暂不进行</button><button className="study-button" disabled={saving} onClick={onConfirm}>{saving?'正在提交…':recovery?'重试保存':'确认并开始'}</button></footer></div></dialog>;
}
