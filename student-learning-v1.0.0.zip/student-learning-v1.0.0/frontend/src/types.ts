export type MainPage = 'home' | 'papers' | 'capture' | 'originals' | 'mine';

export type Page =
  | MainPage
  | 'question-list'
  | 'question-detail'
  | 'question-edit'
  | 'dashboard'
  | 'paper-detail'
  | 'practice-grading'
  | 'practice-result'
  | 'recognize'
  | 'recognition-edit'
  | 'complete'
  | 'original-view'
  | 'source-questions'
  | 'report'
  | 'profile-edit'
  | 'subject-management'
  | 'points-usage'
  | 'system-settings'
  | 'customer-service'
  | 'archived-questions'
  | 'settings';

export type MasteryStatus = '未掌握' | '已掌握';

export type RecognitionStatus = 'pending' | 'saved' | 'skipped' | 'deleted';

export type RecognitionBox = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type RecognitionQuestionImage = {
  id: string;
  label: string;
  pageLabel: string;
  box: RecognitionBox;
  note: string;
  imageSrc?: string;
};

export type MasteryFilter = '全部' | MasteryStatus;

export type FilterKey = 'uploadTime' | 'mastery' | 'knowledgePoint' | 'reason';

export type QuestionFilters = {
  uploadTime: string[];
  mastery: MasteryStatus[];
  knowledgePoint: string[];
  reason: string[];
};

export type WrongQuestion = {
  id: string;
  title: string;
  fullText: string;
  answer?: string;
  analysis?: string;
  sourceRecognitionId?: string;
  uploadTime: string;
  mastery: MasteryStatus;
  knowledgePoint: string;
  knowledgePoints?: string[];
  reason: string;
  reasons?: string[];
  wrongCount: number;
  correctCount: number;
  groupedCount: number;
  archived?: boolean;
};

export type RecognizedQuestion = {
  id: string;
  number: number;
  question: string;
  answer: string;
  analysis: string;
  mastery: MasteryStatus;
  knowledgePoint: string;
  knowledgePoints: string[];
  reason: string;
  reasons: string[];
  box: RecognitionBox;
  imageSrc?: string;
  studentAnswer?: string;
  reviewReasons?: string[];
  supplementalImages?: RecognitionQuestionImage[];
  boxDeleted?: boolean;
  needsRerun?: boolean;
};
