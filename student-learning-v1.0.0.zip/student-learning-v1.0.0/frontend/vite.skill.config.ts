import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({plugins:[react()],base:'/',build:{outDir:'dist-skill',emptyOutDir:true,rollupOptions:{input:'pc.html'}}});
