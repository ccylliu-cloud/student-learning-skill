"""Bound active tags without inventing grade metadata or silently losing candidates."""
import json,re

def grade_priority(raw):
    for key in ('grade','grade_level','minimum_grade','min_grade'):
        value=raw.get(key)
        if type(value) is int and 1<=value<=12:return value,True
        if isinstance(value,str):
            if value in ('高一','高二','高三'):return {'高一':10,'高二':11,'高三':12}[value],True
            m=re.fullmatch(r'([1-9])年级',value)
            if m:return int(m[1]),True
    return 0,False

def limit_knowledge(db,q,subject):
    ids=q.get('knowledgeIds',[])
    if not isinstance(ids,list) or any(not isinstance(k,str) for k in ids):raise ValueError('知识点ID必须为文字数组')
    ids=list(dict.fromkeys(ids))
    if len(ids)<=3:return
    ranks={};names={}
    for kid in ids:
        row=db.execute('SELECT subject,name,payload FROM knowledge WHERE id=?',(kid,)).fetchone()
        if not row or row['subject']!=subject:raise ValueError('知识点ID不存在或学科不符')
        ranks[kid]=grade_priority(json.loads(row['payload']));names[kid]=row['name']
    chosen=sorted(ids,key=lambda k:-ranks[k][0])[:3]
    dropped=[k for k in ids if k not in chosen]
    q['knowledgeIds']=chosen
    q['knowledgeSelectionCandidates']=q.get('knowledgeSelectionCandidates',[])+[{'id':k,'name':names[k],'reason':'超出3个关联上限，保留待核对'} for k in dropped]
    q['knowledgeSelectionReview']=q.get('knowledgeSelectionReview',False) or not all(ranks[k][1] for k in ids)
    attrs=q.get('attributions',[])
    q['knowledgeSelectionAttributions']=q.get('knowledgeSelectionAttributions',[])+[a for a in attrs if a.get('knowledge_point_id') in dropped]
    q['attributions']=[a for a in attrs if a.get('knowledge_point_id') not in dropped]
    q['pc_knowledge_points']=[names[k] for k in chosen]
    note='知识点超过3个，按明确年级优先、同级按核心考点顺序保留3个；其余候选已保留待核对：'+ '、'.join(names[k] for k in dropped)+'。'
    if q['knowledgeSelectionReview']:note+='部分条目没有明确年级，未猜测具体年级，请核对选择。'
    q['evidence']=(q.get('evidence') or '')+'；'+note

def route_knowledge(db,q,subject,grade):
    if subject!='math' or type(grade)is not int:return
    allowed='math-k12-knowledge' if grade<=9 else 'math-highschool-knowledge'
    dropped=[]; kept=[]
    for kid in q.get('knowledgeIds',[]):
        row=db.execute('SELECT subject,name,payload FROM knowledge WHERE id=?',(kid,)).fetchone()
        if not row or row['subject']!=subject:raise ValueError('知识点ID不存在或学科不符')
        if json.loads(row['payload']).get('knowledge_base_id')==allowed and json.loads(row['payload']).get('is_assessable') is True:kept.append(kid)
        else:dropped.append({'id':kid,'name':row['name'],'reason':'不是本卷学段的现行末级知识点，待核对'})
    if dropped:
        ids={k['id'] for k in dropped}
        q['knowledgeIds']=kept
        q['pc_knowledge_points']=[db.execute('SELECT name FROM knowledge WHERE id=?',(k,)).fetchone()['name'] for k in kept]
        q['knowledgeSelectionCandidates']=q.get('knowledgeSelectionCandidates',[])+dropped
        q['knowledgeSelectionAttributions']=q.get('knowledgeSelectionAttributions',[])+[a for a in q.get('attributions',[]) if a.get('knowledge_point_id') in ids]
        q['attributions']=[a for a in q.get('attributions',[]) if a.get('knowledge_point_id') not in ids]
        q['knowledgeSelectionReview']=True
        q['evidence']=(q.get('evidence') or '')+'；不在本年级数学库的候选待核对：'+'、'.join(k['name'] for k in dropped)+'。'
