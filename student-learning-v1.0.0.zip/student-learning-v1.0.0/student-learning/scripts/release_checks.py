"""Read-only release integrity checks; no initialization of personal archives."""
import hashlib,json,importlib.util,platform
from pathlib import Path
from release_runtime import SKILL,VERSION,snapshot

def doctor():
    issues=[];manifest=SKILL/'distribution-manifest.json'
    if not manifest.is_file():issues.append('missing_distribution_manifest')
    else:
        data=json.loads(manifest.read_text(encoding='utf-8'))
        for item in data.get('files',[]):
            p=SKILL/item['file']
            if p.is_symlink() or not p.is_file() or SKILL.resolve() not in p.resolve().parents or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:issues.append('integrity:'+item['file'])
    kb=json.loads((SKILL/'knowledge-integration.json').read_text(encoding='utf-8'))
    for subject,item in kb['subjects'].items():
        p=SKILL/item['path']
        if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:issues.append('knowledge_hash:'+subject)
    missing=[name for name,module in [('Pillow','PIL'),('python-docx','docx')] if importlib.util.find_spec(module) is None]
    result=snapshot()
    result.update(ok=not issues and not missing,issues=issues,missing_dependencies=missing,writes=False,validation_scope='file_integrity_and_dependencies_not_model_accuracy')
    return result
if __name__=='__main__':print(json.dumps(doctor(),ensure_ascii=False,indent=2))
