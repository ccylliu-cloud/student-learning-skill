"""Loopback-only HTTP host for the installed PC interface and SQLite archive."""
from __future__ import annotations
import json, mimetypes, secrets, tempfile, base64, io, hashlib, sqlite3, threading, subprocess, sys
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote, quote
import study
import pc_store
from storage_checks import probe_directory, error_payload


def make_server(root,port=8765):
    root=Path(root).expanduser().resolve()
    static=(study.SKILL/'assets/pc').resolve()
    token=secrets.token_urlsafe(32)
    from codex_bridge import Runner
    runner=Runner(root)
    request_lock=threading.RLock()
    folder_revision=None
    class Handler(BaseHTTPRequestHandler):
        def send(self,status,data,mime='application/json; charset=utf-8',filename=None):
            body=data if isinstance(data,bytes) else study.dumps(data).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type',mime); self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('X-Frame-Options','DENY'); self.send_header('Referrer-Policy','same-origin')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'")
            if filename: self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(filename))
            self.end_headers(); self.wfile.write(body)
        def trusted(self,write=False):
            host=f'127.0.0.1:{self.server.server_port}'; origin='http://'+host
            if self.headers.get('Host')!=host: return False
            if self.headers.get('Sec-Fetch-Site')=='cross-site': return False
            request_origin=self.headers.get('Origin')
            if request_origin is not None and request_origin!=origin: return False
            if write and request_origin!=origin: return False
            return True
        def authorized(self):
            return secrets.compare_digest(self.headers.get('X-Pc-Token',''),token)
        def envelope(self,db):
            nonlocal folder_revision
            value=pc_store.read_archive(root,db)
            profile=value['archive']['profile']
            stamp=(str(root),value['revision'],profile.get('grade'))
            if profile.get('onboardingComplete') and folder_revision!=stamp:
                from student_profile import sync_grade_folders,subject_folder
                for subject in profile['selectedSubjects']:subject_folder(root,db,subject)
                sync_grade_folders(root,db);folder_revision=stamp
            return dict(value,token=token)
        def do_GET(self):
            with request_lock:
                try:return self.get_request()
                except (sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,root))
        def do_POST(self):
            with request_lock:
                try:return self.post_request()
                except (sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,root))
        def settings(self,path):
            nonlocal root,runner,folder_revision
            try:
                study.require(self.headers.get('Content-Type','').split(';')[0]=='application/json','需要设置内容')
                size=int(self.headers.get('Content-Length','0'));study.require(0<size<=16384,'设置内容大小无效')
                data=json.loads(self.rfile.read(size))
                if path.endswith('/choose-folder'):
                    if sys.platform=='darwin':
                        command=['osascript','-e','POSIX path of (choose folder with prompt "选择工作区内部的档案文件夹（更改位置时请选择空文件夹）")']
                    elif sys.platform=='win32':
                        command=['powershell','-NoProfile','-STA','-Command',
                            '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Add-Type -AssemblyName System.Windows.Forms; $dialog=New-Object System.Windows.Forms.FolderBrowserDialog; $dialog.Description="选择工作区内部的档案文件夹"; if($dialog.ShowDialog() -eq "OK"){[Console]::Write($dialog.SelectedPath)}']
                    else:
                        raise ValueError('当前系统没有可用的目录选择器，请直接填写工作区内部的绝对路径')
                    try:process=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',timeout=120)
                    except (OSError,subprocess.TimeoutExpired):
                        raise ValueError('目录选择器不可用或被系统限制，请直接填写工作区内部的绝对路径；无需更改系统安全设置')
                    if process.returncode:
                        if '-128' in process.stderr:return self.send(200,{'path':None})
                        raise ValueError('目录选择器未成功打开，请直接填写工作区内部的绝对路径')
                    return self.send(200,{'path':process.stdout.strip() or None})
                from student_profile import save_profile,prepare_storage_copy,sync_grade_folders
                study.require(isinstance(data,dict),'设置格式无效')
                value=data.get('storageRoot');study.require(isinstance(value,str) and value.strip(),'请确认本地存储位置')
                requested=Path(value).expanduser();study.require(requested.is_absolute(),'请输入绝对文件夹路径')
                import portable_config
                target=portable_config.validate_root(requested)
                _,db=study.connect(root)
                try:
                    if self.headers.get('If-Match')!=pc_store.revision(db):raise pc_store.ConflictError('档案已更新，请关闭设置并刷新后重试')
                    groups=pc_store.meta(db,'pc_recognition',{'groups':[]})['groups']
                    study.require(not runner.active and not any(g.get('requested') or g.get('runStatus') in ('running','queued') for g in groups),'识别进行中，请完成后再修改学生设置')
                    # Validate input without committing profile at the old location.
                    db.execute('BEGIN IMMEDIATE')
                    save_profile(root,db,data);db.rollback()
                finally:db.close()
                probe_directory(target)
                changed=target!=root
                if changed:
                    import portable_config as service
                    config=service.read_config()
                    study.require(Path(config['root']).expanduser().resolve()==root,'档案位置与本试用安装的设置不一致，请通过 portable.py 启动后重试')
                    target=prepare_storage_copy(root,requested)
                _,newdb=study.connect(target)
                try:
                    newdb.execute('BEGIN IMMEDIATE')
                    save_profile(target,newdb,data)
                    sync_grade_folders(target,newdb)
                    newdb.commit()
                except Exception:newdb.rollback();raise
                finally:newdb.close()
                if changed:
                    # Config is atomically published only after a complete usable copy exists.
                    updated={**config,'root':str(target)}
                    service.atomic(service.CONFIG,json.dumps(updated,ensure_ascii=False,indent=2).encode())
                    runner.close();root=target;runner=Runner(root);self.server.runner=runner
                    self.server.archive_root=root
                folder_revision=None
                _,db=study.connect(root)
                try:return self.send(200,self.envelope(db))
                finally:db.close()
            except pc_store.ConflictError as error:return self.send(409,{'error':str(error)})
            except (sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,data.get('storageRoot') if isinstance(locals().get('data'),dict) else root))
            except (ValueError,KeyError,TypeError,subprocess.TimeoutExpired) as error:return self.send(400,error_payload(error,root))
        def get_request(self):
            if not self.trusted(): return self.send(403,{'error':'请使用本机学习管理页'})
            path=unquote(urlparse(self.path).path)
            if path=='/api/runtime':
                from release_runtime import snapshot
                return self.send(200,snapshot())
            if path=='/api/health':
                import os
                # Read-only probe: no initialization, tokens, student text or source paths.
                try:
                    db=sqlite3.connect((root/'study.sqlite3').as_uri()+'?mode=ro',uri=True,timeout=2)
                    try:
                        row=db.execute("SELECT value FROM meta WHERE key='pc_recognition'").fetchone()
                        groups=json.loads(row[0]).get('groups',[]) if row else []
                    finally: db.close()
                    active=sum(bool(g.get('requested') or g.get('runStatus') in ('running','queued') or g.get('reportTask',{}).get('status') in ('running','queued') or g.get('supplementTask',{}).get('status') in ('running','queued')) for g in groups)
                    return self.send(200,{'service':'local.codex.student-learning','version':1,
                        'rootId':hashlib.sha256(str(root).encode()).hexdigest(),
                        'pid':os.getpid(),'activeRecognitions':active})
                except (sqlite3.Error,ValueError,TypeError):
                    return self.send(503,{'error':'学习档案暂时不可读'})
            if path=='/api/archive':
                _,db=study.connect(root)
                try: return self.send(200,self.envelope(db))
                except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error: return self.send(400,error_payload(error,root))
                finally: db.close()
            if path.startswith('/api/archive/check-word/'):
                if not self.authorized(): return self.send(403,{'error':'请刷新页面'})
                _,db=study.connect(root)
                try:
                    from pc_word import check_questions
                    pid=path.removeprefix('/api/archive/check-word/')
                    paper=pc_store.meta(db,'pc_practice',{}).get(pid); study.require(paper,'复习卷不存在')
                    qs={q['id']:q for q in study.snapshot(db)['questions']}
                    return self.send(200,{'issues':check_questions(root,[qs[i] for i in paper['questionIds'] if i in qs])})
                except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,root))
                finally:db.close()
            if path.startswith('/api/archive/word/'):

                if not self.authorized(): return self.send(403,{'error':'下载需要当前页面的请求令牌，请刷新页面'})
                _,db=study.connect(root); temp=None
                try:
                    pid=path.removeprefix('/api/archive/word/')
                    paper=pc_store.meta(db,'pc_practice',{}).get(pid); study.require(paper,'复习卷不存在')
                    from student_profile import subject_folder
                    folder=subject_folder(root,db,paper['subject'],paper.get('grade'))/'打印';folder.mkdir(exist_ok=True)
                    with tempfile.NamedTemporaryFile(suffix='.docx',dir=folder,delete=False) as f: temp=Path(f.name)
                    study.export_docx(root,db,temp,subject=pc_store.subject_code(paper['subject']),mode='practice',question_ids=paper['questionIds'])
                    return self.send(200,temp.read_bytes(),'application/vnd.openxmlformats-officedocument.wordprocessingml.document',paper['title']+'.docx')
                except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error: return self.send(400,error_payload(error,root))
                finally:
                    db.close()
                    if temp: temp.unlink(missing_ok=True)
            if path.startswith('/files/'):
                try:
                    file=pc_store.source_path(root,path)
                    mime=mimetypes.guess_type(file)[0] or 'application/octet-stream'
                    study.require(mime in {'image/png','image/jpeg','image/webp','application/pdf'},'素材格式不支持')
                    return self.send(200,file.read_bytes(),mime)
                except (ValueError,OSError): return self.send(404,{'error':'素材不存在'})
            file=static/('pc.html' if path in ('/','/index.html','/pc.html') else path.lstrip('/'))
            file=file.resolve()
            if file.is_relative_to(static) and file.is_file() and file.suffix.lower() in ('.html','.js','.css','.svg','.png','.jpg','.jpeg','.webp','.woff','.woff2','.ico'):
                return self.send(200,file.read_bytes(),mimetypes.guess_type(file)[0] or 'application/octet-stream')
            self.send(404,{'error':'页面不存在'})
        def post_request(self):
            if not self.trusted(write=True) or not self.authorized(): return self.send(403,{'error':'请从本机页面提交，或刷新页面重试'})
            path=unquote(urlparse(self.path).path)
            if path in ('/api/settings','/api/settings/choose-folder'):return self.settings(path)
            if path=='/api/assets':
                try:
                    study.require(self.headers.get('Content-Type','').split(';')[0]=='application/json','需要图片内容')
                    size=int(self.headers.get('Content-Length','0'));study.require(0<size<=15_000_000,'图片过大，请使用小于 10 MB 的图片')
                    data=json.loads(self.rfile.read(size)); value=data.get('dataUrl','')
                    study.require(isinstance(value,str) and value.startswith(('data:image/png;base64,','data:image/jpeg;base64,','data:image/webp;base64,')),'请粘贴 PNG、JPEG 或 WebP 图片')
                    raw=base64.b64decode(value.split(',',1)[1],validate=True)
                    from PIL import Image
                    with Image.open(io.BytesIO(raw)) as image:
                        study.require(image.width*image.height<=40_000_000,'图片尺寸过大'); image.verify()
                    ext='.png' if value.startswith('data:image/png') else '.jpg' if value.startswith('data:image/jpeg') else '.webp'
                    folder=root/'assets';folder.mkdir(exist_ok=True);name=hashlib.sha256(raw).hexdigest()+ext
                    path=folder/name
                    if not path.exists():path.write_bytes(raw)
                    return self.send(200,{'asset':{'url':'/files/'+name,'label':str(data.get('name') or '题目图片')[:120]}})
                except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,root))
            if path=='/api/recognition/report':
                _,db=study.connect(root)
                try:
                    study.require(self.headers.get('Content-Type','').split(';')[0]=='application/json','仅接受JSON请求')
                    size=int(self.headers.get('Content-Length','0'));study.require(0<size<=16384,'报告请求大小无效')
                    expected=self.headers.get('If-Match');study.require(expected,'缺少档案版本，请刷新后重试')
                    data=json.loads(self.rfile.read(size))
                    from report_recognition import queue_task,stamp
                    with runner.lock:active=isinstance(data,dict) and data.get('groupId') in runner.active
                    if active:
                        current=next((g.get('reportTask') for g in pc_store.meta(db,'pc_recognition',{'groups':[]})['groups'] if g['id']==data.get('groupId')),None)
                        study.require(current and current.get('status') in ('queued','running'),'上一项识别正在收尾，请稍后再试')
                    task=queue_task(root,db,data,expected)
                    if task['status']=='queued' and not runner.submit_report(data['groupId'],task['id']):
                        with runner.lock:active=data['groupId'] in runner.active
                        if not active:stamp(root,data['groupId'],task['id'],'failed',error='服务暂未就绪，请稍后重试。')
                    return self.send(202,self.envelope(db))
                except pc_store.ConflictError as error:return self.send(409,{'error':str(error)})
                except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,root))
                finally:db.close()
            if path=='/api/recognition/supplement':
                _,db=study.connect(root)
                try:
                    study.require(self.headers.get('Content-Type','').split(';')[0]=='application/json','仅接受JSON请求')
                    size=int(self.headers.get('Content-Length','0'));study.require(0<size<=16384,'圈选请求大小无效')
                    expected=self.headers.get('If-Match');study.require(expected,'缺少档案版本，请刷新后再圈选')
                    data=json.loads(self.rfile.read(size))
                    from supplement_recognition import queue_task,stamp
                    with runner.lock:active=data.get('groupId') in runner.active if isinstance(data,dict) else False
                    if active:
                        current=next((g.get('supplementTask') for g in pc_store.meta(db,'pc_recognition',{'groups':[]})['groups'] if g['id']==data.get('groupId')),None)
                        study.require(current and current['id']==data.get('requestId'),'上一道补充题正在处理或收尾，请稍后再圈选下一题')
                    task=queue_task(root,db,data,expected)
                    if task['status']=='queued' and not runner.submit_supplement(data['groupId'],task['id']):
                        with runner.lock:active=data['groupId'] in runner.active
                        if not active:stamp(root,data['groupId'],task['id'],'failed',error='识别服务暂未就绪，请刷新后重试当前区域。')
                    return self.send(202,self.envelope(db))
                except pc_store.ConflictError as error:return self.send(409,{'error':str(error)})
                except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error:return self.send(400,error_payload(error,root))
                finally:db.close()
            if urlparse(self.path).path!='/api/archive': return self.send(404,{'error':'接口不存在'})
            _,db=study.connect(root)
            try:
                study.require(self.headers.get('Content-Type','').split(';')[0]=='application/json','仅接受 JSON 档案')
                size=int(self.headers.get('Content-Length','0')); study.require(0<size<=15_000_000,'提交内容大小无效')
                expected=self.headers.get('If-Match'); study.require(expected,'缺少档案版本，请刷新页面')
                data=json.loads(self.rfile.read(size))
                before=pc_store.read_archive(root,db)['archive'].get('recognition',{'groups':[]})
                prior={g['id']:g for g in before['groups']}
                if isinstance(data,dict):
                    incoming_groups=(data.get('recognition') or {}).get('groups',[])
                    with runner.lock:
                        for candidate in incoming_groups:
                            if candidate.get('requested') and not prior.get(candidate.get('id'),{}).get('requested') and candidate.get('id') in runner.active:
                                raise pc_store.ConflictError('上一项识别正在收尾，请稍后再试；不会重复启动任务')
                result=pc_store.apply_archive(root,db,data,expected)
                queued=[g['id'] for g in result['archive'].get('recognition',{'groups':[]})['groups'] if g.get('requested') and not g.get('recognized') and not prior.get(g['id'],{}).get('requested')]
                self.send(200,self.envelope(db))
                for gid in queued:runner.submit(gid)
            except pc_store.ConflictError as error: self.send(409,{'error':str(error)})
            except (ValueError,KeyError,TypeError,sqlite3.Error,OSError) as error: self.send(400,error_payload(error,root))
            finally: db.close()
        def log_message(self,*args): pass
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.runner=runner
    server.archive_root=root
    return server

def serve(root,port=8765):
    import signal, threading
    if threading.current_thread() is threading.main_thread():
        def stop(signum, frame): raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, stop)
    server=make_server(root,port)
    server.runner.recover()
    print(study.dumps({'url':f'http://127.0.0.1:{server.server_port}/','data_root':str(Path(root).expanduser().resolve())}),flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.runner.close();server.server_close()
