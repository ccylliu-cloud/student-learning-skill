"""Bounded local Codex recognition with compact contracts and observable execution."""
from __future__ import annotations
import json, os, queue, shutil, subprocess, threading, time, uuid
from pathlib import Path
import study, pc_store
import recognition_checkpoint as checkpoint
from recognition_recovery import normalize_result
from recognition_contract import build_prompt, expand_result
from vision_guard import blocked_error, native_event_blocked, BLOCKED_MESSAGE


def executable():
    # ChatGPT/Codex desktop builds ship the CLI inside codex-cli.  Keep the
    # older locations for existing installations and allow an explicit
    # override for managed environments.
    choices=[os.environ.get('STUDENT_LEARNING_CODEX'),
             '/Applications/ChatGPT.app/Contents/Resources/codex-cli/CodexCLI.app/Contents/MacOS/codex',
             '/Applications/ChatGPT.app/Contents/Resources/codex',
             '/Applications/Codex.app/Contents/Resources/codex',
             shutil.which('codex')]
    for candidate in choices:
        if candidate and Path(candidate).is_file() and os.access(candidate,os.X_OK): return str(candidate)
    raise ValueError('未找到 Codex 本地运行程序，请在 Codex 中重新打开个人学习档案。')


def command(work, output, files):
    # Recognition must not inherit a model selected for a different surface.  The
    # desktop app can retain a model that the ChatGPT-backed CLI account cannot
    # execute.  Keep an environment override for managed installations.
    from release_runtime import settings
    selected=settings();model=selected['model']
    cmd=[executable(),'exec','--model',model,'-c','model_reasoning_effort='+json.dumps(selected['reasoning_effort']),'--skip-git-repo-check','--ephemeral','--sandbox','read-only',
         '--disable','plugins','--disable','apps','--disable','multi_agent',
         '--disable','browser_use','--disable','image_generation',
         '--json','-C',str(work),'-o',str(output)]
    for file in files: cmd.extend(['-i',file])
    return cmd+['--','-']


PHASES={'preparing':'准备识别资料','analyzing':'模型正在核对卷面','reading':'正在读取所需知识点',
        'generating':'正在输出识别内容','reconnecting':'连接中断，正在重连',
        'saving':'正在校验并保存结果','completed':'识别完成','failed':'识别未完成'}


class Runner:
    def __init__(self,root):
        self.root=Path(root); self.lock=threading.Lock(); self.active={}; self.processes={}; self.closed=False

    def stamp(self,gid,status,error=None,request_id=None,phase=None,started_at=None,recovery=None,notes=None):
        _,db=study.connect(self.root)
        try:
            db.execute('BEGIN IMMEDIATE'); rec=pc_store.meta(db,'pc_recognition',{'pages':[],'groups':[]})
            group=next((g for g in rec['groups'] if g['id']==gid),None)
            if not group or request_id is not None and group.get('requestId')!=request_id:
                db.rollback(); return
            group['runStatus']=status
            if recovery is not None:group['resultRecovery']=recovery
            if notes is not None:group['recognitionNotes']=notes
            if status=='failed': group['requested']=False;group['error']=error or '识别未完成，请重试。'
            else: group.pop('error',None)
            phase=phase or ('completed' if status=='completed' else 'failed' if status=='failed' else 'analyzing')
            now=study.now(); old=group.get('progress',{})
            progress={'phase':phase,'startedAt':started_at or old.get('startedAt') or now,
                      'updatedAt':now,'message':PHASES[phase]}
            if status in ('completed','failed'): progress['finishedAt']=now
            group['progress']=progress
            pc_store.put_meta(db,'pc_recognition',rec);db.commit()
        finally: db.close()

    def submit(self,gid):
        with self.lock:
            if self.closed or gid in self.active:return
            thread=threading.Thread(target=self.run,args=(gid,),daemon=True)
            self.active[gid]=thread;thread.start()

    def submit_supplement(self,gid,task_id):
        from supplement_recognition import run_task
        with self.lock:
            if self.closed or gid in self.active:return False
            thread=threading.Thread(target=run_task,args=(self,gid,task_id),daemon=True)
            self.active[gid]=thread;thread.start();return True

    def submit_report(self,gid,task_id):
        from report_recognition import run_task
        with self.lock:
            if self.closed or gid in self.active:return False
            thread=threading.Thread(target=run_task,args=(self,gid,task_id),daemon=True)
            self.active[gid]=thread;thread.start();return True

    def _execute(self,gid,cmd,prompt,work,request_id,metrics,stamp_callback=None):
        """Read events while the process runs; model text never becomes UI status."""
        from release_runtime import stage_record
        stage_record(work,prompt,[cmd[i+1] for i,x in enumerate(cmd) if x=='-i'],cmd)
        metrics['requested_reasoning_effort']=__import__('release_runtime').settings()['reasoning_effort']
        env=os.environ.copy();env.pop('CODEX_THREAD_ID',None)
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              text=True,encoding='utf-8',errors='replace',bufsize=1,env=env)
        with self.lock:
            self.processes[gid]=proc
            if self.closed:proc.terminate()
        messages=queue.Queue()
        def drain(stream,path,kind):
            with path.open('w',encoding='utf-8') as target:
                for line in stream:
                    target.write(line);target.flush()
                    if kind=='event':
                        try: messages.put(('event',json.loads(line)))
                        except (ValueError,TypeError): pass
                    elif blocked_error(line):
                        messages.put(('image_blocked',None))
                    elif 'responses_retry' in line and ('retrying' in line or 'reconnect' in line.lower()):
                        messages.put(('retry',None))
            messages.put(('closed',kind))
        readers=[threading.Thread(target=drain,args=(proc.stdout,work/'events.jsonl','event'),daemon=True),
                 threading.Thread(target=drain,args=(proc.stderr,work/'error.log','stderr'),daemon=True)]
        for thread in readers:thread.start()
        closed=0;start=time.monotonic();last_stamp=0;last_phase=None
        try:
            proc.stdin.write(prompt);proc.stdin.close()
            while closed<2:
                if time.monotonic()-start>1200:raise subprocess.TimeoutExpired(cmd,1200)
                try:kind,item=messages.get(timeout=.25)
                except queue.Empty:continue
                if kind=='closed':closed+=1;continue
                if kind=='image_blocked' or kind=='event' and native_event_blocked(item):
                    raise ValueError(BLOCKED_MESSAGE)
                phase=None
                if kind=='retry':
                    metrics['connection_retry_events']+=1;phase='reconnecting'
                else:
                    event_type=item.get('type')
                    if event_type=='turn.completed':
                        usage=item.get('usage')
                        if isinstance(usage,dict):
                            totals=metrics.get('usage') or {}
                            for key,value in usage.items():
                                if type(value) is int and value>=0:totals[key]=totals.get(key,0)+value
                            metrics['usage']=totals;metrics['usage_complete']=True
                            metrics['completed_turns']=metrics.get('completed_turns',0)+1
                    elif event_type=='turn.failed':
                        metrics['model_turn_failed']=True;metrics['usage_complete']=False
                        metrics['failure_message']=str(item.get('error',{}).get('message',''))[:1000]
                    elif event_type=='error':
                        if 'reconnect' in str(item.get('message','')).lower():
                            metrics['connection_retry_events']+=1;phase='reconnecting'
                    elif event_type in ('turn.started','thread.started'):
                        phase='analyzing'
                        if event_type=='turn.started':metrics['usage_complete']=False
                    elif event_type in ('item.started','item.completed'):
                        value=item.get('item',{});item_type=value.get('type')
                        if item_type=='command_execution':
                            phase='reading' if event_type=='item.started' else 'analyzing'
                            if event_type=='item.completed':
                                metrics['tool_calls']+=1
                                metrics['tool_output_chars']+=len(value.get('aggregated_output',''))
                        elif item_type=='agent_message':
                            text=value.get('text','').lstrip()
                            phase='generating' if text.startswith(('{','```json')) else 'analyzing'
                if phase and (phase!=last_phase or time.monotonic()-last_stamp>=3):
                    if stamp_callback:stamp_callback(phase)
                    else:self.stamp(gid,'running',request_id=request_id,phase=phase)
                    last_phase=phase;last_stamp=time.monotonic()
            proc.wait(timeout=5)
            return proc.returncode
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=3)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=3)
            for thread in readers:thread.join(timeout=2)
            for stream in (proc.stdin,proc.stdout,proc.stderr):
                if stream and not stream.closed:stream.close()

    def run(self,gid):
        group={};legacy_recovery=False
        try:
            _,db=study.connect(self.root)
            try:
                group=next((g for g in pc_store.meta(db,'pc_recognition',{'groups':[]})['groups'] if g['id']==gid),{})
                legacy_recovery=bool(group.get('resultRecovery',{}).get('available')) and group.get('retryMode')!='recognize' and checkpoint.find(self.root,checkpoint.context(self.root,db,group)) is not None
            finally:db.close()
        except Exception as error:
            try:
                self.stamp(gid,'failed',checkpoint.failure_message(error,bool(group.get('resultRecovery',{}).get('available'))),request_id=group.get('requestId'))
            finally:
                with self.lock:self.active.pop(gid,None);self.processes.pop(gid,None)
            return
        # Preserve pre-upgrade complete output recovery; new original requests use selective reading.
        if group and group.get('kind')!='practice' and not legacy_recovery:
            from selective_recognition import run_task
            return run_task(self,gid)
        work=self.root/'drafts'/('recognition-'+uuid.uuid4().hex)
        request_id=None;identity=None;has_result=False;recovery_expected=False;started=time.monotonic();started_at=study.now()
        metrics={'version':1,'protocol':'student-scan-v3','group_id':gid,'started_at':started_at,
                 'usage':None,'usage_complete':False,'tool_calls':0,'tool_output_chars':0,
                 'connection_retry_events':0,'status':'preparing','model_calls':0}
        try:
            work.mkdir(parents=True)
            _,db=study.connect(self.root)
            try:
                rec=pc_store.meta(db,'pc_recognition',{'pages':[],'groups':[]});group=next(g for g in rec['groups'] if g['id']==gid)
                if group.get('recognized') or not group.get('requested'):
                    metrics['status']='skipped';return
                request_id=group.get('requestId');metrics['request_id']=request_id
                recovery_expected=bool(group.get('resultRecovery',{}).get('available')) and group.get('retryMode')!='recognize'
                pages={p['id']:p for p in rec['pages']};selected=[pages[i] for i in group['pageIds']]
                files=[str(pc_store.source_path(self.root,p['url'])) for p in selected]
                identity=checkpoint.context(self.root,db,group)
                checkpoint.write(work/'input-context.json',identity)
                cached=None if group.get('retryMode')=='recognize' else checkpoint.find(self.root,identity)
                if group.get('resultRecovery',{}).get('available') and group.get('retryMode')!='recognize' and cached is None:
                    raise ValueError('保存结果与当前原图或试卷信息不再匹配，未调用AI。请核对后选择“重新读取整卷”；再次重试保存也不会调用AI。')
                prompt=build_prompt(self.root,db,group,files) if cached is None else ''
            finally:db.close()
            metrics.update(kind=group.get('kind','original'),page_count=len(files),prompt_chars=len(prompt))
            self.stamp(gid,'running',request_id=request_id,phase='saving' if cached else 'preparing',started_at=started_at,recovery={'available':bool(cached)},notes=[])
            output=work/'result.json'
            if cached:
                shutil.copyfile(cached,output)
                metrics.update(reused_result=str(cached.parent.name),model_calls=0,usage={'input_tokens':0,'cached_input_tokens':0,'output_tokens':0},usage_complete=True)
            else:
                cmd=command(work,output,files)
                metrics.update(model_calls=1,requested_model=cmd[cmd.index('--model')+1])
                rc=self._execute(gid,cmd,prompt,work,request_id,metrics)
                metrics['model_elapsed_seconds']=round(time.monotonic()-started,3)
                if rc!=0 or not output.exists():
                    metrics['usage_complete']=False
                    raise ValueError(checkpoint.execution_failure(metrics))
            checkpoint.ready(work,identity);has_result=True
            metrics['result_bytes']=output.stat().st_size
            compact,repairs=normalize_result(output.read_text(encoding='utf-8'))
            if compact.get('status') in ('image_blocked','blocked'):
                has_result=False
                (work/'result-ready.json').unlink(missing_ok=True)
                raise ValueError(BLOCKED_MESSAGE)
            checkpoint.write(work/'normalized-result.json',compact)
            checkpoint.write(work/'local-repairs.json',repairs)
            metrics['local_repair_count']=len(repairs)
            self.stamp(gid,'running',request_id=request_id,phase='saving')
            save_start=time.monotonic()
            _,db=study.connect(self.root)
            try:
                group=checkpoint.same_input(self.root,db,gid,identity,request_id)
                result=expand_result(self.root,db,group,files,compact)
                for q in result['questions']:
                    if q.get('diagram'):
                        from pc_diagram import render_diagram
                        asset=render_diagram(self.root,q.pop('diagram'))
                        q.setdefault('content',{'version':1,'blocks':[{'type':'paragraph','runs':[{'text':q['text']}]}]})['blocks'].append({'type':'image','asset':asset})
                        q['diagramReviewRequired']=True
                checkpoint.same_input(self.root,db,gid,identity,request_id)
                pc_store.put_results(self.root,db,gid,result,expected_request_id=request_id)
            finally:db.close()
            metrics.update(status='completed',question_count=len(result['questions']),save_elapsed_seconds=round(time.monotonic()-save_start,3))
            notes=[]
            if repairs:notes.append('已在本地完成格式兼容处理，原始识别输出已保留。请对照原图复核。')
            if result['paper']['coverage']=='partial':notes.append('当前按已识别内容展示，尚未确认覆盖整卷。若发现漏题，请在对应页圈选补充，无需重跑整卷。')
            missing=[f"第{q['page']}页 {q['number']}" for q in result['questions'] if q['verdict']!='correct' and not q.get('box')]
            if missing:notes.append('以下题目定位待核对，可选择题号后调整题框：'+'、'.join(missing[:12])+('等' if len(missing)>12 else ''))
            self.stamp(gid,'completed',request_id=request_id,recovery={'available':False},notes=notes)
        except subprocess.TimeoutExpired:
            metrics.update(status='failed',error_kind='timeout',usage_complete=False)
            self.stamp(gid,'failed','识别超过 20 分钟，已停止。请检查连接后重试。',request_id=request_id)
        except Exception as error:
            metrics.update(status='failed',error_kind=type(error).__name__,error=str(error)[:1000])
            self.stamp(gid,'failed',checkpoint.failure_message(error,has_result),request_id=request_id,recovery={'available':has_result or recovery_expected})
        finally:
            metrics.update(finished_at=study.now(),elapsed_seconds=round(time.monotonic()-started,3))
            try:(work/'usage.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
            except OSError:pass
            with self.lock:self.active.pop(gid,None);self.processes.pop(gid,None)

    def close(self):
        with self.lock:
            self.closed=True;procs=list(self.processes.values());threads=list(self.active.values())
        for proc in procs:
            if proc.poll() is None:proc.terminate()
        for thread in threads:thread.join(timeout=5)

    def recover(self):
        _,db=study.connect(self.root)
        try:groups=pc_store.meta(db,'pc_recognition',{'groups':[]})['groups']
        finally:db.close()
        for g in groups:
            report=g.get('reportTask')
            if report and report.get('status') in ('queued','running'):
                from report_recognition import stamp
                stamp(self.root,g['id'],report['id'],'failed',error='上次整卷分析已中断；已保存的内容会复用，请点击重试。')
            task=g.get('supplementTask')
            if task and task.get('status') in ('queued','running'):
                from supplement_recognition import stamp
                stamp(self.root,g['id'],task['id'],'failed',error='上次补充题识别已中断，原题记录已保留。请点击重试当前区域。')
            if g.get('requested') and not g.get('recognized'):
                self.stamp(g['id'],'failed','上次识别已中断，请点击重新识别。',request_id=g.get('requestId'))
