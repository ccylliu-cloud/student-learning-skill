"""Single-student settings and derived grade folders; never re-grade historical work.

The caller owns service restart/root switching. Profile saves use a savepoint,
so they compose with an outer transaction. Folder indexes are disposable views.
"""
from __future__ import annotations
import datetime as dt
import html
import json
import os
import shutil
import sqlite3
import stat
import tempfile
import uuid
from pathlib import Path
from urllib.parse import quote, unquote

SUBJECTS = {'math': '数学', 'chinese': '语文', 'english': '英语'}
GRADE_LABELS = ('一年级', '二年级', '三年级', '四年级', '五年级', '六年级',
                '七年级', '八年级', '九年级', '高一', '高二', '高三')
INDEX_OWNER = 'student-learning-grade-index-v1'


def _today(today=None):
    if today is None:
        return dt.date.today()
    if isinstance(today, dt.datetime):
        return today.date()
    if isinstance(today, dt.date):
        return today
    return dt.date.fromisoformat(today)


def school_year(today=None):
    day = _today(today)
    return day.year if day.month >= 9 else day.year - 1


def _grade(value):
    return value if type(value) is int and 1 <= value <= 12 else None


def grade_label(grade):
    return GRADE_LABELS[grade - 1] if _grade(grade) else '未分年级'


def _meta(db, key, default):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return json.loads(row[0]) if row else default


def _json(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n'


def read_profile(root, db, today=None):
    raw = _meta(db, 'pc_profile', {})
    if not isinstance(raw, dict):
        raw = {}
    year = school_year(today)
    anchor = raw.get('gradeAnchorYear', year)
    if type(anchor) is not int or not 1900 <= anchor <= 9999:
        anchor = year
    grade = _grade(raw.get('grade'))
    if grade is not None:
        grade = min(12, grade + max(0, year - anchor))
    name = raw.get('name', '')
    name = name.strip() if isinstance(name, str) else ''
    values = raw.get('selectedSubjects', list(SUBJECTS.values()))
    subjects = list(dict.fromkeys(s for s in values if isinstance(s, str) and s in SUBJECTS.values())) if isinstance(values, list) else []
    complete = raw.get('onboardingComplete') is True and bool(name) and len(name) <= 60 and grade is not None and bool(subjects)
    return {'name': name, 'grade': grade, 'gradeLabel': grade_label(grade),
            'gradeAnchorYear': anchor, 'selectedSubjects': subjects,
            'onboardingComplete': complete, 'storageRoot': str(Path(root).expanduser().resolve()),
            'needsSetup': not complete}


def _plain_path(path):
    """Reject symlinks in every existing component, before resolving."""
    p = Path(os.path.abspath(Path(path).expanduser()))
    for part in (p, *p.parents):
        if part.is_symlink():
            raise ValueError('存储路径不能经过软链接')
    return p


def _mkdir(path):
    p = _plain_path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_profile(root, db, data, today=None):
    if not isinstance(data, dict):
        raise ValueError('学生设置必须为对象')
    name = data.get('name')
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 60:
        raise ValueError('姓名不能为空，且不能超过60个字符')
    grade = _grade(data.get('grade'))
    if grade is None:
        raise ValueError('请选择一年级至高三的年级')
    subjects = data.get('selectedSubjects')
    if not isinstance(subjects, list) or not subjects or any(not isinstance(s, str) or s not in SUBJECTS.values() for s in subjects):
        raise ValueError('请至少选择数学、语文、英语中的一科')
    subjects = list(dict.fromkeys(subjects))
    value = {'name': name.strip(), 'grade': grade, 'gradeAnchorYear': school_year(today),
             'selectedSubjects': subjects, 'onboardingComplete': True}
    for subject in subjects:
        _mkdir(Path(root) / grade_label(grade) / subject)
    before = _meta(db, 'pc_profile', None)
    db.execute('SAVEPOINT save_student_profile')
    try:
        db.execute('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                   ('pc_profile', _json(value)))
        if before != value:
            db.execute('INSERT INTO events(entity_id,kind,before_json,after_json,created) VALUES(?,?,?,?,?)',
                       ('student-profile', 'pc_profile_revision', _json(before) if before is not None else None,
                        _json(value), dt.datetime.now(dt.timezone.utc).isoformat()))
        db.execute('RELEASE SAVEPOINT save_student_profile')
    except Exception:
        db.execute('ROLLBACK TO SAVEPOINT save_student_profile')
        db.execute('RELEASE SAVEPOINT save_student_profile')
        raise
    return read_profile(root, db, today)


_CURRENT_GRADE = object()

def subject_folder(root, db, subject, grade=_CURRENT_GRADE):
    name = SUBJECTS.get(subject, subject)
    if name not in SUBJECTS.values():
        raise ValueError('学科尚未接入')
    if grade is _CURRENT_GRADE:
        grade = read_profile(root, db)['grade']
    elif grade is not None and _grade(grade) is None:
        raise ValueError('年级必须为1至12')
    return _mkdir(Path(root) / grade_label(grade) / name)


def prepare_storage_copy(oldroot, target):
    """Create a verified copy, retaining the source. Does not switch configuration.

    The service must stop accepting work and ensure recognition jobs are inactive
    before calling. SQLite writes are locked during copy; external filesystem
    writers must be quiesced by the caller. Failed staging is removed.
    """
    source, target = _plain_path(oldroot), _plain_path(target)
    if source == target or source in target.parents or target in source.parents:
        raise ValueError('新目录不能与当前目录相同，也不能互为父子目录')
    if not source.is_dir() or not (source / 'study.sqlite3').is_file():
        raise ValueError('当前档案不存在')
    if target.exists() and (not target.is_dir() or any(target.iterdir())):
        raise ValueError('请选择不存在或完全为空的目标目录')
    # Preflight every archive entry. In particular do not copy links to unrelated data.
    for directory, dirs, files in os.walk(source, followlinks=False):
        for name in dirs + files:
            path = Path(directory) / name
            mode = path.lstat().st_mode
            if stat.S_ISLNK(mode) or not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
                raise ValueError('档案包含软链接或特殊文件，不能安全复制：' + str(path.relative_to(source)))
    _mkdir(target.parent)
    staging = Path(tempfile.mkdtemp(prefix='.student-learning-copy-', dir=target.parent))
    lock = reader = destdb = None
    existed = target.exists()
    try:
        lock = sqlite3.connect(source / 'study.sqlite3', timeout=30)
        lock.execute('BEGIN IMMEDIATE')
        reader = sqlite3.connect((source / 'study.sqlite3').as_uri() + '?mode=ro', uri=True, timeout=30)
        destdb = sqlite3.connect(staging / 'study.sqlite3')
        reader.backup(destdb)
        if destdb.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ValueError('新档案数据库完整性检查失败')
        destdb.close(); destdb = None
        for entry in source.iterdir():
            if entry.name in {'study.sqlite3', 'study.sqlite3-wal', 'study.sqlite3-shm', 'study.sqlite3-journal'}:
                continue
            dest = staging / entry.name
            if entry.is_dir():
                shutil.copytree(entry, dest)
            else:
                shutil.copy2(entry, dest)
        # Recheck the destination immediately before publishing. No overwrite of data.
        if target.exists():
            if target.is_symlink() or not target.is_dir() or any(target.iterdir()):
                raise ValueError('目标目录已发生变化，复制未生效')
            target.rmdir()
        staging.rename(target)
        return target
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        if existed and not target.exists():
            target.mkdir()
        raise
    finally:
        if destdb is not None: destdb.close()
        if reader is not None: reader.close()
        if lock is not None:
            lock.rollback(); lock.close()


def _snapshot_grade(value):
    # Only explicit metadata counts. Never infer a historical grade from date/name.
    return _grade(value.get('grade')) if isinstance(value, dict) else None


def _atomic_text(path, text):
    _plain_path(path)
    if path.exists() and path.read_text(encoding='utf-8') == text:
        return False
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temp.write_text(text, encoding='utf-8')
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)
    return True


def sync_grade_folders(root, db):
    """Write derived JSON records, per-folder original copies and HTML indexes.

    Grade is the explicit question snapshot, else its paper snapshot. Recognition
    groups/pages and practice papers use their own snapshots. Missing snapshots
    go to 未分年级; current profile is never used to guess historical grade.
    Existing database records and canonical assets are read only.
    """
    root = _plain_path(root)
    buckets = {}
    def bucket(grade, subject):
        name = SUBJECTS.get(subject, subject)
        if name not in SUBJECTS.values():
            return None
        key = (grade_label(grade), name)
        return buckets.setdefault(key, {'owner': INDEX_OWNER, 'grade': _grade(grade), 'subject': name,
                                        'authority': '统一study.sqlite3为权威；本目录为可重建副本，手工编辑不回写档案',
                                        'papers': [], 'questions': [], 'wrongQuestionIds': [],
                                        'recognitionGroups': [], 'pages': [], 'practicePapers': []})
    papers = {}
    for pid, payload in db.execute('SELECT id,payload FROM papers ORDER BY id'):
        p = json.loads(payload); p = {**p, 'id': pid}; papers[pid] = p
        b = bucket(_snapshot_grade(p), p.get('subject'))
        if b is not None: b['papers'].append(p)
    for qid, pid, subject, payload in db.execute('SELECT id,paper_id,subject,payload FROM questions ORDER BY id'):
        q = json.loads(payload); g = _snapshot_grade(q)
        if g is None: g = _snapshot_grade(papers.get(pid))
        b = bucket(g, subject)
        if b is not None:
            b['questions'].append({**q, 'id': qid, 'paper_id': pid, 'subject': subject})
            if q.get('verdict') == 'wrong' and q.get('decision_status') == 'confirmed' and not q.get('pc_excluded'):
                b['wrongQuestionIds'].append(qid)
    recognition = _meta(db, 'pc_recognition', {'pages': [], 'groups': []})
    pages = {p['id']: p for p in recognition.get('pages', [])}
    grouped = set()
    for group in recognition.get('groups', []):
        b = bucket(_snapshot_grade(group), group.get('subject'))
        if b is not None: b['recognitionGroups'].append(group)
        for pid in group.get('pageIds', []):
            p = pages.get(pid)
            if not p: continue
            grouped.add(pid)
            g = _snapshot_grade(p)
            pb = bucket(g if g is not None else _snapshot_grade(group), p.get('subject', group.get('subject')))
            if pb is not None and not any(x['id'] == pid for x in pb['pages']): pb['pages'].append(p)
    for pid, p in pages.items():
        if pid not in grouped:
            b = bucket(_snapshot_grade(p), p.get('subject'))
            if b is not None: b['pages'].append(p)
    for pid, p in sorted(_meta(db, 'pc_practice', {}).items()):
        b = bucket(_snapshot_grade(p), p.get('subject'))
        if b is not None: b['practicePapers'].append({**p, 'id': pid})
    # Existing owned indexes can be emptied after a correction; never remove user files.
    for grade in (*GRADE_LABELS, '未分年级'):
        for subject in SUBJECTS.values():
            path = root / grade / subject / '学习记录.json'
            _plain_path(path)
            if path.is_file():
                previous = json.loads(path.read_text(encoding='utf-8'))
                if previous.get('owner') != INDEX_OWNER:
                    raise ValueError('同名目录文件非本程序索引，未覆盖：' + str(path))
                if (grade, subject) not in buckets:
                    g = GRADE_LABELS.index(grade) + 1 if grade in GRADE_LABELS else None
                    bucket(g, subject)
    count = changed = 0
    for (grade, subject), value in sorted(buckets.items()):
        folder = _mkdir(root / grade / subject)
        links = {}
        def visit(node):
            if isinstance(node, dict):
                for key, item in node.items():
                    if key in {'path', 'url'} and isinstance(item, str):
                        relative = 'assets/' + unquote(item[len('/files/'):]) if item.startswith('/files/') else item
                        if relative.startswith('assets/'):
                            asset = root / relative
                            try:
                                asset = _plain_path(asset)
                                asset.relative_to(root / 'assets')
                            except ValueError:
                                continue
                            if asset.is_file():
                                originals = _mkdir(folder / '原件')
                                copied = _plain_path(originals / asset.name)
                                srcstat = asset.stat()
                                dststat = copied.stat() if copied.exists() else None
                                if dststat is None or (dststat.st_size, dststat.st_mtime_ns) != (srcstat.st_size, srcstat.st_mtime_ns):
                                    temp = originals / ('.' + asset.name + '.' + uuid.uuid4().hex + '.tmp')
                                    try:
                                        shutil.copy2(asset, temp)
                                        temp.replace(copied)
                                    finally:
                                        temp.unlink(missing_ok=True)
                                href = os.path.relpath(copied, folder)
                                links[href] = node.get('label') or node.get('original_name') or asset.name
                    visit(item)
            elif isinstance(node, list):
                for item in node: visit(item)
        visit(value)
        value['assetLinks'] = [{'path': path, 'label': label} for path, label in sorted(links.items())]
        # The ownership marker protects an unrelated file with the same name.
        html_path = folder / '原图索引.html'
        _plain_path(html_path)
        if html_path.exists() and f'<!-- {INDEX_OWNER} -->' not in html_path.read_text(encoding='utf-8'):
            raise ValueError('同名原图索引非本程序文件，未覆盖：' + str(html_path))
        listing = ''.join(f'<li><a href="{html.escape(quote(path, safe="/"), quote=True)}">{html.escape(str(label))}</a></li>' for path, label in sorted(links.items()))
        document = f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><!-- {INDEX_OWNER} --><title>{grade}·{subject}</title><h1>{grade}·{subject}</h1><p>本页链接本年级学科的原图副本。统一数据库与素材目录为权威，编辑副本不会回写学习档案。完整题目与学习记录见 <a href="学习记录.json">学习记录.json</a>。</p><ul>{listing}</ul></html>\n'
        changed += _atomic_text(folder / '学习记录.json', _json(value))
        changed += _atomic_text(html_path, document)
        count += 1
    return {'folders': count, 'changedFiles': changed}
