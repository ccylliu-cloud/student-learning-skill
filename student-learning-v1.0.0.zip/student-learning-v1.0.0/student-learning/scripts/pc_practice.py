"""Practice scans update one existing practice attempt, never canonical questions."""
from pathlib import Path
import hashlib
import json
import pc_store as s
import study


def group_id(paper_id):
    return 'practice-scan-' + paper_id


def _canonical(db, paper):
    result = {}
    for qid in paper['questionIds']:
        row = db.execute('SELECT subject,payload FROM questions WHERE id=?', (qid,)).fetchone()
        s.require(row and s.SUBJECTS[row['subject']] == paper['subject'], '复练原题不存在或学科不符')
        result[qid] = json.loads(row['payload'])
    return result


def _stage(root, db, paths, paper_id, date):
    practices = s.meta(db, 'pc_practice', {})
    paper = practices.get(paper_id)
    s.require(paper, '复习卷不存在')
    date = s.real_date(date)
    existing_date = paper.get('pc_result_date')
    s.require(not paper.get('savedResults') or existing_date, '已确认复练缺少原始作答日期，请先核对历史记录')
    s.require(not existing_date or s.real_date(existing_date) == date, '本卷已有其他日期作答；新一次复练请重新组卷')
    s.require(isinstance(paths, (list, tuple)) and paths, '请提供复练原图')
    assets = [s._stage_file(root, p) for p in paths]
    recognition = s.meta(db, 'pc_recognition', {'pages': [], 'groups': []})
    before = s.clone(recognition)
    gid = group_id(paper_id)
    group = next((g for g in recognition['groups'] if g['id'] == gid), None)
    ids = list(dict.fromkeys('practice-page-' + paper_id + '-' + a['sha256'] for a in assets))
    if group:
        s.require(group.get('kind') == 'practice' and group.get('practicePaperId') == paper_id, '复练分组身份冲突')
        s.require(group.get('resultDate') == date, '本卷已有其他日期作答；新一次复练请重新组卷')
        # Preserve a received scan and any human edits on exact re-uploads.
        s.require(set(ids) <= set(group['pageIds']) or not (group.get('recognized') or group.get('requested') or group.get('runStatus') in ('queued','running')), '识别后不能更换原图；请修订已有结果')
    else:
        group = {'id': gid, 'kind': 'practice', 'practicePaperId': paper_id, 'grade':paper.get('grade'),
                 'paperId': paper_id, 'title': paper['title'] + ' · 复练批改',
                 'subject': paper['subject'], 'resultDate': date, 'pageIds': [],
                 'questions': [], 'recognized': False, 'requested': False, 'finalized': False}
        recognition['groups'].append(group)
    for asset in assets:
        pid = 'practice-page-' + paper_id + '-' + asset['sha256']
        if not any(p['id'] == pid for p in recognition['pages']):
            recognition['pages'].append({'id': pid, 'label': asset['original_name'],
                'url': s.file_asset(root, asset)['url'], 'subject': paper['subject'], 'date': date.replace('-', '.')})
        if pid not in group['pageIds']:
            group['pageIds'].append(pid)
    old_paper = s.clone(paper)
    page_map = {p['id']: p for p in recognition['pages']}
    existing_sources = {a['url']: a for a in paper.get('sources', [])}
    paper['sources'] = [s.clone(existing_sources.get(page_map[p]['url']) or {'url': page_map[p]['url'], 'label': page_map[p]['label']}) for p in group['pageIds']]
    paper['pc_result_date'] = date
    if paper != old_paper:
        s.put_meta(db, 'pc_practice', practices)
        study.event(db, paper_id, 'pc_practice_stage', old_paper, paper)
    if recognition != before:
        s.put_meta(db, 'pc_recognition', recognition)
        study.event(db, gid, 'stage_practice_pages', before, recognition)
    return ids


def stage_practice_pages(root, db, paths, paper_id, date):
    db.execute('BEGIN IMMEDIATE')
    try:
        ids = _stage(root, db, paths, paper_id, date)
        db.commit()
    except Exception:
        db.rollback()
        raise
    return dict(s.read_archive(root, db), stagedPageIds=ids, practiceRecognitionId=group_id(paper_id))


def _scan(db, group, canonical, qid, detail, number, page, box, confirmed=False):
    records, _ = s.knowledge_catalog(db)
    ids, names = s.question_knowledge(canonical, s.subject_code(group['subject']), records)
    verdict = detail.get('verdict') or {'incorrect': 'wrong', 'wrong': 'wrong', 'correct': 'correct'}.get(detail.get('result'), 'pending')
    result = {'id': group['id'] + '-q-' + hashlib.sha256(qid.encode()).hexdigest()[:16],
        'canonicalId': qid, 'pageId': page, 'number': number,
        'fullText': canonical['text'], 'answer': canonical.get('expected_answer') or '',
        'analysis': canonical.get('explanation') or '', 'studentAnswer': detail.get('answer') or '',
        'knowledgeIds': ids, 'knowledgePoints': names, 'reasons': [],
        'box': s._box(box), 'boxVerified': not bool(detail.get('location_note')), 'status': 'saved' if confirmed else 'pending',
        'verdict': verdict, 'decisionStatus': 'confirmed' if confirmed else 'pending',
        'evidence': detail.get('evidence') or '', 'independent': detail.get('independent', False),
        **s.content_fields(canonical)}
    result['reviewNote'] = detail.get('location_note') or ('' if confirmed else '待人工复核：' + (detail.get('evidence') or '请核对本次复练作答'))
    return result


def put_practice_recognition(root, db, gid, data, expected_request_id=None):
    db.execute('BEGIN IMMEDIATE')
    try:
        recognition = s.meta(db, 'pc_recognition', {'pages': [], 'groups': []})
        group = next((g for g in recognition['groups'] if g['id'] == gid), None)
        s.require(group and group.get('kind') == 'practice' and group['pageIds'], '复练识别分组不存在')
        if expected_request_id is not None:
            s.require(group.get('requestId') == expected_request_id and group.get('requested') is True, '识别请求已更新或结束，旧执行结果不再写入')
        practices = s.meta(db, 'pc_practice', {})
        paper = practices[group['practicePaperId']]
        canonical = _canonical(db, paper)
        incoming = s.clone(data)
        p = incoming.get('paper', {})
        s.require(s.subject_code(p.get('subject')) == s.subject_code(group['subject']), '识别结果与复练学科不符')
        s.require(p.get('id') in (paper['id'], gid) and s.real_date(p.get('date')) == group['resultDate'], '复练卷ID或真实作答日期不符')
        s.require(p.get('page_count') == len(group['pageIds']), '复练结果页数不符')
        pages = {p['id']: p for p in recognition['pages']}
        expected = [s.source_path(root, pages[pid]['url']) for pid in group['pageIds']]
        supplied = p.get('sources', [])
        s.require(len(supplied) == len(expected) and all(hashlib.sha256(Path(a).expanduser().read_bytes()).digest() == hashlib.sha256(b.read_bytes()).digest() for a, b in zip(supplied, expected)), '识别结果原图与复练分组不符')
        qs = incoming.get('questions')
        s.require(isinstance(qs, list) and len(qs) == len(canonical) and all(isinstance(q,dict) for q in qs), '复练识别需完整逐题对应原组卷')
        qids = [q.get('question_id') for q in qs]
        s.require(all(isinstance(qid,str) for qid in qids) and len(set(qids)) == len(qids) and set(qids) == set(canonical), '复练题目映射缺失、重复或不属于本卷')
        for q in qs:
            original=canonical[q['question_id']]
            ids,_=s.question_knowledge(original,s.subject_code(paper['subject']),s.knowledge_catalog(db)[0])
            q.update(text=original['text'],expected_answer=original.get('expected_answer'),explanation=original.get('explanation'),knowledgeIds=ids,observed_error='',attributions=[],**s.content_fields(original))
            s.require(q.get('basis') != 'user_confirmed', '模型识别不能冒充用户确认')
            q['decision_status'] = 'pending'
            s.require(isinstance(q.get('student_answer'), str) or q.get('student_answer') is None, '本次作答必须为文字或待辨认')
            s.require(study.nonempty(q.get('evidence')), '需保留本次批改证据')
            s.require(type(q.get('independent', False)) is bool, '独立完成标记无效')
            s._box(q.get('box') or q.get('pc_box') or {'x':0,'y':0,'width':100,'height':100})
        p['sources'] = [str(path) for path in expected]
        prepared = s._prepare_paper(root, db, incoming, trusted_practice=True)
        digest = hashlib.sha256(study.dumps(prepared).encode()).hexdigest()
        drafts = s.meta(db, 'pc_drafts', {})
        if group.get('recognized'):
            s.require(drafts.get(gid, {}).get('pc_input_digest') == digest, '本组已有识别结果，请在页面修订，不能覆盖人工确认')
            db.commit()
            return s.read_archive(root, db)
        before_paper, before_group = s.clone(paper), s.clone(group)
        details, results, scans = {}, {}, []
        for q in prepared['questions']:
            qid = q['question_id']
            eligible = set(s.question_knowledge(canonical[qid], s.subject_code(paper['subject']), s.knowledge_catalog(db)[0])[0])
            verified = q.get('knowledge_point_ids', [])
            s.require(isinstance(verified, list) and set(verified) <= eligible, '复练验证知识点必须来自原题正式关联')
            box = q.get('box') or q.get('pc_box') or {'x':0,'y':0,'width':100,'height':100}
            detail = {'answer': q.get('student_answer') or '', 'evidence': q['evidence'],
                'independent': q.get('independent', False), 'knowledge_point_ids': verified,
                'verdict': q['verdict'], 'expected_answer': q.get('expected_answer'),
                'explanation': q.get('explanation'), 'corrected_answer': q.get('corrected_answer'),
                'page': q['page'], 'number': q['number'], 'box': s._box(box),
                'evidence_level': q['evidence_level'], 'basis': q['basis']}
            if not (q.get('box') or q.get('pc_box')):
                detail['location_note'] = '未核对题框；当前显示全页原图'
            if q['verdict'] in ('correct', 'wrong'):
                detail['result'] = results[qid] = 'correct' if q['verdict'] == 'correct' else 'incorrect'
            details[qid] = detail
            scans.append(_scan(db, group, canonical[qid], qid, detail, q['number'], group['pageIds'][q['page']-1], box))
        # Keep original question wording and knowledge in the linked scan projection.
        group.update(recognized=True, requested=False, runStatus='completed', questions=scans,
            coverage=p['coverage'], expectedQuestionCount=len(canonical), finalized=False)
        group.pop('error', None)
        paper.update(results=results, pc_result_details=details, pc_result_date=group['resultDate'])
        paper.setdefault('pc_result_received_at', study.now())
        prepared['pc_input_digest'] = digest
        drafts[gid] = prepared
        s.put_meta(db, 'pc_drafts', drafts)
        s.put_meta(db, 'pc_practice', practices)
        s.put_meta(db, 'pc_recognition', recognition)
        study.event(db, gid, 'practice_recognition_result', {'paper': before_paper, 'group': before_group}, {'paper': paper, 'group': group})
        db.commit()
    except Exception:
        db.rollback()
        raise
    return s.read_archive(root, db)


def _save_confirmed(paper, scans):
    saved = {q['canonicalId']: 'correct' if q['verdict'] == 'correct' else 'incorrect' for q in scans}
    paper['savedResults'] = saved
    paper['status'] = '已批改'
    dates = paper.setdefault('pc_result_dates', {})
    times = paper.setdefault('pc_result_recorded_at', {})
    for qid in saved:
        dates.setdefault(qid, paper['pc_result_date'])
        times.setdefault(qid, paper.get('pc_result_received_at') or study.now())


def apply_group(root, db, previous, group):
    if group == previous:
        return
    for key in ('kind','practicePaperId','paperId','resultDate','pageIds','subject','coverage','expectedQuestionCount'):
        s.require(group.get(key) == previous.get(key), '不能替换复练来源、日期或题目范围')
    old_q = {q['id']: q for q in previous['questions']}
    qs = group.get('questions')
    s.require(isinstance(qs,list) and len(qs) == len(old_q) and {q['id'] for q in qs} == set(old_q), '复练不能新增、删除或重复原题映射')
    practices = s.meta(db, 'pc_practice', {})
    paper = practices[group['practicePaperId']]
    before = s.clone(paper)
    for q in qs:
        old = old_q[q['id']]
        for key in ('canonicalId','number','pageId','fullText','answer','analysis','knowledgeIds','knowledgePoints','reasons',*s.CONTENT_FIELDS):
            s.require(q.get(key) == old.get(key), '复练不能替换原题、题号、知识点或来源；请在原错题详情中修改')
        s.require(q.get('status') in ('pending','saved'), '复练原题不能排除；无法判断时请保留待确认')
        s.require(q.get('verdict') in study.VERDICTS and q.get('decisionStatus') in ('pending','confirmed'), '复练判定或确认状态无效')
        s.require(q['verdict'] != 'pending' or q['decisionStatus'] == 'pending', '待确认题不能标为已确认')
        s.require(isinstance(q.get('studentAnswer'),str), '本次作答必须为文字')
        s.require(isinstance(q.get('evidence',''),str) and type(q.get('independent',False)) is bool, '复练证据或独立完成标记无效')
        s._box(q['box'])
        s.require(type(q.get('boxVerified',True)) is bool,'题框核对状态无效')
        q.pop('savedQuestionId', None)
        detail = paper.setdefault('pc_result_details', {}).setdefault(q['canonicalId'], {})
        detail.update(answer=q['studentAnswer'], evidence=q.get('evidence',detail.get('evidence','')), independent=q.get('independent',detail.get('independent',False)), box=s.clone(q['box']), boxVerified=q.get('boxVerified',True), human_verdict=q['verdict'])
    verdicts = {q['canonicalId']: 'correct' if q['verdict']=='correct' else 'incorrect' for q in qs if q['verdict'] in ('correct','wrong')}
    if paper.get('results',{}) != verdicts:
        paper.setdefault('pc_model_results',s.clone(paper.get('results',{})))
        paper['results'] = verdicts
    complete = bool(qs) and all(q['status']=='saved' and q['decisionStatus']=='confirmed' and q['verdict'] in ('correct','wrong') for q in qs)
    s.require(not previous.get('finalized') or complete, '已保存复练不能撤销为草稿，请直接修正判定')
    group['finalized'] = complete
    if complete:
        _save_confirmed(paper, qs)
    if paper != before:
        s.put_meta(db, 'pc_practice', practices)
        study.event(db, paper['id'], 'pc_practice_recognition_save', before, paper)


def sync_saved_group(db, paper):
    recognition = s.meta(db, 'pc_recognition', {'pages': [], 'groups': []})
    before = s.clone(recognition)
    group = next((g for g in recognition['groups'] if g.get('kind') == 'practice' and g.get('practicePaperId') == paper['id']), None)
    if not group or not group.get('recognized'):
        return
    paper.setdefault('pc_model_results',s.clone(paper.get('results',{})))
    paper['results'] = s.clone(paper['savedResults'])
    for q in group['questions']:
        value = paper.get('savedResults', {}).get(q['canonicalId'])
        if value:
            q.update(verdict='correct' if value=='correct' else 'wrong', decisionStatus='confirmed', status='saved')
            paper.setdefault('pc_result_details', {}).setdefault(q['canonicalId'], {})['human_verdict'] = q['verdict']
    group['finalized'] = len(paper.get('savedResults', {})) == len(paper['questionIds'])
    if recognition != before:
        s.put_meta(db,'pc_recognition',recognition)
        study.event(db,group['id'],'pc_practice_grading_sync',before,recognition)


def backfill_practice_recognition(root, db):
    """Project existing real results into scan groups without creating new attempts."""
    own = not db.in_transaction
    if own: db.execute('BEGIN IMMEDIATE')
    try:
        created = []
        for paper in list(s.meta(db,'pc_practice',{}).values()):
            gid = group_id(paper['id'])
            recognition = s.meta(db,'pc_recognition',{'pages':[],'groups':[]})
            if any(g['id']==gid for g in recognition['groups']) or not paper.get('sources') or not (paper.get('results') or paper.get('savedResults')):
                continue
            date = paper.get('pc_result_date')
            if not date: continue  # Unknown dates must never be fabricated.
            _stage(root,db,[s.source_path(root,a['url']) for a in paper['sources']],paper['id'],date)
            recognition = s.meta(db,'pc_recognition',{'pages':[],'groups':[]})
            before = s.clone(recognition)
            group = next(g for g in recognition['groups'] if g['id']==gid)
            canonical = _canonical(db,paper)
            scans=[]
            for index,qid in enumerate(paper['questionIds'],1):
                detail=s.clone(paper.get('pc_result_details',{}).get(qid,{}))
                value=paper.get('savedResults',{}).get(qid) or paper.get('results',{}).get(qid)
                detail['verdict']={'correct':'correct','incorrect':'wrong'}.get(value,'pending')
                page=detail.get('page', detail.get('source_page',1))
                if type(page) is not int or not 1<=page<=len(group['pageIds']): page=1
                box=detail.get('box') or {'x':0,'y':0,'width':100,'height':100}
                if not detail.get('box'):
                    detail['location_note']='历史记录未核对题框；当前显示全页原图' if ('page' in detail or 'source_page' in detail) else '历史记录未核对题框与所在页；当前显示首张全页原图，请对照全部来源核对'
                scans.append(_scan(db,group,canonical[qid],qid,detail,detail.get('number') or str(index),group['pageIds'][page-1],box,qid in paper.get('savedResults',{})))
            group.update(recognized=True,requested=False,runStatus='completed',questions=scans,coverage='full',expectedQuestionCount=len(scans),finalized=all(q['decisionStatus']=='confirmed' for q in scans))
            s.put_meta(db,'pc_recognition',recognition)
            study.event(db,gid,'pc_practice_history_backfill',before,recognition)
            created.append(gid)
        if own: db.commit()
    except Exception:
        if own: db.rollback()
        raise
    return dict(s.read_archive(root,db),backfilledPracticeRecognitionIds=created)


def sync_imported_results(root, db, paper_id):
    """Legacy CLI import keeps confirmed answers authoritative and flags new evidence."""
    backfill_practice_recognition(root, db)
    papers = s.meta(db, 'pc_practice', {})
    paper = papers[paper_id]
    recognition = s.meta(db, 'pc_recognition', {'pages': [], 'groups': []})
    before = s.clone(recognition)
    group = next((g for g in recognition['groups'] if g.get('practicePaperId') == paper_id), None)
    if not group:
        return
    for q in group['questions']:
        qid = q['canonicalId']
        detail = paper.get('pc_result_details', {}).get(qid, {})
        saved = paper.get('savedResults', {}).get(qid)
        predicted = paper.get('results', {}).get(qid)
        q.update(studentAnswer=detail.get('answer',''), evidence=detail.get('evidence',''), independent=detail.get('independent',False))
        q['verdict'] = 'correct' if (saved or predicted) == 'correct' else 'wrong' if (saved or predicted) == 'incorrect' else 'pending'
        q['decisionStatus'] = 'confirmed' if saved else 'pending'
        q['status'] = 'saved' if saved else 'pending'
        if saved and predicted != saved:
            q['reviewNote'] = '新导入预判与已确认结果不同；保留人工确认结果，请核对新证据'
    if recognition != before:
        s.put_meta(db,'pc_recognition',recognition)
        study.event(db,group['id'],'pc_practice_import_sync',before,recognition)


def project_group(db, group, records):
    """Refresh linked original wording exactly as PcPaper.questions does."""
    for scan in group.get('questions', []):
        row = db.execute('SELECT subject,payload FROM questions WHERE id=?', (scan['canonicalId'],)).fetchone()
        if not row:
            continue
        canonical = json.loads(row['payload'])
        ids, names = s.question_knowledge(canonical, row['subject'], records)
        scan.update(fullText=canonical['text'],answer=canonical.get('expected_answer') or '',analysis=canonical.get('explanation') or '',knowledgeIds=ids,knowledgePoints=names)
        for key in s.CONTENT_FIELDS:
            if key in canonical: scan[key] = s.clone(canonical[key])
            else: scan.pop(key, None)
