"""Render bounded geometric primitives supplied by Codex, for user review."""
import hashlib,io,math,os
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

def render_diagram(root,spec):
    def require(ok,msg):
        if not ok:raise ValueError(msg)
    require(isinstance(spec,dict),'题图描述无效')
    w,h=spec.get('width'),spec.get('height');require(type(w)is int and type(h)is int and 100<=w<=2400 and 100<=h<=2400,'题图画布尺寸无效')
    elements=spec.get('elements');require(isinstance(elements,list) and 0<len(elements)<=300,'题图元素无效')
    image=Image.new('RGB',(w,h),'white');draw=ImageDraw.Draw(image)
    def n(e,key,maximum):
        value=e.get(key);require(type(value) in (int,float) and math.isfinite(value) and 0<=value<=maximum,'题图坐标无效');return value
    font_paths=[Path('/System/Library/Fonts/Supplemental/Arial Unicode.ttf'),Path('/Library/Fonts/Arial Unicode.ttf'),Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts/msyh.ttc',Path(os.environ.get('WINDIR','C:/Windows'))/'Fonts/simsun.ttc']
    for e in elements:
        require(isinstance(e,dict),'题图元素无效');kind=e.get('type')
        if kind=='text':
            text=e.get('text');require(isinstance(text,str) and len(text)<=300,'题图文字无效');size=int(e.get('size',30));require(12<=size<=100,'题图字号无效')
            path=next((p for p in font_paths if p.exists()),None)
            require(path is not None or not any(ord(c)>127 for c in text),'未找到支持中文的本机字体，请安装系统中文字体后重试，或在网页人工添加题图；没有生成缺字题图')
            font=ImageFont.truetype(str(path),size) if path else ImageFont.load_default(size=size)
            draw.text((n(e,'x',w),n(e,'y',h)),text,fill='black',font=font)
        elif kind=='line':draw.line((n(e,'x1',w),n(e,'y1',h),n(e,'x2',w),n(e,'y2',h)),fill='black',width=3)
        elif kind=='rect':
            x,y=n(e,'x',w),n(e,'y',h);ew,eh=n(e,'width',w),n(e,'height',h);require(x+ew<=w and y+eh<=h,'题图矩形超出画布');draw.rectangle((x,y,x+ew,y+eh),outline='black',width=3)
        elif kind=='circle':
            x,y,r=n(e,'cx',w),n(e,'cy',h),n(e,'r',min(w,h));require(x-r>=0 and x+r<=w and y-r>=0 and y+r<=h,'题图圆超出画布');draw.ellipse((x-r,y-r,x+r,y+r),outline='black',width=3)
        elif kind=='polygon':
            points=e.get('points');require(isinstance(points,list) and 3<=len(points)<=50,'题图多边形无效');require(all(isinstance(p,list) and len(p)==2 and all(type(v) in (int,float) and math.isfinite(v) for v in p) and 0<=p[0]<=w and 0<=p[1]<=h for p in points),'题图坐标无效');draw.polygon([tuple(p) for p in points],outline='black',width=3)
        else:raise ValueError('题图包含不支持的图形，请手工补图')
    out=io.BytesIO();image.save(out,format='PNG');raw=out.getvalue();folder=Path(root)/'assets';folder.mkdir(exist_ok=True);name=hashlib.sha256(raw).hexdigest()+'.png';(folder/name).write_bytes(raw)
    return {'url':'/files/'+name,'label':'对话重建题图（请对照原图核对）'}
