"""Structural evidence validation, never inference about handwriting or mental causes."""
import ast,json,re
FIELDS={'answerEvidence','knowledgeValidation'}
PROMPT = r"""
1.0证据契约（原卷及补题必须，复练只保留本次作答）：
每题增加answerEvidence:{printed_text:"与text/content逐字相同的印刷题干，保留除/除以、否定、单位和全部条件",initial_steps:["逐行原始作答，不能用正确结果修复原字"],correction_steps:["可见订正，未知为空数组"],completeness:"complete|cropped|unknown",transcription_status:"clear|uncertain",uncertain_tokens:["看不清处及原因"],first_error:null或{step:1,kind:"transcription|arithmetic|method|answer_format|unknown",detail:"第一处可见不一致，区分观察事实与原因假设"}}。
student_answer必须等于initial_steps以换行连接的内容（没有可辨初答用null和空数组），corrected_answer必须等于correction_steps换行连接（无订正null）。步骤不因数学不成立而擅自改写；先从图片记录字形，再核对数字复用、符号/关系变化、运算结果。不得从最终得数倒推学生做过的步骤。completeness不是complete或字迹不确定时，verdict用pending/ungradable，first_error可为空并说明缺口。只读到答句不能宣称已核对全部过程。first_error.step为initial_steps的1起始索引，原因不明只写unknown和缺口，不自动确认粗心。
知识必须完成本次语义核对：knowledgeValidation:{status:"matched|no_match|insufficient",reason:"核心目标、规则适用或缺口",reviewed:[{id:"查询过的真实ID",quote:"从该ID完整语义详情中逐字摘录至少8字符的定义/规则/包含或排除边界，非名称或编号"}]}。每个knowledgeIds都必须有reviewed对应，程序核对引文确属当前卡；引用是自述可核对证据，不是独立工具调用证明。候选名称不是正式标签；no_match需至少查过一张相关卡。无法检索/条件不足可insufficient并具体说明，保持空ID和待知识复核，不能用insufficient表示已完成知识关联。可用下方只读kb_lookup查询，不能仅凭内联索引猜规则。原因未知不妨碍先保存可见事实。
requires_image=true但尚无干净题图时说明待清理；原图裁片只作证据，不能用于无答案练习。所有语义判定待人工复核。
"""
def require(ok,message):
    if not ok:raise ValueError(message)
def norm(s):return re.sub(r'\s+','',s or '')
def _strings(value):
    if isinstance(value,str):yield value
    elif isinstance(value,list):
        for v in value:yield from _strings(v)
    elif isinstance(value,dict):
        for k,v in value.items():
            if not any(x in k.lower() for x in ('source','basis','metadata')) and k not in ('type','kind','status','version','id','name','display_name','assessment_id','requested_id','path_names','path_ids','sources','source_refs','aliases'):yield from _strings(v)
def semantic_strings(card):
    # Traverse only actual rules and their boundary/definition fields. Source IDs,
    # authorship and provenance text are intentionally not semantic evidence.
    allowed={'rules','rule','rule_components','conditions','summary','applies_if','decision_steps','boundaries','definition','include','exclude','text','core_concepts_rules','核心概念/规则','适用条件','不适用条件','规则','定义','包含','排除'}
    def walk(value):
        if isinstance(value,str):yield value
        elif isinstance(value,list):
            for child in value:yield from walk(child)
        elif isinstance(value,dict):
            for key,child in value.items():
                if key in allowed:yield from walk(child)
    yield from walk(card)
def validate(db,q,subject):
    e=q.get('answerEvidence');require(isinstance(e,dict),'缺少逐步作答证据answerEvidence；请仅修复本地结果，不重读整卷')
    require(set(e)<= {'printed_text','initial_steps','correction_steps','completeness','transcription_status','uncertain_tokens','first_error'},'作答证据字段无效')
    require(isinstance(e.get('printed_text'),str) and norm(e['printed_text'])==norm(q.get('text')),'印刷题干核对不一致；不能增删除/除以或其他条件')
    for key in ('initial_steps','correction_steps','uncertain_tokens'):
        require(isinstance(e.get(key),list) and len(e[key])<=100 and all(isinstance(x,str) and 0<len(x)<=8000 for x in e[key]),'作答步骤或不确定项格式无效')
    require(e.get('completeness') in ('complete','cropped','unknown'),'缺少作答完整性状态')
    require(e.get('transcription_status') in ('clear','uncertain'),'缺少字迹核对状态')
    for key,source in [('student_answer','initial_steps'),('corrected_answer','correction_steps')]:
        require(norm(q.get(key))==norm('\n'.join(e[source])),key+'与逐步证据不同；初答和订正须独立保存')
    uncertain=e['completeness']!='complete' or e['transcription_status']=='uncertain'
    require(not uncertain or (q.get('verdict') in ('pending','ungradable') and bool(e['uncertain_tokens'])),'题面/作答不完整或字迹不确定时应待核并说明缺口')
    first=e.get('first_error')
    if q.get('verdict')=='wrong':
        require(isinstance(first,dict) and type(first.get('step')) is int and 1<=first['step']<=len(e['initial_steps']),'错题缺少可定位首错步骤')
        require(first.get('kind') in ('transcription','arithmetic','method','answer_format','unknown') and isinstance(first.get('detail'),str) and len(first['detail'].strip())>=4,'首错类型或依据无效')
    if q.get('verdict')=='correct':require(first is None,'正确题不得保存首错')
    k=q.get('knowledgeValidation');require(isinstance(k,dict),'缺少知识核对状态knowledgeValidation')
    require(k.get('status') in ('matched','no_match','insufficient') and isinstance(k.get('reason'),str) and len(k['reason'].strip())>=4,'知识点未关联须说明实际原因')
    reviewed=k.get('reviewed');require(isinstance(reviewed,list) and len(reviewed)<=24,'知识核对记录格式无效')
    from kb_lookup import details
    seen=set()
    for item in reviewed:
        require(isinstance(item,dict) and isinstance(item.get('id'),str) and isinstance(item.get('quote'),str),'知识语义引文格式无效')
        kid=item['id'];require(kid not in seen,'知识核对ID重复');seen.add(kid)
        card=details(db,subject,[kid])[0]
        quote=item['quote'].strip()
        require(len(quote)>=8 and any(quote in t for t in semantic_strings(card)),'知识引文不属于当前规则/边界：'+kid)
    ids=q.get('knowledgeIds',[])
    require(set(ids)<=seen,'正式知识ID尚未核对完整规则/边界')
    require((k['status']=='matched')==bool(ids),'知识关联状态与正式ID不一致')
    require(k['status']!='no_match' or bool(seen),'no_match必须有实际核对的知识卡；检索未完成请标insufficient')
    k['versions']={kid:db.execute('SELECT version FROM knowledge WHERE id=?',(kid,)).fetchone()[0] for kid in seen}
    k['verification']='quoted_source_checked_not_independent_tool_proof'
    q['evidenceSchemaVersion']='1.0'
    q['causeStatus']='pending' if any(a.get('status')!='confirmed' for a in q.get('attributions',[])) else 'none'
    if k['status']=='insufficient':q['evidence']+='；知识关联未完成：'+k['reason']
    if q.get('requires_image') and not q.get('diagram'):q['evidence']+='；干净题图待清理，尚不能用于打印组卷'
