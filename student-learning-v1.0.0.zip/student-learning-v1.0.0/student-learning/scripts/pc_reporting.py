"""Report-only inference after real review of every error candidate."""
import hashlib

def enrich(recognition,drafts):
    for group in recognition['groups']:
        if group.get('kind')=='practice': continue
        draft=drafts.get(group['id'],{}); originals={}
        for q in draft.get('questions',[]):
            sid=q.get('pc_scan_id') or group['id']+'-q-'+hashlib.sha256(q['local_id'].encode()).hexdigest()[:16]
            originals[sid]=q
        scans=group.get('questions',[])
        candidates=[q for q in scans if originals.get(q['id'],{}).get('verdict')!='correct' or q.get('verdict')!='correct' or q.get('decisionStatus')=='confirmed']
        def confirmed(q):return q.get('decisionStatus')=='confirmed' and q.get('status')=='saved' and q.get('verdict') in ('wrong','correct')
        def invalid(q):return q.get('status')=='excluded' and q.get('exclusionKind')=='invalid'
        complete=bool(group.get('recognized') and candidates and any(confirmed(q) for q in candidates) and all(confirmed(q) or invalid(q) for q in candidates))
        # Partial coverage may describe reviewed visible questions, never an entire paper.
        group['reviewComplete']=complete
        for q in scans:
            inferred=complete and q.get('verdict')=='correct' and q.get('decisionStatus')!='confirmed' and q.get('status')!='excluded'
            q['reportInferredCorrect']=inferred
            q['reportResult']='correct' if inferred else q.get('verdict','pending') if confirmed(q) else 'pending'
    return recognition
