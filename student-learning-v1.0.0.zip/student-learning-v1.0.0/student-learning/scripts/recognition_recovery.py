"""Conservative, auditable normalization before recognition_contract.expand_result.

This module performs no I/O and never validates or grants image visibility, user
confirmation, correctness, knowledge membership, or permission to persist data.
Callers must retain the raw response and run the unchanged expansion/DB guards.
"""
from __future__ import annotations

import json
import math
import re

MAX_RAW_CHARS = 2_000_000
MAX_CLOSER_REPAIRS = 8
MAX_DEPTH = 128


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("JSON 含重复键：" + key)
        result[key] = value
    return result


def _constant(value):
    raise ValueError("JSON 不允许非有限数值：" + value)


def _float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("JSON 数值超出有限范围")
    return result


def _loads(raw):
    return json.loads(raw, object_pairs_hook=_pairs, parse_constant=_constant,
                      parse_float=_float)


def _closing_symbols(raw):
    """Only substitute mismatched existing closers; never insert/delete tokens.

    For each existing closer the unmatched opener forces exactly one replacement.
    The restricted repair family therefore has at most one candidate. A candidate
    is accepted only if the entire result then passes strict JSON parsing.
    """
    stack, edits = [], []
    in_string = escaped = False
    for index, char in enumerate(raw):
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "[{":
            stack.append(char)
            if len(stack) > MAX_DEPTH:
                raise ValueError("JSON 嵌套超过恢复上限")
        elif char in "]}":
            if not stack:
                raise ValueError("JSON 存在多余闭合符，不能安全恢复")
            expected = "]" if stack.pop() == "[" else "}"
            if expected != char:
                edits.append((index, char, expected))
                if len(edits) > MAX_CLOSER_REPAIRS:
                    raise ValueError("JSON 闭合符错配超过恢复上限")
    if in_string or stack:
        raise ValueError("JSON 不完整，不能补写字符串或缺失结构")
    if not edits:
        raise ValueError("JSON 错误不属于可安全恢复的闭合符错配")
    chars = list(raw)
    for index, _, expected in edits:
        chars[index] = expected
    return "".join(chars), edits


def _audit(changes, path, original, action, value=None, **details):
    changes.append(dict(path=path, original=original, action=action,
                        value=value, **details))


def _pointer(key):
    return str(key).replace("~", "~0").replace("/", "~1")


def _valid_box(value):
    if not isinstance(value, dict) or set(value) != {"x", "y", "width", "height"}:
        return False
    if not all(type(v) is int or type(v) is float and math.isfinite(v) for v in value.values()):
        return False
    return (value["x"] >= 0 and value["y"] >= 0 and value["width"] > 0
            and value["height"] > 0 and value["x"] + value["width"] <= 100.0001
            and value["y"] + value["height"] <= 100.0001)


def _append_evidence(question, addition, path, changes):
    old = question.get("evidence")
    if not isinstance(old, str):
        raise ValueError(path + "/evidence 必须为字符串，不能自动替代原证据")
    value = old + ("；" if old else "") + addition
    question["evidence"] = value
    _audit(changes, path + "/evidence", old, "append_evidence", value)


def normalize_result(raw: str) -> tuple[dict, list[dict]]:
    """Return normalized object and per-change JSON-pointer audit, or ValueError.

    Source-string edits use /$raw (or /$json for post-fence character offsets).
    Page mismatch checks use only existing vision page reports. The caller must
    still compare against trusted input page count in expand_result; no report
    is manufactured, completed, or promoted to readable here.
    """
    if not isinstance(raw, str) or len(raw) > MAX_RAW_CHARS:
        raise ValueError("识别结果必须为有界 JSON 文本")
    changes = []
    source = raw.strip()
    match = re.fullmatch(r"```(?:json)?[ \t]*\r?\n(.*?)\r?\n```", source,
                         flags=re.DOTALL | re.IGNORECASE)
    if match:
        source = match.group(1)
        _audit(changes, "/$raw", raw, "remove_markdown_fence", source)
    try:
        result = _loads(source)
    except json.JSONDecodeError as exc:
        try:
            fixed, edits = _closing_symbols(source)
            result = _loads(fixed)
        except (ValueError, RecursionError) as recovery_error:
            raise ValueError(f"JSON 第 {exc.lineno} 行第 {exc.colno} 列无效：{recovery_error}") from exc
        for index, old, new in edits:
            _audit(changes, "/$json", old, "replace_mismatched_closer", new,
                   offset=index, line=source.count("\n", 0, index) + 1)
    except RecursionError as exc:
        raise ValueError("JSON 嵌套过深") from exc
    if not isinstance(result, dict):
        raise ValueError("识别结果顶层必须为对象")

    sections = result.get("sections")
    containers = []
    if isinstance(sections, dict):
        containers.extend(("/sections/" + _pointer(key), section)
                          for key, section in sections.items() if isinstance(section, dict))
    questions = result.get("questions")
    if isinstance(questions, list):
        containers.extend(("/questions/" + str(i), q)
                          for i, q in enumerate(questions) if isinstance(q, dict))
    for path, item in containers:
        for key in ("sectionTitle", "sharedContext"):
            if key in item and item[key] is None:
                del item[key]
                _audit(changes, path + "/" + key, None, "remove_optional_null")
    if isinstance(questions, list):
        for i, question in enumerate(questions):
            if not isinstance(question, dict):
                continue
            path = "/questions/" + str(i)
            # Practice questions and malformed unknown shapes remain strict failures.
            if "question_id" not in question and ("text" in question or "content" in question):
                for key in ("skill_id", "skill_name"):
                    if key in question:
                        value = question[key]
                        rendered = json.dumps(value, ensure_ascii=False, allow_nan=False)
                        _append_evidence(question, "知识细项辅助依据（待核对）" + key + "=" + rendered,
                                         path, changes)
                        del question[key]
                        _audit(changes, path + "/" + key, value, "move_to_evidence")
            if "box" in question and not _valid_box(question["box"]):
                _append_evidence(question, "题框定位待核对", path, changes)
                old = question.pop("box")
                _audit(changes, path + "/box", old, "remove_invalid_box")

    paper = result.get("paper")
    if isinstance(paper, dict) and isinstance(questions, list):
        expected = paper.get("expected_question_count")
        if type(expected) is int and expected < len(questions):
            paper["expected_question_count"] = None
            _audit(changes, "/paper/expected_question_count", expected,
                   "clear_contradictory_total", None)
        mismatch = paper.get("expected_question_count") != len(questions)
        vision = result.get("vision")
        reports = vision.get("pages") if isinstance(vision, dict) else None
        scanned = paper.get("scanned_pages")
        if (isinstance(reports, list) and reports
                and all(isinstance(page, dict) and type(page.get("page")) is int for page in reports)
                and isinstance(scanned, list) and all(type(page) is int for page in scanned)):
            mismatch = mismatch or set(scanned) != {page["page"] for page in reports}
        if paper.get("coverage") == "full" and mismatch:
            paper["coverage"] = "partial"
            _audit(changes, "/paper/coverage", "full", "downgrade_incomplete_coverage", "partial")
    return result, changes
