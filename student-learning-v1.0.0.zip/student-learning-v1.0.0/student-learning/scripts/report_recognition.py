"""Explicitly consented full-paper reports, isolated from canonical learning facts.

The immutable model snapshot lives in pc_reports. Only unmatched error candidates
are appended to the review draft; existing questions and decisions are untouched.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
import uuid
from collections import Counter
from pathlib import Path

import study
import pc_store as s
import recognition_checkpoint as checkpoint
from recognition_contract import build_prompt, expand_result
from recognition_recovery import normalize_result

ACTIVE = ('queued', 'running')
PURPOSE = 'full-paper-report-v1'


def context(root, db, group):
    pages = {p['id']: p for p in s.meta(db, 'pc_recognition', {'pages': []})['pages']}
    s.require(group.get('pageIds') and all(pid in pages for pid in group['pageIds']), '整卷报告缺少原图')
    data = {k: group.get(k) for k in ('id', 'kind', 'subject', 'grade', 'pageIds')}
    data['purpose'] = PURPOSE
    data['sources'] = [{'id': pid, 'url': pages[pid]['url'], 'sha256': hashlib.sha256(
        s.source_path(root, pages[pid]['url']).read_bytes()).hexdigest()} for pid in group['pageIds']]
    # Deliberately exclude questions, manual decisions, labels, drafts and review state.
    return {'version': 1, 'group_id': group['id'], 'fingerprint': checkpoint.digest(data), 'context': data}


def find_cached(root, identity):
    matches = []
    for marker in (Path(root) / 'drafts').glob('report-*/result-ready.json'):
        if marker.is_symlink() or marker.parent.is_symlink():
            continue
        try:
            data = json.loads(marker.read_text(encoding='utf-8'))
            result = marker.parent / 'result.json'
            if data.get('group_id') != identity['group_id'] or data.get('fingerprint') != identity['fingerprint']:
                continue
            if result.is_symlink() or result.stat().st_size > 15_000_000:
                continue
            if data.get('result_sha256') != hashlib.sha256(result.read_bytes()).hexdigest():
                continue
            try:
                value, _ = normalize_result(result.read_text(encoding='utf-8'))
                if value.get('status') in ('image_blocked', 'blocked'):
                    continue
            except ValueError:
                pass  # Retain malformed complete output for local repair, never silently reread.
            matches.append((marker.stat().st_mtime_ns, result))
        except (OSError, ValueError):
            continue
    return max(matches, key=lambda item: item[0])[1] if matches else None


def queue_task(root, db, data, expected_revision):
    s.require(isinstance(data, dict) and set(data) == {'groupId', 'requestId', 'consent'}, '整卷报告请求字段无效')
    s.require(data['consent'] is True, '请先确认整卷识别的 Token 消耗')
    gid, rid = data['groupId'], data['requestId']
    s.require(all(isinstance(v, str) and v for v in (gid, rid)), '整卷报告缺少请求编号')
    try:
        s.require(str(uuid.UUID(rid)) == rid, '请求编号无效')
    except (ValueError, AttributeError):
        raise ValueError('请求编号无效')
    db.execute('BEGIN IMMEDIATE')
    try:
        if s.revision(db) != expected_revision:
            raise s.ConflictError('档案已更新，请刷新后查看报告')
        rec = s.meta(db, 'pc_recognition', {'groups': []})
        group = next((g for g in rec['groups'] if g['id'] == gid), None)
        s.require(group and group.get('recognized') and group.get('kind') != 'practice', '请从已识别原卷查看试卷报告')
        s.require(not group.get('requested') and group.get('runStatus') not in ACTIVE, '原卷正在识别，请稍候')
        s.require(group.get('supplementTask', {}).get('status') not in ACTIVE, '补充题正在识别，请完成后查看报告')
        previous = group.get('reportTask')
        identity = context(root, db, group)
        if previous and previous['status'] in (*ACTIVE,'awaiting_conversation'):
            s.require(previous.get('fingerprint') == identity['fingerprint'], '原图或年级已改变，请等待当前任务停止后重新确认')
            db.commit()
            return s.clone(previous)
        if previous and previous['id'] == rid:
            s.require(previous.get('fingerprint') == identity['fingerprint'], '当前原图已变化，请使用新的确认请求')
            db.commit()
            return s.clone(previous)
        report = s.meta(db, 'pc_reports', {}).get(gid)
        if report and report.get('identity', {}).get('fingerprint') == identity['fingerprint']:
            task = s.clone(report['task'])
            group['reportTask'] = task
            s.put_meta(db, 'pc_recognition', rec)
            db.commit()
            return task
        s.require(not db.execute("SELECT 1 FROM events WHERE entity_id=? AND kind='report_queued'", (rid,)).fetchone(),
                  '该请求已处理，请刷新后重试')
        cached = find_cached(root, identity)
        recovery_expected = bool(previous and previous.get('fingerprint') == identity['fingerprint']
                                 and previous.get('resultRecovery', {}).get('available'))
        s.require(cached is not None or not recovery_expected,
                  '已保留的识别结果缺失或校验失败，未重新调用AI；请先恢复结果文件')
        now = study.now()
        task = {'id': rid, 'status': 'queued', 'fingerprint': identity['fingerprint'],
                'resultRecovery': {'available': cached is not None},
                'progress': {'phase': 'preparing', 'startedAt': now, 'updatedAt': now,
                             'message': '已确认整卷识别，正在准备报告'}}
        group['reportTask'] = task
        s.put_meta(db, 'pc_recognition', rec)
        study.event(db, rid, 'report_queued', previous, task)
        db.commit()
        return s.clone(task)
    except Exception:
        db.rollback()
        raise


def stamp(root, gid, task_id, status, phase=None, error=None, recovery=None):
    _, db = study.connect(root)
    try:
        db.execute('BEGIN IMMEDIATE')
        rec = s.meta(db, 'pc_recognition', {'groups': []})
        group = next((g for g in rec['groups'] if g['id'] == gid), None)
        task = group.get('reportTask') if group else None
        if not task or task['id'] != task_id or task['status'] not in ACTIVE:
            db.rollback()
            return
        from codex_bridge import PHASES
        now = study.now()
        task['status'] = status
        task['progress'].update(phase=phase or status, updatedAt=now,
                                message=PHASES.get(phase or status, '正在生成整卷报告'))
        if status in ('completed', 'failed'):
            task['progress']['finishedAt'] = now
        if error:
            task['error'] = error
        else:
            task.pop('error', None)
        if recovery is not None:
            task['resultRecovery'] = recovery
        s.put_meta(db, 'pc_recognition', rec)
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def _norm(value):
    return re.sub(r'\s+', '', str(value or ''))


def _key(scan):
    return scan.get('pageId'), _norm(scan.get('number'))


def _same_content(a, b):
    if _norm(a.get('fullText')) and all(_norm(a.get(k)) == _norm(b.get(k))
                                        for k in ('fullText', 'sectionTitle', 'sharedContext')):
        return True
    if not a.get('boxVerified') or not b.get('boxVerified'):
        return False
    x, y = a.get('box', {}), b.get('box', {})
    try:
        # Legacy projections may label an absent box as verified and supply the full page.
        if any(box['width'] >= 99 and box['height'] >= 99 for box in (x, y)):
            return False
        overlap = max(0, min(x['x'] + x['width'], y['x'] + y['width']) - max(x['x'], y['x'])) * max(
            0, min(x['y'] + x['height'], y['y'] + y['height']) - max(x['y'], y['y']))
        union = x['width'] * x['height'] + y['width'] * y['height'] - overlap
        return union > 0 and overlap / union >= 0.65
    except (KeyError, TypeError):
        return False


def _match(rows, scans, links=None):
    """Stable server links first; new matches require unique page+number and evidence."""
    by_id = {q['id']: q for q in scans}
    counts = Counter(_key(q) for q in scans)
    row_counts = Counter(_key(q) for q in rows)
    matches, used = {}, set()
    for row in rows:
        linked = by_id.get((links or {}).get(row['id']))
        if linked and linked['id'] not in used:
            matches[row['id']] = linked
            used.add(linked['id'])
    for row in rows:
        key = _key(row)
        if row['id'] in matches or counts[key] != 1 or row_counts[key] != 1:
            continue
        scan = next(q for q in scans if _key(q) == key)
        if scan['id'] not in used and _same_content(row, scan):
            matches[row['id']] = scan
            used.add(scan['id'])
    return matches


def _report_rows(result, group, records):
    rows = []
    for q in result['questions']:
        row = s._scan_projection(q, group, records)
        row['id'] = q['local_id']
        rows.append(row)
    return rows


def append_missing_candidates(db, rec, group, prepared, identity, records):
    """Called inside the save transaction. Never update existing draft/SQL questions."""
    drafts = s.meta(db, 'pc_drafts', {})
    s.require(group['id'] in drafts, '原卷识别稿不存在，请先恢复原卷')
    projected = s.recognition_projection(db, records)
    scans = next(g for g in projected['groups'] if g['id'] == group['id']).get('questions', [])
    rows = _report_rows(prepared, group, records)
    matches = _match(rows, scans)
    links = {rid: scan['id'] for rid, scan in matches.items()}
    added = []
    for q in prepared['questions']:
        if q['local_id'] in links or q['verdict'] == 'correct':
            continue
        new = s.clone(q)
        suffix = hashlib.sha256((identity['fingerprint'] + '\0' + q['local_id']).encode()).hexdigest()[:24]
        new.update(local_id='report:' + suffix, pc_scan_id=group['id'] + '-report-' + suffix,
                   decision_status='pending', pc_report_candidate=True)
        scan = s._scan_projection(new, group, records)
        drafts[group['id']]['questions'].append(new)
        group.setdefault('questions', []).append(scan)
        links[q['local_id']] = scan['id']
        added.append(scan['id'])
    if added:
        group['finalized'] = False
        s.put_meta(db, 'pc_drafts', drafts)
    return links, added


def _current(root, db, gid, task_id, identity):
    rec = s.meta(db, 'pc_recognition', {'groups': []})
    group = next((g for g in rec['groups'] if g['id'] == gid), None)
    task = group.get('reportTask') if group else None
    s.require(task and task['id'] == task_id and task['status'] in ACTIVE, '整卷报告请求已更新，旧结果不会写入')
    s.require(group.get('recognized') and group.get('kind') != 'practice', '原卷状态已改变，整卷结果未写入')
    s.require(task.get('fingerprint') == identity['fingerprint'] == context(root, db, group)['fingerprint'],
              '原图或试卷年级已改变，旧结果已保留；请重新确认整卷识别')
    return rec, group


def save_report(root, db, gid, task_id, identity, result):
    # Validation and asset copying have no effect on existing review/canonical rows.
    prepared = s._prepare_paper(root, db, result)
    db.execute('BEGIN IMMEDIATE')
    try:
        rec, group = _current(root, db, gid, task_id, identity)
        records, _ = s.knowledge_catalog(db)
        links, added = append_missing_candidates(db, rec, group, prepared, identity, records)
        task = group['reportTask']
        now = study.now()
        task.update(status='completed', resultRecovery={'available': False})
        task.pop('error', None)
        task['progress'].update(phase='completed', updatedAt=now, finishedAt=now,
                                message='整卷报告已生成' + ('，新增候选题请人工复核' if added else ''))
        reports = s.meta(db, 'pc_reports', {})
        reports[gid] = {'identity': identity, 'result': prepared, 'links': links,
                        'taskId': task_id, 'task': s.clone(task), 'generatedAt': now,
                        'addedCandidateIds': added}
        s.put_meta(db, 'pc_reports', reports)
        s.put_meta(db, 'pc_recognition', rec)
        study.event(db, task_id, 'report_completed', None,
                    {'fingerprint': identity['fingerprint'], 'question_count': len(prepared['questions']),
                     'added_candidate_ids': added})
        db.commit()
    except Exception:
        db.rollback()
        raise


def project(root, db, recognition):
    """Enrich a cloned recognition projection; never persist derived report values."""
    reports = s.meta(db, 'pc_reports', {})
    records, _ = s.knowledge_catalog(db)
    for group in recognition['groups']:
        group.pop('reportData', None)
        report = reports.get(group['id'])
        if not report or group.get('kind') == 'practice' or not group.get('recognized'):
            continue
        try:
            valid = context(root, db, group)['fingerprint'] == report['identity']['fingerprint']
        except (ValueError, OSError, KeyError):
            valid = False
        if not valid:
            if group.get('reportTask', {}).get('status') not in ACTIVE:
                task = s.clone(group.get('reportTask') or report['task'])
                task.update(status='failed', error='原图或年级已改变，请重新确认整卷识别后查看报告', resultRecovery={'available': False})
                group['reportTask'] = task
            continue
        result, paper = report['result'], report['result']['paper']
        rows = _report_rows(result, group, records)
        scans = group.get('questions', [])
        matches = _match(rows, scans, report.get('links'))
        used = {q['id'] for q in matches.values()}
        unmatched = [q for q in scans if q['id'] not in used]
        merged, originals = [], []
        for source, row in zip(result['questions'], rows):
            scan = s.clone(matches.get(row['id'], row))
            if row['id'] not in matches:
                scan['id'] = group['id'] + '-report-row-' + row['id']
                scan['canonicalId'] = scan['id']
            merged.append(scan)
            originals.append({'local_id': scan['id'], 'pc_scan_id': scan['id'], 'verdict': source['verdict']})
        for scan in unmatched:
            merged.append(s.clone(scan))
            originals.append({'local_id': scan['id'], 'pc_scan_id': scan['id'], 'verdict': scan.get('verdict')})
        from pc_reporting import enrich
        synthetic = {'id': group['id'], 'recognized': True, 'questions': merged}
        enrich({'groups': [synthetic]}, {group['id']: {'questions': originals}})
        full = paper['coverage'] == 'full' and not unmatched
        notes = []
        if unmatched:
            notes.append('有已有题目未能与整卷结果可靠对应，已保留人工内容；当前报告仅代表已识别内容，不能作为完整成绩。')
        if paper['coverage'] != 'full':
            notes.append('未核实全部页面或总题数，本报告为部分内容分析。')
        if report.get('addedCandidateIds'):
            notes.append('整卷验算发现的新增错题或待定题已加入原卷候选列表，请逐题核对后确认。')
        if not synthetic['reviewComplete']:
            notes.append('正误仍需人工复核；没有已确认的错题候选时，不将模型预测的正确题直接视为满分。')
        items = []
        for scan in merged:
            items.append({'id': scan.get('canonicalId') or scan['id'], 'scanId': scan['id'], 'number': scan['number'],
                          'text': scan['fullText'], 'verdict': scan.get('verdict', 'pending'),
                          'decisionStatus': scan.get('decisionStatus', 'pending'),
                          'excluded': scan.get('status') == 'excluded',
                          **({'exclusionKind': scan.get('exclusionKind', 'legacy')} if scan.get('status') == 'excluded' else {}),
                          'knowledgeIds': scan.get('knowledgeIds', []), 'knowledgePoints': scan.get('knowledgePoints', []),
                          'reasons': scan.get('reasons', []) if scan.get('verdict') == 'wrong' else [],
                          'reportResult': scan['reportResult'], 'reportInferredCorrect': scan['reportInferredCorrect']})
        excluded = sum(q.get('exclusionKind') == 'invalid' for q in items)
        legacy = sum(q.get('exclusionKind') == 'legacy' for q in items)
        assessed = [q for q in items if not q['excluded'] and q['reportResult'] in ('correct', 'wrong')]
        data = {'id': group.get('paperId', 'scan-original-' + group['id']), 'title': group['title'],
                'subject': group['subject'], 'grade': group.get('grade'), 'date': group.get('date', '').replace('-', '.'),
                'kind': 'original', 'status': '已整理', 'sources': [s.file_asset(root, a) for a in paper['sources']],
                'questionIds': [q['id'] for q in items if q['reportResult'] == 'wrong' and not q['excluded']],
                'allQuestions': items, 'coverage': 'full' if full else 'partial',
                'analysis': paper.get('analysis', ''), 'notes': notes, 'reviewComplete': synthetic['reviewComplete'],
                'excludedQuestions': excluded, 'legacyExcludedQuestions': legacy,
                'pendingQuestions': sum(not q['excluded'] and q['reportResult'] == 'pending' or q.get('exclusionKind') == 'legacy' for q in items),
                'ungradableQuestions': sum(not q['excluded'] and q['verdict'] == 'ungradable' for q in items),
                'assessedQuestions': len(assessed), 'correctQuestions': sum(q['reportResult'] == 'correct' for q in assessed),
                'wrongQuestions': sum(q['reportResult'] == 'wrong' for q in assessed)}
        if full:
            data['totalQuestions'] = max(0, paper['expected_question_count'] - excluded)
        group['reportData'] = data
    return recognition


def run_task(runner, gid, task_id):
    from codex_bridge import command
    root = Path(runner.root)
    work = root / 'drafts' / ('report-' + uuid.uuid4().hex)
    started = time.monotonic()
    has_result = False
    recovery_expected = False
    metrics = {'version': 1, 'kind': 'report', 'protocol': 'student-scan-v3', 'group_id': gid,
               'request_id': task_id, 'started_at': study.now(), 'model_calls': 0, 'usage': None,
               'usage_complete': False, 'tool_calls': 0, 'tool_output_chars': 0,
               'connection_retry_events': 0, 'status': 'preparing'}
    try:
        work.mkdir(parents=True)
        _, db = study.connect(root)
        try:
            rec = s.meta(db, 'pc_recognition', {'groups': []})
            group = next((g for g in rec['groups'] if g['id'] == gid), None)
            task = group.get('reportTask') if group else None
            if not task or task['id'] != task_id or task['status'] not in ACTIVE:
                metrics['status'] = 'skipped'
                return
            recovery_expected = bool(task.get('resultRecovery', {}).get('available'))
            identity = context(root, db, group)
            _current(root, db, gid, task_id, identity)
            checkpoint.write(work / 'input-context.json', identity)
            files = [str(s.source_path(root, p['url'])) for p in identity['context']['sources']]
            cached = find_cached(root, identity)
            s.require(cached is not None or not task.get('resultRecovery', {}).get('available'),
                      '已保留的识别结果缺失或校验失败，未重新调用AI；请先恢复结果文件')
            prompt = '' if cached else build_prompt(root, db, group, files) + '\n本次用户已明确同意整卷报告识别。必须逐页识别所有正确、错误、待定和无法判断题；无批改卷逐题独立验算。所有判定仍为待人工复核。只返回完整协议JSON。'
        finally:
            db.close()
        metrics.update(page_count=len(files), prompt_chars=len(prompt))
        stamp(root, gid, task_id, 'running', phase='saving' if cached else 'preparing')
        output = work / 'result.json'
        if cached:
            shutil.copyfile(cached, output)
            metrics.update(reused_result=cached.parent.name, usage={'input_tokens': 0, 'cached_input_tokens': 0, 'output_tokens': 0}, usage_complete=True)
        else:
            cmd = command(work, output, files)
            metrics.update(model_calls=1, requested_model=cmd[cmd.index('--model') + 1])
            callback = lambda phase: stamp(root, gid, task_id, 'running', phase=phase)
            rc = runner._execute(gid, cmd, prompt, work, task_id, metrics, stamp_callback=callback)
            if rc != 0 or not output.exists():
                metrics['usage_complete'] = False
                raise ValueError(checkpoint.execution_failure(metrics))
        checkpoint.ready(work, identity)
        has_result = True
        compact, repairs = normalize_result(output.read_text(encoding='utf-8'))
        if compact.get('status') in ('image_blocked', 'blocked'):
            has_result = False
            (work / 'result-ready.json').unlink(missing_ok=True)
            from vision_guard import BLOCKED_MESSAGE
            raise ValueError(BLOCKED_MESSAGE)
        checkpoint.write(work / 'normalized-result.json', compact)
        checkpoint.write(work / 'local-repairs.json', repairs)
        stamp(root, gid, task_id, 'running', phase='saving', recovery={'available': True})
        _, db = study.connect(root)
        try:
            _, group = _current(root, db, gid, task_id, identity)
            result = expand_result(root, db, group, files, compact)
            for q in result['questions']:
                if q.get('diagram'):
                    from pc_diagram import render_diagram
                    asset = render_diagram(root, q.pop('diagram'))
                    q['content']['blocks'].append({'type': 'image', 'asset': asset})
                    q['diagramReviewRequired'] = True
            save_report(root, db, gid, task_id, identity, result)
        finally:
            db.close()
        metrics.update(status='completed', question_count=len(result['questions']), local_repair_count=len(repairs))
    except Exception as error:
        metrics.update(status='failed', error_kind=type(error).__name__, error=str(error)[:1000])
        message = ('整卷识别内容已保留，保存未完成：' + str(error)[:200] + '。请重试保存，系统会复用结果，不重复调用AI。'
                   if has_result else checkpoint.failure_message(error, False))
        stamp(root, gid, task_id, 'failed', error=message, recovery={'available': has_result or recovery_expected})
    finally:
        metrics.update(finished_at=study.now(), elapsed_seconds=round(time.monotonic() - started, 3))
        try:
            checkpoint.write(work / 'usage.json', metrics)
        except OSError:
            pass
        with runner.lock:
            runner.active.pop(gid, None)
            runner.processes.pop(gid, None)
