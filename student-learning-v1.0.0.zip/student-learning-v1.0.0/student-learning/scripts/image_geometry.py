"""Deterministic percent geometry in the EXIF-oriented image basis."""
def padded_box(box,padding=2.0):
    from pc_store import _box
    b=_box(box);x=max(0,b['x']-padding);y=max(0,b['y']-padding)
    right=min(100,b['x']+b['width']+padding);bottom=min(100,b['y']+b['height']+padding)
    return {'x':x,'y':y,'width':right-x,'height':bottom-y}
