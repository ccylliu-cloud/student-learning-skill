"""Transactional PC projection of the single canonical learning SQLite archive."""
from __future__ import annotations
import copy, datetime as dt, hashlib, json, math, re
from pathlib import Path
import study
from pc_content import CONTENT_FIELDS, validate_fields, has_question_content

SUBJECTS = study.SUBJECTS
REVERSE = {v:k for k,v in SUBJECTS.items()}
class ConflictError(ValueError): pass

def clone(value): return copy.deepcopy(value)
def require(ok, message): study.require(ok, message)
def meta(db, key, default):
    row = db.execute('SELECT value FROM meta WHERE key=?', (key,)).fetchone()
    return json.loads(row[0]) if row else clone(default)
def put_meta(db, key, value):
    db.execute('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key,study.dumps(value)))
def subject_code(value):
    result = REVERSE.get(value, value)
    require(result in SUBJECTS, '学科必须为语文、数学或英语')
    return result

def real_date(value):
    require(isinstance(value,str), '必须保留真实作答日期')
    return study.date(value.replace('.', '-'))
def labels(values):
    require(isinstance(values,list) and all(isinstance(x,str) and x.strip() for x in values), '标签必须为非空文字数组')
    return list(dict.fromkeys(values))
def tags(q):
    attrs = q.get('attributions',[])
    knowledge = q.get('pc_knowledge_points', [a.get('knowledge_name') for a in attrs if a.get('knowledge_name')])
    reasons = q.get('pc_reasons', [study.CAUSES[a['error_cause_id']]['name'] for a in attrs if a.get('error_cause_id') in study.CAUSES])
    return list(dict.fromkeys(knowledge)), list(dict.fromkeys(reasons))

def knowledge_catalog(db):
    records={r['id']:dict(r) for r in db.execute('SELECT * FROM knowledge ORDER BY id')}
    trees={s:[] for s in SUBJECTS.values()}; modules={}; topics={}; math_nodes={}
    for kid,row in records.items():
        raw=json.loads(row['payload']); subject=row['subject']
        if subject not in SUBJECTS: continue
        if subject=='math':
            if not raw.get('is_assessable') or not raw.get('active'): continue
            children=trees['数学']
            for level,(node_id,name) in enumerate(zip(raw['path_ids'],raw['path_names']),1):
                if node_id not in math_nodes:
                    node={'id':node_id,'label':name+('（高中）' if level==1 and raw['stage']=='高中' else ''),
                          'level':level,'is_assessable':node_id==kid}
                    if node_id!=kid:node['children']=[]
                    math_nodes[node_id]=node;children.append(node)
                node=math_nodes[node_id]
                if node_id!=kid:children=node['children']
            continue
        if subject=='chinese' and raw.get('level')==2 and raw.get('category_id'):
            cid=raw['category_id']
            if (subject,cid) not in modules:
                modules[subject,cid]={'id':cid,'label':raw['category'],'level':1,'children':[]}
                trees[SUBJECTS[subject]].append(modules[subject,cid])
            modules[subject,cid]['children'].append({'id':kid,'label':row['name'],'level':2})
            continue
        mid=raw.get('module_id',raw.get('unit_id')); ml=raw.get('module',raw.get('一级单元'))
        tid=raw.get('topic_id',raw.get('parent_id')); tl=raw.get('topic',raw.get('二级知识点'))
        if raw.get('knowledge_base_id')in ('math-k12-knowledge','math-highschool-knowledge'):
            mid,ml=raw['catalog_domain_id'],raw['domain']
            tid,tl=raw['catalog_topic_id'],raw['module']
            if raw['knowledge_base_id']=='math-highschool-knowledge': ml+='（高中）'
        elif subject=='math':
            # Retired entries are migrated explicitly; never offer them as active tags.
            continue
        if not all(isinstance(x,str) and x for x in (mid,ml,tid,tl)):
            trees[SUBJECTS[subject]].append({'id':kid,'label':row['name'],'level':3}); continue
        if (subject,mid) not in modules:
            modules[subject,mid]={'id':mid,'label':ml,'level':1,'children':[]}
            trees[SUBJECTS[subject]].append(modules[subject,mid])
        if (subject,mid,tid) not in topics:
            topics[subject,mid,tid]={'id':tid,'label':tl,'level':2,'children':[]}
            modules[subject,mid]['children'].append(topics[subject,mid,tid])
        topics[subject,mid,tid]['children'].append({'id':kid,'label':row['name'],'level':3})
    # K12 and high-school are the only active math catalogs.
    trees['数学'].sort(key=lambda n:0 if n['id'].startswith('MATH-K') else 1 if n['id'].startswith('HSMATH-D') else 2)
    return records,trees

def question_knowledge(q,subject,records):
    names,_=tags(q)
    by_name={}
    for kid,row in records.items():
        if row['subject']==subject: by_name.setdefault(row['name'],[]).append(kid)
    if 'knowledgeIds' in q:
        ids=[k for k in q['knowledgeIds'] if k in records and records[k]['subject']==subject]
        # Explicit ID selection controls standard labels; unmatched manual labels remain visible.
        names=[records[k]['name'] for k in ids]+[n for n in names if n not in by_name]
    elif 'pc_knowledge_points' in q:
        ids=[by_name[n][0] for n in names if len(by_name.get(n,[]))==1]
    else:
        ids=[a['knowledge_point_id'] for a in q.get('attributions',[]) if a.get('knowledge_point_id') in records and records[a['knowledge_point_id']]['subject']==subject]
    return list(dict.fromkeys(ids)),list(dict.fromkeys(names))

def validate_knowledge(db,q,subject,*,historical=None):
    if 'knowledgeIds' not in q: return
    ids=labels(q['knowledgeIds']); require(len(ids)<=3,'知识点最多3个')
    for kid in ids:
        row=db.execute('SELECT subject,payload FROM knowledge WHERE id=?',(kid,)).fetchone()
        require(row is not None and row['subject']==subject,'知识点ID不存在或学科不符')
        if subject=='math':
            raw=json.loads(row['payload'])
            unchanged_history=historical is not None and q.get('knowledgeIds')==historical.get('knowledgeIds') and raw.get('legacy_reference') is True
            require(raw.get('is_assessable') is True or unchanged_history,'请选择现行数学末级知识点；旧关联请先迁移')
    q['knowledgeIds']=ids

def content_fields(q): return {k:clone(q[k]) for k in CONTENT_FIELDS if k in q}

def exclusion_kind(q):
    return ('invalid' if q.get('pc_exclusion_kind')=='invalid' else 'legacy') if q.get('pc_excluded') else None

def _canonical_id(pid,q):
    return 'scan-question-'+q['pc_scan_id'] if q.get('pc_scan_id') else 'scan-record-'+hashlib.sha256((pid+'\0'+q['local_id']).encode()).hexdigest()

def _scan_projection(q,group,records,canonical_id=None,status=None):
    sid=q.get('pc_scan_id') or group['id']+'-q-'+hashlib.sha256(q['local_id'].encode()).hexdigest()[:16]
    ids,knowledge=question_knowledge(q,subject_code(group['subject']),records); _,reasons=tags(q)
    verdict=q.get('verdict','pending'); decision=q.get('decision_status','pending') if canonical_id else 'pending'
    status=status or ('excluded' if q.get('pc_excluded') else 'saved' if canonical_id else 'pending')
    result={'id':sid,'canonicalId':canonical_id or 'scan-question-'+sid,'pageId':group['pageIds'][q['page']-1],'number':q['number'],'fullText':q['text'],'answer':q.get('expected_answer') or '', 'analysis':q.get('explanation') or '', 'studentAnswer':q.get('student_answer') or '', 'knowledgeIds':ids,'knowledgePoints':knowledge,'reasons':reasons,'box':_box(q.get('pc_box') or q.get('box') or {'x':0,'y':0,'width':100,'height':100}),'status':status,'verdict':verdict,'decisionStatus':decision,'boxVerified':q.get('boxVerified',True),**content_fields(q)}
    result.update(boxLocated=bool(q.get('box') or q.get('pc_box')),boxSource=q.get('boxSource','model'),answerEvidence=q.get('answerEvidence'),knowledgeValidation=q.get('knowledgeValidation'),correctedAnswer=q.get('corrected_answer'),causeStatus=('confirmed' if all(a.get('status')=='confirmed' for a in q.get('attributions',[])) else 'pending') if q.get('attributions') else 'none')
    if q.get('pc_supplemental'):result['supplemental']=True
    if status=='excluded': result['exclusionKind']=exclusion_kind(q) or 'legacy'
    if q.get('diagramReviewRequired') and decision!='confirmed': result['diagramReviewRequired']=True
    if canonical_id and verdict=='wrong' and decision=='confirmed' and not q.get('pc_excluded'): result['savedQuestionId']=canonical_id
    if decision!='confirmed': result['reviewNote']='待人工复核：'+(q.get('evidence') or '识别证据尚不充分')+('；重建题图需核对' if q.get('diagramReviewRequired') else '')
    if q.get('knowledgeValidation',{}).get('status')=='insufficient':result['reviewNote']=(result.get('reviewNote','')+'；知识关联未完成：'+q['knowledgeValidation']['reason'])
    if result['causeStatus']=='pending':result['reviewNote']=(result.get('reviewNote','')+'；错因待复核（确认正误不等于确认错因）')
    return result

def recognition_projection(db,records):
    recognition=meta(db,'pc_recognition',{'pages':[],'groups':[]}); drafts=meta(db,'pc_drafts',{})
    for group in recognition['groups']:
        if group.get('kind')=='practice':
            from pc_practice import project_group
            project_group(db,group,records)
            continue
        draft=drafts.get(group['id'])
        if not group.get('recognized') or not draft: continue
        pid=draft['paper']['id']; stored={s['id']:s for s in group.get('questions',[])}; scans=[]
        for original in draft['questions']:
            sid=original.get('pc_scan_id') or group['id']+'-q-'+hashlib.sha256(original['local_id'].encode()).hexdigest()[:16]
            row=db.execute('SELECT id,payload FROM questions WHERE paper_id=? AND local_id=?',(pid,original['local_id'])).fetchone()
            if row:
                q=json.loads(row['payload']); q['pc_scan_id']=sid
                scans.append(_scan_projection(q,group,records,row['id']))
            else:
                scan=_scan_projection(original,group,records)
                if sid in stored:
                    # Preserve edits in drafts that have not yet been committed as questions.
                    scan.update(clone(stored[sid])); scan.setdefault('verdict',original['verdict']); scan['decisionStatus']='pending'
                scans.append(scan)
        group['questions']=scans; group['paperId']=pid; group.setdefault('runStatus','completed')
        group['coverage']=draft['paper'].get('coverage','partial')
        group['expectedQuestionCount']=draft['paper'].get('expected_question_count')
    return recognition
def file_asset(root, asset):
    raw = asset.get('path','')
    path = (Path(root)/raw).resolve()
    require(path.is_relative_to((Path(root)/'assets').resolve()) and path.is_file(), '素材丢失或路径越界')
    return {'url':'/files/'+path.name,'label':asset.get('original_name') or path.name}
def source_path(root, url):
    require(isinstance(url,str) and re.fullmatch(r'/files/[A-Za-z0-9_.-]+',url), '只允许档案内的原图')
    path = (Path(root)/'assets'/url.rsplit('/',1)[1]).resolve()
    require(path.is_relative_to((Path(root)/'assets').resolve()) and path.is_file(), '原图不存在')
    return path

def revision(db):
    h = hashlib.sha256()
    for table in ('papers','questions','reviews','mastery','events','knowledge','meta'):
        h.update(table.encode())
        for row in db.execute(f'SELECT * FROM {table} ORDER BY 1'):
            h.update(study.dumps(list(row)).encode()); h.update(b'\n')
    return h.hexdigest()

def attempt_baseline(attempts):
    if not attempts: return None
    latest=attempts[-1]
    return {k:latest[k] for k in ('id','date','result')}

def _read_archive(root,db):
    from student_profile import read_profile
    from pc_reporting import enrich
    profile=read_profile(root,db)
    records,trees=knowledge_catalog(db)
    recognition=enrich(recognition_projection(db,records),meta(db,'pc_drafts',{}))
    from report_recognition import project
    recognition=project(root,db,recognition)
    report_groups={g.get('paperId'):g for g in recognition['groups'] if g.get('kind')!='practice'}
    practices = meta(db,'pc_practice',{})
    originals = {r['id']:json.loads(r['payload']) for r in db.execute('SELECT * FROM papers ORDER BY created DESC')}
    all_questions = [dict(json.loads(r['payload']),id=r['id'],paper_id=r['paper_id'],subject=r['subject']) for r in db.execute('SELECT * FROM questions ORDER BY rowid DESC')]
    review_map = {}
    for row in db.execute('SELECT * FROM reviews ORDER BY created'):
        r=json.loads(row['payload'])
        if r.get('result') in ('correct','wrong'):
            review_map.setdefault(row['question_id'],[]).append({'id':r['id'],'date':r['date'],'label':'复做记录','result':'correct' if r['result']=='correct' else 'incorrect','answer':r.get('answer',''),'_recordedAt':row['created']})
    questions=[]; all_projected_questions=[]
    for q in all_questions:
        p=originals[q['paper_id']]; ids,knowledge=question_knowledge(q,q['subject'],records); _,reasons=tags(q); attempts=clone(review_map.get(q['id'],[]))
        for paper in practices.values():
            result=paper.get('savedResults',{}).get(q['id'])
            if result:
                detail=paper.get('pc_result_details',{}).get(q['id'],{})
                attempts.append({'id':paper['id']+':'+q['id'],'date':paper.get('pc_result_dates',{}).get(q['id'],paper.get('pc_result_date',paper['date'])),'label':paper['title'],'result':result,'paperId':paper['id'],'answer':detail.get('answer',''),'_recordedAt':paper.get('pc_result_recorded_at',{}).get(q['id'],paper.get('pc_result_received_at',''))})
        attempts.sort(key=lambda x:(x['date'].replace('.','-'),x['_recordedAt'],x['id']))
        mastery=q.get('pc_mastery') if q.get('pc_mastery') and q.get('pc_mastery_after')==attempt_baseline(attempts) else ('已掌握' if attempts and attempts[-1]['result']=='correct' else '未掌握')
        for attempt in attempts: attempt.pop('_recordedAt',None)
        images=[file_asset(root,a) for a in q.get('assets',[]) if a['role']=='original']
        if q.get('pc_images'): images=clone(q['pc_images'])
        projected_question={'grade':p.get('grade'),'id':q['id'],'title':q['text'],'fullText':q['text'],'answer':q.get('expected_answer') or '', 'analysis':q.get('explanation') or '', 'studentAnswer':q.get('student_answer') or '', 'causeAnalysis':('【错因待复核】' if any(a.get('status')!='confirmed' for a in q.get('attributions',[])) else '')+(q.get('observed_error') or ''), 'answerEvidence':q.get('answerEvidence'), 'knowledgeValidation':q.get('knowledgeValidation'), 'correctedAnswer':q.get('corrected_answer'), 'causeStatus':('confirmed' if all(a.get('status')=='confirmed' for a in q.get('attributions',[])) else 'pending') if q.get('attributions') else 'none', 'subject':SUBJECTS[q['subject']], 'uploadTime':p['date'].replace('-','.'),'mastery':mastery,'knowledgePoint':knowledge[0] if knowledge else '', 'knowledgePoints':knowledge,'knowledgeIds':ids,**content_fields(q),'reason':reasons[0] if reasons else '', 'reasons':reasons,'wrongCount':int(q.get('verdict')=='wrong' and not q.get('pc_excluded'))+sum(a['result']=='incorrect' for a in attempts),'correctCount':sum(a['result']=='correct' for a in attempts),'groupedCount':sum(q['id'] in paper['questionIds'] for paper in practices.values()),'originalId':q['paper_id'],'images':images,'diagramReviewRequired':bool(q.get('diagramReviewRequired')),'requiresImage':bool(q.get('requires_image')),'cleanImages':[file_asset(root,a) for a in q.get('assets',[]) if a['role']=='question_clean'],'attempts':attempts,**({'sourceRecognitionId':q['pc_scan_id']} if q.get('pc_scan_id') else {})}
        all_projected_questions.append(projected_question)
        if q.get('verdict')=='wrong' and q.get('decision_status')=='confirmed' and not q.get('pc_excluded'): questions.append(projected_question)
    papers=[]
    for pid,p in originals.items():
        items=[q for q in all_questions if q['paper_id']==pid]
        assessed=[q for q in items if q['decision_status']=='confirmed' and q['verdict'] in ('wrong','correct') and not q.get('pc_excluded')]
        full_questions=[]
        for q in reversed(items):
            ids,names=question_knowledge(q,p['subject'],records)
            full_questions.append({'id':q['id'],'number':q['number'],'text':q['text'],'verdict':q['verdict'],'decisionStatus':q['decision_status'],'excluded':bool(q.get('pc_excluded')),**({'exclusionKind':exclusion_kind(q)} if q.get('pc_excluded') else {}),'knowledgeIds':ids,'knowledgePoints':names,'reasons':tags(q)[1] if q['verdict']=='wrong' else []})
        report_group=report_groups.get(pid,{})
        report_items={q.get('canonicalId'):q for q in report_group.get('questions',[])}
        for item in full_questions:
            scan=report_items.get(item['id'],{})
            if 'reportResult' in scan: item.update(reportResult=scan['reportResult'],reportInferredCorrect=scan.get('reportInferredCorrect',False))
        projected={'grade':p.get('grade'),'reviewComplete':report_group.get('reviewComplete',False),'allQuestions':full_questions,'coverage':p.get('coverage','partial'),'excludedQuestions':sum(exclusion_kind(q)=='invalid' for q in items),'legacyExcludedQuestions':sum(exclusion_kind(q)=='legacy' for q in items),'pendingQuestions':sum((q['decision_status']!='confirmed' and not q.get('pc_excluded')) or exclusion_kind(q)=='legacy' for q in items),'ungradableQuestions':sum(q['verdict']=='ungradable' and not q.get('pc_excluded') for q in items),'id':pid,'title':p['title'],'subject':SUBJECTS[p['subject']],'date':p['date'].replace('-','.'),'kind':'original','questionIds':[q['id'] for q in questions if q['originalId']==pid],'status':'已整理','sources':[file_asset(root,a) for a in p['sources']],'assessedQuestions':len(assessed),'correctQuestions':sum(q['verdict']=='correct' for q in assessed),'wrongQuestions':sum(q['verdict']=='wrong' for q in assessed),'analysis':p.get('analysis','')}
        if p.get('coverage')=='full' and type(p.get('expected_question_count')) is int: projected['totalQuestions']=max(0,p['expected_question_count']-sum(exclusion_kind(q)=='invalid' for q in items))
        papers.append(projected)
    projected_by_id={q['id']:q for q in all_projected_questions}
    for p in practices.values():
        projected={k:clone(v) for k,v in p.items() if not k.startswith('pc_')}
        projected['resultDetails']=clone(p.get('pc_result_details',{}))
        projected['resultDate']=p.get('pc_result_date')
        from pc_practice import group_id
        if any(g['id']==group_id(p['id']) for g in meta(db,'pc_recognition',{'groups':[]})['groups']): projected['practiceRecognitionId']=group_id(p['id'])
        projected['questions']=[clone(projected_by_id[qid]) for qid in p['questionIds'] if qid in projected_by_id]
        projected['coverage']='full' if len(projected['questions'])==len(p['questionIds']) else 'partial'
        projected['sourceCoverage']='partial' if any(originals.get(q.get('originalId'),{}).get('coverage')!='full' for q in projected['questions']) else 'full'
        papers.append(projected)
    papers.sort(key=lambda p:p['date'].replace('.','-'),reverse=True)
    grade=profile.get('grade')
    if type(grade)is int:
        allowed='math-k12-knowledge' if grade<=9 else 'math-highschool-knowledge'
        linked={k for q in all_questions for k in question_knowledge(q,q['subject'],records)[0]}
        def keep(nodes):
            result=[]
            for node in nodes:
                if node.get('children'):
                    children=keep(node['children'])
                    if children:result.append({**node,'children':children})
                elif node['id'] in linked or json.loads(records[node['id']]['payload']).get('knowledge_base_id')==allowed:result.append(node)
            return result
        trees['数学']=keep(trees['数学'])
    knowledge={s:[] for s in SUBJECTS.values()}
    for row in db.execute('SELECT subject,name,payload FROM knowledge ORDER BY name'):
        if row['subject']=='math' and not json.loads(row['payload']).get('is_assessable'):continue
        if row['subject'] in SUBJECTS and row['name'] not in knowledge[SUBJECTS[row['subject']]]: knowledge[SUBJECTS[row['subject']]].append(row['name'])
    return {'version':1,'mode':'local','questions':questions,'papers':papers,'recognition':recognition,'knowledgeTree':trees, 'profile':profile,'knowledgeOptions':knowledge,'causeOptions':{SUBJECTS[s]:names for s,names in study.CAUSE_NAMES.items()}}

def read_archive(root,db):
    # Keep the revision and its projection on one SQLite read snapshot.
    own=not db.in_transaction
    if own: db.execute('BEGIN')
    try:
        result={'archive':_read_archive(root,db),'revision':revision(db)}
        if own: db.commit()
        return result
    except Exception:
        if own: db.rollback()
        raise

def _stage_file(root,path):
    from image_import import prepare
    return prepare(root,path)['asset']

def _stage_import_plan(root,db,paths,subject,practice_id=None):
    from image_import import prepare,decode,pixel_hash
    require(isinstance(paths,(list,tuple)) and paths,'请提供原图')
    imports=[prepare(root,p) for p in paths]
    pages=meta(db,'pc_recognition',{'pages':[]})['pages']
    evidence=meta(db,'pc_image_imports',{})
    scope='practice:'+practice_id if practice_id else 'original:'+subject
    candidates=[]
    for p in pages:
        in_scope=(p['id'].startswith('practice-page-'+practice_id+'-') if practice_id else p.get('subject')==SUBJECTS[subject] and not p['id'].startswith('practice-page-'))
        if not in_scope: continue
        path=source_path(root,p['url'])
        known=next((v for v in evidence.values() if v.get('pageId')==p['id']),None)
        try: fingerprint=known['pixelHash'] if known else pixel_hash(decode(path)[0])
        except ValueError: fingerprint=None
        candidates.append({'pageId':p['id'],'label':p['label'],'asset':study.store_file(Path(root),path),'pixelHash':fingerprint})
    for item in imports:
        same=next((c for c in candidates if c['asset']['sha256']==item['asset']['sha256']),None)
        match='bytes' if same else None
        if not same:
            same=next((c for c in candidates if c['pixelHash']==item['pixelHash']),None)
            if same: match='pixels'
        asset=same['asset'] if same else item['asset']
        pid=same['pageId'] if same else ('practice-page-'+practice_id+'-'+asset['sha256'] if practice_id else 'page-'+asset['sha256']+'-'+subject)
        item.update(pageId=pid,previewUrl=file_asset(root,asset)['url'],status='reused' if same else 'staged',duplicateMatch=match,
            suspectedDuplicates=[{'pageId':c['pageId'],'label':c['label'],'reason':'同名但解码像素不同，请核对是否为另一张作答页'} for c in candidates if Path(c['label']).stem.casefold()==Path(item['sourceName']).stem.casefold() and c['pageId']!=pid],_selectedAsset=asset,_scope=scope)
        if not same: candidates.append({'pageId':pid,'label':item['sourceName'],'asset':asset,'pixelHash':item['pixelHash']})
    return imports

def _save_image_imports(db,imports):
    evidence=meta(db,'pc_image_imports',{});old=clone(evidence)
    for item in imports:
        key=item['_scope']+':'+item['sourceSha256']+':'+item['sourceName']
        evidence[key]={k:clone(item[k]) for k in ('pageId','sourceName','sourceSha256','originalAsset','pixelHash','pixelHashVersion','converted','orientationApplied','decoder','width','height')}
    if evidence!=old: put_meta(db,'pc_image_imports',evidence)

def _import_response(imports):
    return [{k:clone(v) for k,v in item.items() if not k.startswith('_') and k not in ('asset','pixelHash')} for item in imports]

def stage_pages(root,db,paths,subject):
    subject=subject_code(subject)
    db.execute('BEGIN IMMEDIATE')
    try:
        imports=_stage_import_plan(root,db,paths,subject)
        old=meta(db,'pc_recognition',{'pages':[],'groups':[]}); r=clone(old); ids=[]
        for item in imports:
            pid=item['pageId']
            if not any(p['id']==pid for p in r['pages']):
                r['pages'].append({'id':pid,'label':item['sourceName'],'url':item['previewUrl'],'subject':SUBJECTS[subject],'date':dt.date.today().isoformat().replace('-','.'),'grade':__import__('student_profile').read_profile(root,db).get('grade'),'width':item.get('width'),'height':item.get('height'),'qualityWarnings':item.get('qualityWarnings',[]),'sourceSha256':item.get('sourceSha256')})
            if pid not in ids: ids.append(pid)
        if old!=r: put_meta(db,'pc_recognition',r); study.event(db,'pc_recognition','stage_pages',old,r)
        _save_image_imports(db,imports)
        db.commit()
    except Exception: db.rollback(); raise
    return dict(read_archive(root,db),stagedPageIds=ids,importResults=_import_response(imports))

def _prepare_paper(root,db,data,*,trusted_practice=False):
    data=clone(data); require(data.get('schema_version')==1,'导入契约版本必须为 1')
    p=data['paper']; qs=data['questions']; subject=subject_code(p.get('subject')); p['subject']=subject
    require(study.nonempty(p.get('id')) and study.nonempty(p.get('title')),'试卷ID和名称不能为空'); real_date(p.get('date'))
    require(p.get('coverage') in ('full','partial') and p.get('assessment_mode') in ('teacher_marks','unmarked'),'试卷覆盖/批改模式无效')
    n=p.get('page_count'); scanned=p.get('scanned_pages'); require(type(n) is int and n>0,'总页数无效')
    require(isinstance(scanned,list) and len(set(scanned))==len(scanned) and all(type(x) is int and 1<=x<=n for x in scanned),'扫描页码无效')
    require(p['coverage']!='full' or set(scanned)==set(range(1,n+1)),'完整分析须核对全部页面')
    require(isinstance(qs,list) and (bool(qs) or p.get('recognition_scope')=='mistakes' and p['coverage']=='partial'),'需要完整逐题结果')
    require(len({q.get('local_id') for q in qs})==len(qs),'同卷题号重复')
    expected=p.get('expected_question_count'); require(expected is None or type(expected) is int and expected>=len(qs),'全卷题数无效')
    require(p['coverage']!='full' or expected==len(qs),'全卷题数必须核实且等于逐题记录数')
    require(isinstance(p.get('sources'),list) and p['sources'],'需要原卷素材')
    for q in qs:
        from knowledge_selection import limit_knowledge,route_knowledge
        from knowledge_quality import reconcile_knowledge
        reconcile_knowledge(db,q,subject,p.get('grade'))
        route_knowledge(db,q,subject,p.get('grade'))
        limit_knowledge(db,q,subject)
        validate_fields(root,q); validate_knowledge(db,q,subject)
        study.validate_question(db,q,subject,machine_import=not trusted_practice); require(q['page'] in scanned,'题目所在页未扫描')
        if p['assessment_mode']=='teacher_marks' and q['basis']=='model_reasoning': require(q['decision_status']=='pending','有批改卷面的模型验算须待复核')
        q['assets']=[dict(study.store_file(Path(root),a['path']),role=a['role']) for a in q.get('assets',[])]
    p['sources']=[study.store_file(Path(root),s) for s in p['sources']]
    return data

def _box(value):
    require(isinstance(value,dict) and set(value)=={'x','y','width','height'},'题框无效')
    require(all(type(value[k]) in (int,float) and math.isfinite(value[k]) for k in value),'题框数值无效')
    require(value['x']>=0 and value['y']>=0 and value['width']>0 and value['height']>0 and value['x']+value['width']<=100.0001 and value['y']+value['height']<=100.0001,'题框超出图片')
    return clone(value)

def put_results(root,db,group_id,data,expected_request_id=None):
    group=next((g for g in meta(db,'pc_recognition',{'groups':[]})['groups'] if g['id']==group_id),None)
    if group and group.get('kind')=='practice':
        from pc_practice import put_practice_recognition
        return put_practice_recognition(root,db,group_id,data,expected_request_id)
    db.execute('BEGIN IMMEDIATE')
    try:
        r=meta(db,'pc_recognition',{'pages':[],'groups':[]}); group=next((g for g in r['groups'] if g['id']==group_id),None)
        require(group is not None and group['pageIds'],'识别分组不存在或为空')
        if expected_request_id is not None:
            require(group.get('requestId')==expected_request_id and group.get('requested') is True,'识别请求已更新或结束，旧执行结果不再写入')
        require(subject_code(data['paper']['subject'])==subject_code(group['subject']),'识别结果与分组学科不符')
        page_map={p['id']:p for p in r['pages']}; input_data=clone(data)
        require(input_data['paper']['page_count']==len(group['pageIds']),'结果页数与分组原图数不符')
        supplied=input_data['paper'].get('sources',[])
        expected=[source_path(root,page_map[pid]['url']) for pid in group['pageIds']]
        require(len(supplied)==len(expected) and all(hashlib.sha256(Path(a).expanduser().read_bytes()).digest()==hashlib.sha256(b.read_bytes()).digest() for a,b in zip(supplied,expected)),'识别结果原图与当前分组不一致，请重新核对请求')
        input_data['paper']['sources']=[str(source_path(root,page_map[pid]['url'])) for pid in group['pageIds']]
        input_data['paper']['grade']=group.get('grade')
        prepared=_prepare_paper(root,db,input_data)
        input_digest=hashlib.sha256(study.dumps(prepared).encode()).hexdigest()
        drafts=meta(db,'pc_drafts',{})
        if group.get('recognized'):
            require(drafts.get(group_id,{}).get('pc_input_digest')==input_digest,'本组已有不同识别结果，请显式修订，不能覆盖人工修改或排除状态')
            db.commit(); return read_archive(root,db)
        require(not db.execute('SELECT id FROM papers WHERE id=?',(prepared['paper']['id'],)).fetchone(),'该原卷已导入，请修订已有原卷，不要重复识别入库')
        for row in db.execute('SELECT payload FROM papers'):
            require(json.loads(row[0]).get('pc_original_paper_id')!=prepared['paper']['id'],'该原卷已通过识别工作区入库，请修订已有原卷')
        prepared['pc_input_digest']=input_digest
        prepared['paper']['pc_original_paper_id']=prepared['paper']['id']; prepared['paper']['id']='scan-original-'+group_id
        prepared['paper']['pc_group_id']=group_id
        before=clone(drafts.get(group_id)); drafts[group_id]=prepared
        old=clone(group); candidates=[]; records,_=knowledge_catalog(db)
        for q in prepared['questions']:
            q['pc_scan_id']=group_id+'-q-'+hashlib.sha256(q['local_id'].encode()).hexdigest()[:16]
            candidates.append(_scan_projection(q,group,records))
        group.update(recognized=True,requested=False,questions=candidates)
        group.pop('error',None)
        put_meta(db,'pc_drafts',drafts); put_meta(db,'pc_recognition',r)
        study.event(db,group_id,'recognition_result',{'group':old,'draft':before},{'group':group,'draft':prepared})
        db.commit()
    except Exception: db.rollback(); raise
    return read_archive(root,db)

def _apply_scan_knowledge(db,q,scan,old_scan,subject):
    records,_=knowledge_catalog(db)
    ids_changed=old_scan is None or scan.get('knowledgeIds')!=old_scan.get('knowledgeIds')
    names_changed=old_scan is None or scan.get('knowledgePoints')!=old_scan.get('knowledgePoints')
    if ids_changed and 'knowledgeIds' in scan:
        q['knowledgeIds']=clone(scan['knowledgeIds']); validate_knowledge(db,q,subject)
        standard_names={r['name'] for r in records.values() if r['subject']==subject}
        custom=[n for n in scan['knowledgePoints'] if n not in standard_names]
        q['pc_knowledge_points']=[records[k]['name'] for k in q['knowledgeIds']]+custom
    elif names_changed:
        q['pc_knowledge_points']=labels(scan['knowledgePoints'])
        legacy=clone(q); legacy.pop('knowledgeIds',None)
        q['knowledgeIds']=question_knowledge(legacy,subject,records)[0]
    if old_scan is None or scan.get('reasons')!=old_scan.get('reasons'): q['pc_reasons']=clone(scan['reasons'])


def _save_group(root,db,old_group,group,draft,pages):
    p=clone(draft['paper']); pid=p['id']; before_p=db.execute('SELECT payload FROM papers WHERE id=?',(pid,)).fetchone()
    if before_p:
        existing=json.loads(before_p[0]); require(existing.get('pc_group_id')==group['id'],'试卷ID已存在，拒绝覆盖其他来源')
        updated_p=clone(existing)
        if p.get('coverage')=='partial': updated_p.update(coverage='partial',expected_question_count=None)
        if updated_p!=existing:
            db.execute('UPDATE papers SET payload=? WHERE id=?',(study.dumps(updated_p),pid))
            study.event(db,pid,'pc_coverage_revision',existing,updated_p)
    else:
        db.execute('INSERT INTO papers VALUES(?,?,?,?)',(pid,hashlib.sha256(study.dumps(draft).encode()).hexdigest(),study.dumps(p),study.now()))
        study.event(db,pid,'paper_import',None,p)
    scans={s['id']:s for s in group['questions']}; olds={s['id']:s for s in old_group['questions']}
    for original in draft['questions']:
        sid=original.get('pc_scan_id') or group['id']+'-q-'+hashlib.sha256(original['local_id'].encode()).hexdigest()[:16]
        scan=scans.get(sid); old_scan=olds.get(sid)
        if not scan or original.get('pc_manual') and scan['status']=='pending' and not has_question_content(scan,'fullText'): continue
        row=db.execute('SELECT id,payload FROM questions WHERE paper_id=? AND local_id=?',(pid,original['local_id'])).fetchone()
        qid=row['id'] if row else scan['canonicalId']
        before=json.loads(row['payload']) if row else None
        if row and scan==old_scan: continue
        q=clone(before or original); q['pc_scan_id']=sid
        for pc,canonical in [('fullText','text'),('answer','expected_answer'),('analysis','explanation'),('studentAnswer','student_answer')]:
            if not before or not old_scan or scan[pc]!=old_scan[pc]: q[canonical]=scan[pc] if pc=='fullText' else scan[pc] or None
        for key in CONTENT_FIELDS:
            if key in scan and (not before or not old_scan or scan.get(key)!=old_scan.get(key)): q[key]=clone(scan[key])
            elif old_scan and key in old_scan and key not in scan:q.pop(key,None)
        _apply_scan_knowledge(db,q,scan,old_scan if before else None,p['subject'])
        q['boxVerified']=scan.get('boxVerified',q.get('boxVerified',True))
        q['pc_excluded']=scan['status']=='excluded'
        if q['pc_excluded']: q['pc_exclusion_kind']=scan.get('exclusionKind','legacy')
        else: q.pop('pc_exclusion_kind',None)
        q['verdict']=scan['verdict']
        if q['verdict']=='correct' and (before or original).get('verdict')!='correct':
            study.clear_correct_attributions(q)
            old_draft=clone(original)
            original['verdict']='correct'
            study.clear_correct_attributions(original)
            scan['reasons']=[]
            scan['reason']=''
            scan['causeAnalysis']=''
            # Store prior draft analysis in the same transaction before clearing it.
            study.event(db,qid,'pc_draft_correct_revision',old_draft,original)
        q['decision_status']=scan['decisionStatus'] if scan['status']=='saved' else 'pending'
        if scan['status']=='saved' and q['decision_status']=='confirmed':
            q['basis']='user_confirmed'
            if not before or q['verdict']!=before.get('verdict') or q['decision_status']!=before.get('decision_status'):
                q['evidence']=(q.get('evidence') or '卷面判断')+'；用户在 PC 识别页确认'+({'wrong':'错误','correct':'正确','pending':'待确认','ungradable':'不可判定'}[q['verdict']])
        if scan['status']=='saved' and q['verdict']=='wrong' and q['decision_status']=='confirmed': scan['savedQuestionId']=qid
        else: scan.pop('savedQuestionId',None)
        q['pc_box']=clone(scan['box'])
        q['pc_images']=[{'url':pages[scan['pageId']]['url'],'label':pages[scan['pageId']]['label']+' · '+scan['number'],'box':clone(scan['box'])}]
        validate_fields(root,q); validate_knowledge(db,q,p['subject'],historical=before); study.validate_question(db,q,p['subject'],historical=before,canonical_id=qid)
        if before==q: continue
        if row: db.execute('UPDATE questions SET payload=?,fingerprint=? WHERE id=?',(study.dumps(q),study.fingerprint(p['subject'],q['text'],q.get('content')),qid))
        else: db.execute('INSERT INTO questions VALUES(?,?,?,?,?,?)',(qid,pid,q['local_id'],p['subject'],study.fingerprint(p['subject'],q['text'],q.get('content')),study.dumps(q)))
        study.event(db,qid,'pc_recognition_save' if before is None else 'pc_recognition_revision',before,q)


def _apply_recognition(root,db,old,new):
    require(isinstance(new,dict) and set(new)>={'pages','groups'},'识别工作区无效')
    require(new['pages']==old['pages'],'原图只能通过 Codex stage-pages 添加，不能从页面伪造或删除')
    pages={p['id']:p for p in old['pages']}; old_groups={g['id']:g for g in old['groups']}
    require(isinstance(new['groups'],list),'分组无效'); seen=set(); group_ids=set(); drafts=meta(db,'pc_drafts',{})
    for g in new['groups']:
        gid=g.get('id'); require(study.nonempty(gid) and gid not in group_ids,'分组ID缺失或重复'); group_ids.add(gid)
        require(study.nonempty(g.get('title')) and g.get('subject') in REVERSE,'分组名称/学科无效')
        require(isinstance(g.get('pageIds'),list) and g['pageIds'],'分组不能为空')
        for pid in g['pageIds']:
            require(pid in pages and pid not in seen and pages[pid]['subject']==g['subject'],'原图重复分组或学科不符'); seen.add(pid)
        previous=old_groups.get(gid)
        if previous:
            require(g.get('grade')==previous.get('grade'),'既有试卷年级不可随学生设置更改')
        else:
            page_grades={pages[pid].get('grade') for pid in g['pageIds']}
            require(len(page_grades)==1,'不同年级的原图请分成不同试卷')
            g['grade']=next(iter(page_grades))
        require(g.get('kind')==(previous or {}).get('kind'),'分组类型只能通过正式上传入口设置')
        if g.get('kind')=='practice':
            require(previous and all(g.get(k)==previous.get(k) for k in ('practicePaperId','paperId','resultDate','pageIds','subject')),'不能替换复练分组来源或日期')
        retry=bool(g.get('requested') and previous and not previous.get('requested') and not previous.get('recognized'))
        require(g.get('runStatus')==(previous or {}).get('runStatus'),'识别运行状态只能由本机 Codex 执行器更新')
        require(g.get('progress')==(previous or {}).get('progress'),'识别进度只能由本机 Codex 执行器更新')
        require(g.get('supplementTask')==(previous or {}).get('supplementTask'),'补充题识别状态只能由服务更新')
        for field in ('resultRecovery','recognitionNotes','recognitionScope','recognitionMode','detection','reportTask','reportData'):
            require(g.get(field)==(previous or {}).get(field),'识别恢复信息只能由服务更新')
        require(g.get('retryMode')==(previous or {}).get('retryMode') or retry and g.get('retryMode') in ('save','recognize'),'重试方式只能随新的识别请求设置')
        require(g.get('error')==(previous or {}).get('error') or retry and not g.get('error'),'不能伪造识别错误信息')
        if previous and (previous.get('requested') or previous.get('runStatus') in ('queued','running')):
            require(g.get('requested')==previous.get('requested') and g.get('requestId')==previous.get('requestId') and g['pageIds']==previous['pageIds'] and g['subject']==previous['subject'],'识别执行期间不可替换请求或原图分组')
        if retry and previous.get('runStatus')=='failed': require(g.get('requestId')!=previous.get('requestId'),'重试识别需要新的请求ID')
        if not previous or not previous.get('recognized'):
            require(not g.get('recognized') and not g.get('finalized') and g.get('questions')==[],'识别结果只能由 Codex 写入')
            if g.get('requested'): require(study.nonempty(g.get('requestId')),'请求需要稳定 requestId')
            continue
        require(g.get('recognized') is True and g['pageIds']==previous['pageIds'] and g['subject']==previous['subject'],'已有识别结果不可改来源分组')
        if previous.get('kind')=='practice':
            from pc_practice import apply_group
            apply_group(root,db,previous,g)
            continue
        require(gid in drafts and g.get('paperId',drafts[gid]['paper']['id'])==drafts[gid]['paper']['id'],'识别稿来源不存在或被替换')
        old_q={q['id']:q for q in previous['questions']}
        require(isinstance(g.get('questions'),list) and len({q['id'] for q in g['questions']})==len(g['questions']),'题目列表或ID无效')
        new_ids={q['id'] for q in g['questions']}
        canonical_by_scan={}
        for q in drafts[gid]['questions']:
            sid=q.get('pc_scan_id') or gid+'-q-'+hashlib.sha256(q['local_id'].encode()).hexdigest()[:16]
            canonical_by_scan[sid]=q
        removed=set(old_q)-new_ids
        require(all(old_q[sid]['status']=='pending' and not has_question_content(old_q[sid],'fullText') and canonical_by_scan.get(sid,{}).get('pc_manual') for sid in removed),'仅可取消尚未填写的手工补录题')
        if removed: drafts[gid]['questions']=[q for sid,q in canonical_by_scan.items() if sid not in removed]
        for q in g['questions']:
            require(study.nonempty(q.get('id')) and q.get('pageId') in g['pageIds'] and study.nonempty(q.get('number')),'补录题需要本卷既有图片及题号')
            original=old_q.get(q['id'])
            if original:
                require(q.get('pageId')==original['pageId'] and q.get('number')==original['number'],'题目来源和题号不能替换')
                require(q.get('canonicalId',original['canonicalId'])==original['canonicalId'],'不能替换题目档案ID')
                q['canonicalId']=original['canonicalId']
            else:
                require(q.get('status')=='pending','新补录题先保存草稿再确认入库')
                require(not any(q['id']==item['id'] for other in old['groups'] for item in other.get('questions',[])), '补录题ID重复')
                q['canonicalId']='scan-question-'+q['id']
                require(not db.execute('SELECT id FROM questions WHERE id=?',(q['canonicalId'],)).fetchone(),'补录题ID重复')
                source=source_path(root,pages[q['pageId']]['url'])
                assets=[dict(study.store_file(Path(root),source),role='original')]
                drafts[gid]['questions'].append({'local_id':'manual:'+q['id'],'number':q['number'],'page':g['pageIds'].index(q['pageId'])+1,'text':'','student_answer':None,'corrected_answer':None,'expected_answer':None,'explanation':None,'verdict':'pending','decision_status':'pending','evidence_level':'B','basis':'user_confirmed','evidence':'用户在本卷原图框选补充题目，待核对完整题干与作答','observed_error':'待用户核对','attributions':[],'requires_image':True,'assets':assets,'pc_scan_id':q['id'],'pc_manual':True})
                drafts[gid]['paper'].update(coverage='partial',expected_question_count=None)
            q.setdefault('verdict','wrong' if q.get('status')=='saved' else 'pending')
            q.setdefault('decisionStatus','confirmed' if q.get('status')=='saved' else 'pending')
            require(q.get('status') in ('pending','excluded','saved'),'保存状态无效')
            if q['status']=='excluded':
                q.setdefault('exclusionKind','legacy')
                require(q['exclusionKind'] in ('invalid','legacy'),'排除类型无效')
            else: q.pop('exclusionKind',None)
            require(q['verdict'] in study.VERDICTS and q['decisionStatus'] in ('pending','confirmed'),'正误或确认状态无效')
            require(q['verdict']!='pending' or q['decisionStatus']=='pending','待确认题不能标记已确认')
            for key in ('fullText','answer','analysis','studentAnswer'): require(isinstance(q.get(key),str),'识别文字字段无效')
            if q['status']=='saved': require(has_question_content(q,'fullText'),'保存前需要文字或题干图片')
            # Recognition may retain candidate labels beside the three formal IDs.
            # Preserve unchanged model output; enforce UI limits only on tag edits.
            for key,limit in [('knowledgePoints',3),('reasons',2)]:
                value=labels(q[key])
                if original is None or q[key]!=original.get(key):
                    require(len(value)<=limit, f"{g['title']} · 第{q['number']}题："+('知识点最多3个' if key=='knowledgePoints' else '错因最多2个'))
            validate_fields(root,q); validate_knowledge(db,q,subject_code(g['subject']),historical=original); _box(q['box'])
            if q.get('savedQuestionId'): require(q['savedQuestionId']==q['canonicalId'],'入库题目ID不符')
        require(not previous.get('finalized') or g.get('finalized'), '已保存识别结果不能撤销')
        if g.get('finalized') or any(q['status']=='saved' for q in g['questions']): _save_group(root,db,previous,g,drafts[gid],pages)
    require(all(not (g.get('recognized') or g.get('requested') or g.get('runStatus') in ('queued','running')) or gid in group_ids for gid,g in old_groups.items()),'不能删除已识别或识别中的分组')
    if drafts!=meta(db,'pc_drafts',{}): put_meta(db,'pc_drafts',drafts)
    persisted_groups={g['id']:g for g in meta(db,'pc_recognition',{'groups':[]})['groups']}
    for value in (old,new):
        for group in value['groups']:
            # Report expiry is a read-only projection, never a client-owned task transition.
            persisted=persisted_groups.get(group['id'],{})
            if 'reportTask' in persisted:group['reportTask']=clone(persisted['reportTask'])
            else:group.pop('reportTask',None)
            group.pop('reviewComplete',None)
            group.pop('reportData',None)
            for item in group.get('questions',[]):
                item.pop('reportResult',None);item.pop('reportInferredCorrect',None)
    if old!=new: put_meta(db,'pc_recognition',new); study.event(db,'pc_recognition','pc_workspace_revision',old,new)

def _apply_questions(root,db,old,new):
    old_map={q['id']:q for q in old}; require(isinstance(new,list),'错题列表无效')
    require(len({q['id'] for q in new})==len(new),'错题ID重复')
    require(set(old_map)=={q['id'] for q in new},'不能从页面任意新增或删除错题；请从识别结果入库')
    fields={'fullText':'text','answer':'expected_answer','analysis':'explanation','studentAnswer':'student_answer','causeAnalysis':'observed_error'}
    for q in new:
        before_pc=old_map[q['id']]
        if q==before_pc: continue
        for key in ('subject','originalId','uploadTime','images','grade'):
            require(q.get(key)==before_pc.get(key),'不能更换题目学科、来源、日期或原始题图')
        row=db.execute('SELECT * FROM questions WHERE id=?',(q['id'],)).fetchone(); before=json.loads(row['payload']); updated=clone(before)
        for pc,canonical in fields.items():
            if q.get(pc,'')!=before_pc.get(pc,''):
                require(isinstance(q.get(pc),str),'题目内容必须为文字'); updated[canonical]=q[pc]
        if q.get('mastery')!=before_pc.get('mastery'):
            require(q.get('mastery') in ('未掌握','已掌握'),'掌握状态无效'); updated['pc_mastery']=q['mastery']; updated['pc_mastery_after']=attempt_baseline(before_pc.get('attempts',[]))
        for key,limit in [('knowledgePoints',3),('reasons',2)]:
            if q.get(key)!=before_pc.get(key):
                value=labels(q.get(key)); require(len(value)<=limit,'标签数量超出限制')
        _apply_scan_knowledge(db,updated,q,before_pc,row['subject'])
        for key in CONTENT_FIELDS:
            if q.get(key)!=before_pc.get(key): updated[key]=clone(q.get(key))
        if updated.get('content')!=before.get('content') and before.get('diagram_review'):
            updated['diagramReviewRequired']=True;updated.pop('diagram_review',None)
        if q.get('diagramReviewConfirmed') is True:
            require(updated.get('diagramReviewRequired') is True,'本题没有待核对重建题图')
            require(any(b.get('type')=='image' for b in (updated.get('content') or {}).get('blocks',[])),'没有可核对的干净题图')
            updated['diagramReviewRequired']=False
            updated['diagram_review']={'source':'user_confirmed','at':study.now(),'evidence':'用户在题目详情明确点击已对照原图核对题图'}
        validate_fields(root,updated); validate_knowledge(db,updated,row['subject'],historical=before); study.validate_question(db,updated,row['subject'],historical=before,canonical_id=row['id'])
        if updated!=before:
            db.execute('UPDATE questions SET payload=?,fingerprint=? WHERE id=?',(study.dumps(updated),study.fingerprint(row['subject'],updated['text'],updated.get('content')),q['id']))
            study.event(db,q['id'],'pc_question_revision',before,updated)

def _apply_practices(root,db,old_archive,new_archive):
    stored=meta(db,'pc_practice',{}); updated=clone(stored)
    old_practices={p['id']:p for p in old_archive['papers'] if p['kind']=='practice'}
    old_originals={p['id']:p for p in old_archive['papers'] if p['kind']=='original'}
    require(isinstance(new_archive['papers'],list),'试卷列表无效')
    require(len({p['id'] for p in new_archive['papers']})==len(new_archive['papers']),'试卷ID重复')
    actual_originals={p['id']:p for p in new_archive['papers'] if p['kind']=='original'}
    require(actual_originals==old_originals,'原卷报告由真实逐题记录计算，不能手动伪造或删除')
    question_map={q['id']:q for q in old_archive['questions']}; new_questions={q['id']:q for q in new_archive['questions']}; seen=set()
    for p in new_archive['papers']:
        if p['kind']=='original': continue
        require(p['kind']=='practice','试卷类型无效'); pid=p['id']; seen.add(pid); old=stored.get(pid)
        if old and p==old_practices.get(pid): continue
        require(study.nonempty(pid) and pid not in old_originals and study.nonempty(p.get('title')),'组卷ID或标题无效')
        ids=p.get('questionIds'); require(isinstance(ids,list) and ids and len(set(ids))==len(ids),'请选择不重复的题目')
        if old:
            for qid in ids:
                row=db.execute('SELECT subject FROM questions WHERE id=?',(qid,)).fetchone()
                require(row and SUBJECTS[row['subject']]==p.get('subject'),'组卷题目不存在或跨学科')
        else: require(all(qid in question_map and question_map[qid]['subject']==p.get('subject') for qid in ids),'组卷题目不存在或跨学科')
        real_date(p.get('date'))
        if old:
            require(all(p.get(k)==old.get(k) for k in ('questionIds','subject','date','sources','beforeMastery','grade')),'不能更改已生成卷的来源、日期或题目')
            candidate=clone(old); candidate['title']=p['title']; candidate['status']=p['status']
            require(p.get('results',{})==old.get('results',{}),'批改预判只能由 Codex 导入；人工修正单独保留')
        else:
            require(not p.get('results') and not p.get('savedResults') and not p.get('sources'),'新组卷不能伪造批改结果')
            candidate={k:clone(p[k]) for k in ('id','title','subject','date','kind','questionIds','status','sources')}
            grade=p.get('grade') if 'grade' in p else __import__('student_profile').read_profile(root,db).get('grade')
            require(grade is None or type(grade) is int and 1<=grade<=12,'组卷年级必须为一年级至高三或未分年级')
            candidate['grade']=grade
            candidate['beforeMastery']={qid:question_map[qid]['mastery'] for qid in ids}
        require(type(p.get('deleted',False)) is bool,'组卷删除状态无效')
        if 'deleted' in p: candidate['deleted']=p['deleted']
        require(candidate['status'] in ('已生成','已打印','已批改'),'组卷状态无效')
        saved=p.get('savedResults',{})
        if saved!=((old or {}).get('savedResults') or {}):
            require(old and (set(old.get('pc_result_details',{}))==set(ids) or set(old.get('results',{}))==set(ids)) and set(saved)==set(ids) and all(v in ('correct','incorrect') for v in saved.values()),'需要真实完整的批改结果后才能保存或修正')
            candidate['savedResults']=clone(saved); candidate['status']='已批改'
            candidate['pc_result_dates']=clone(old.get('pc_result_dates',{}))
            candidate['pc_result_recorded_at']=clone(old.get('pc_result_recorded_at',{}))
            for qid in ids:
                candidate['pc_result_dates'].setdefault(qid,old.get('pc_result_date',old['date']))
                candidate['pc_result_recorded_at'].setdefault(qid,old.get('pc_result_received_at') or study.now())
        if candidate['status']=='已批改': require(candidate.get('savedResults'),'尚未保存批改结果')
        if candidate.get('savedResults') and candidate.get('savedResults')!=((old or {}).get('savedResults') or {}):
            from pc_practice import sync_saved_group
            sync_saved_group(db,candidate)
        if candidate!=old: updated[pid]=candidate; study.event(db,pid,'pc_practice_revision' if old else 'pc_practice_create',old,candidate)
    require(set(stored)<=seen,'不能删除已有复习卷')
    if updated!=stored: put_meta(db,'pc_practice',updated)

def apply_archive(root,db,archive,expected_revision):
    require(isinstance(archive,dict) and archive.get('version')==1 and archive.get('mode')=='local','只接受正式本地档案')
    db.execute('BEGIN IMMEDIATE')
    try:
        if expected_revision!=revision(db): raise ConflictError('档案已被另一个窗口更新，请刷新后重新操作')
        old=_read_archive(root,db)
        # Validate client lists against the old projection. New records originate solely from saved recognition transitions.
        _apply_questions(root,db,old['questions'],archive['questions'])
        _apply_recognition(root,db,old['recognition'],clone(archive.get('recognition',old['recognition'])))
        _apply_practices(root,db,old,archive)
        db.commit()
    except Exception: db.rollback(); raise
    return read_archive(root,db)

def put_practice_results(root,db,paper_id,data):
    date=real_date(data.get('date')); require(isinstance(data.get('results'),dict),'请提供逐题批改结果')
    sources=[study.store_file(Path(root),p) for p in data.get('sources',[])]
    db.execute('BEGIN IMMEDIATE')
    try:
        practices=meta(db,'pc_practice',{}); old=practices.get(paper_id); require(old,'复习卷不存在')
        require(set(data['results'])==set(old['questionIds']),'批改结果必须完整对应本卷题目')
        new=clone(old); details={}; results={}
        for qid,item in data['results'].items():
            require(item.get('result') in ('correct','wrong','incorrect'),'批改结果无效')
            require(isinstance(item.get('answer'),str) and study.nonempty(item.get('evidence')),'需保留真实作答及批改证据')
            require(type(item.get('independent')) is bool,'需注明是否独立完成')
            require(isinstance(item.get('knowledge_point_ids'),list),'需提供已核实知识点数组，可为空')
            canonical=json.loads(db.execute('SELECT payload FROM questions WHERE id=?',(qid,)).fetchone()[0])
            eligible={a.get('knowledge_point_id') for a in canonical.get('attributions',[])} | set(canonical.get('knowledgeIds',[]))
            require(set(item['knowledge_point_ids'])<=eligible,'复练验证的知识点必须来自原题正式关联')
            details[qid]=clone(item); results[qid]='correct' if item['result']=='correct' else 'incorrect'
        if old.get('savedResults'):
            require(date==old.get('pc_result_date'),'同次批改修正必须保留真实作答日期')
        new.update(results=results,pc_result_details=details,pc_result_date=date)
        new.setdefault('pc_result_received_at',study.now())
        if sources: new['sources']=[file_asset(root,a) for a in sources]
        if new!=old: practices[paper_id]=new; put_meta(db,'pc_practice',practices); study.event(db,paper_id,'pc_practice_result_import',old,new)
        from pc_practice import sync_imported_results
        sync_imported_results(root,db,paper_id)
        db.commit()
    except Exception: db.rollback(); raise
    return read_archive(root,db)


def stage_practice_pages(root,db,paths,paper_id,date):
    from pc_practice import group_id
    db.execute('BEGIN IMMEDIATE')
    try:
        practices=meta(db,'pc_practice',{});paper=practices.get(paper_id)
        require(paper,'复习卷不存在');date=real_date(date)
        existing_date=paper.get('pc_result_date')
        require(not paper.get('savedResults') or existing_date,'已确认复练缺少原始作答日期，请先核对历史记录')
        require(not existing_date or real_date(existing_date)==date,'本卷已有其他日期作答；新一次复练请重新组卷')
        imports=_stage_import_plan(root,db,paths,subject_code(paper['subject']),paper_id)
        ids=list(dict.fromkeys(i['pageId'] for i in imports))
        recognition=meta(db,'pc_recognition',{'pages':[],'groups':[]});before=clone(recognition)
        gid=group_id(paper_id);group=next((g for g in recognition['groups'] if g['id']==gid),None)
        if group:
            require(group.get('kind')=='practice' and group.get('practicePaperId')==paper_id,'复练分组身份冲突')
            require(group.get('resultDate')==date,'本卷已有其他日期作答；新一次复练请重新组卷')
            require(set(ids)<=set(group['pageIds']) or not (group.get('recognized') or group.get('requested') or group.get('runStatus') in ('queued','running')),'识别后不能更换原图；请修订已有结果')
        else:
            group={'id':gid,'kind':'practice','practicePaperId':paper_id,'grade':paper.get('grade'),'paperId':paper_id,'title':paper['title']+' · 复练批改','subject':paper['subject'],'resultDate':date,'pageIds':[],'questions':[],'recognized':False,'requested':False,'finalized':False}
            recognition['groups'].append(group)
        for item in imports:
            if not any(p['id']==item['pageId'] for p in recognition['pages']):
                recognition['pages'].append({'id':item['pageId'],'label':item['sourceName'],'url':item['previewUrl'],'subject':paper['subject'],'date':date.replace('-','.')})
            if item['pageId'] not in group['pageIds']: group['pageIds'].append(item['pageId'])
        old_paper=clone(paper);page_map={p['id']:p for p in recognition['pages']}
        existing_sources={a['url']:a for a in paper.get('sources',[])}
        paper['sources']=[clone(existing_sources.get(page_map[p]['url']) or {'url':page_map[p]['url'],'label':page_map[p]['label']}) for p in group['pageIds']]
        paper['pc_result_date']=date
        if paper!=old_paper:
            put_meta(db,'pc_practice',practices);study.event(db,paper_id,'pc_practice_stage',old_paper,paper)
        if recognition!=before:
            put_meta(db,'pc_recognition',recognition);study.event(db,gid,'stage_practice_pages',before,recognition)
        _save_image_imports(db,imports)
        db.commit()
    except Exception: db.rollback(); raise
    return dict(read_archive(root,db),stagedPageIds=ids,practiceRecognitionId=gid,importResults=_import_response(imports))

def backfill_practice_recognition(root,db):
    from pc_practice import backfill_practice_recognition as backfill
    return backfill(root,db)
