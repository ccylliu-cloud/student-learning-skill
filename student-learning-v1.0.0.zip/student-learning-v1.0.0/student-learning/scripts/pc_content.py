"""Validate the portable rich question content shared by PC and Word output."""
from __future__ import annotations
import math, re
from pathlib import Path


def require(ok, message):
    if not ok: raise ValueError(message)


def content_plain_text(content):
    if not content: return ''
    return '\n'.join(''.join(run['text'] for run in block['runs'])
                     for block in content['blocks'] if block['type']=='paragraph')


def has_question_content(value, text_key='text'):
    # Rich content is structurally validated by validate_fields before persistence.
    return bool(str(value.get(text_key) or '').strip() or
                any(isinstance(block,dict) and block.get('type')=='image'
                    for block in (value.get('content') or {}).get('blocks',[])))


def validate_fields(root, value):
    for key in ('sectionTitle', 'sharedContext'):
        if key in value: require(isinstance(value[key],str) and len(value[key])<=30000, '题目分区标题或共用材料无效')
    if 'answerLayout' in value and value['answerLayout'] is not None:
        layout=value['answerLayout']
        require(isinstance(layout,dict) and set(layout)<={'kind','lines','heightCm'},'作答版式无效')
        require(layout.get('kind') in ('inline','lines','space'),'作答版式类型无效')
        if 'lines' in layout: require(type(layout['lines']) is int and 1<=layout['lines']<=12,'作答行数需为1至12')
        if 'heightCm' in layout: require(type(layout['heightCm']) in (int,float) and math.isfinite(layout['heightCm']) and 1<=layout['heightCm']<=15,'作答空间高度无效')
    if 'content' not in value or value['content'] is None: return
    content=value['content']
    require(isinstance(content,dict) and set(content)=={'version','blocks'} and content['version']==1,'题干内容版本无效')
    require(isinstance(content['blocks'],list) and len(content['blocks'])<=300,'题干内容块无效')
    for block in content['blocks']:
        require(isinstance(block,dict),'题干内容块无效')
        if block.get('type')=='paragraph':
            require(set(block)=={'type','runs'} and isinstance(block['runs'],list) and len(block['runs'])<=1000,'题干文字格式无效')
            for run in block['runs']:
                require(isinstance(run,dict) and set(run)<={'text','underline','bold','italic'} and isinstance(run.get('text'),str),'题干文字格式无效')
                require(len(run['text'])<=50000 and all(type(run[k]) is bool for k in ('underline','bold','italic') if k in run),'题干文字格式无效')
        elif block.get('type')=='image':
            require(set(block)<={'type','asset','widthCm'},'题干图片格式无效')
            asset=block.get('asset')
            require(isinstance(asset,dict) and set(asset)=={'url','label'} and isinstance(asset.get('label'),str),'题干图片素材无效')
            url=asset.get('url')
            require(isinstance(url,str) and re.fullmatch(r'/files/[A-Za-z0-9_.-]+',url),'题干图片必须来自本地档案')
            path=(Path(root)/'assets'/url.rsplit('/',1)[1]).resolve()
            require(path.is_relative_to((Path(root)/'assets').resolve()) and path.is_file() and path.suffix.lower() in ('.png','.jpg','.jpeg','.webp'), '题干图片不存在或格式不支持')
            if 'widthCm' in block: require(type(block['widthCm']) in (int,float) and math.isfinite(block['widthCm']) and 0<block['widthCm']<=18,'题干图片宽度无效')
        else: raise ValueError('不支持的题干内容块')


CONTENT_FIELDS=('content','sectionTitle','sharedContext','answerLayout')
