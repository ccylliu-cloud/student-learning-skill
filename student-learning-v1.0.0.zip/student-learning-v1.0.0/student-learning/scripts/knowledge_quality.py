"""Local ingestion checks; no model calls, semantic guessing, or historical rewrites."""
import json


def reconcile_knowledge(db, q, subject, grade=None):
    # Only new machine drafts. Human decisions and edits must never be re-labelled.
    if q.get('basis') == 'user_confirmed' or q.get('decision_status') == 'confirmed':
        return
    ids = q.get('knowledgeIds', [])
    if not isinstance(ids, list) or any(not isinstance(k, str) for k in ids):
        raise ValueError('知识点ID必须为文字数组')
    ids = list(dict.fromkeys(ids))
    attrs = q.get('attributions', [])
    if not isinstance(attrs, list) or any(not isinstance(a, dict) for a in attrs):
        raise ValueError('归因必须为对象数组')
    def record(k):
        r = db.execute('SELECT subject,name,payload FROM knowledge WHERE id=?', (k,)).fetchone()
        return r if r and r['subject'] == subject else None
    def eligible(r):
        raw = json.loads(r['payload'])
        if raw.get('node_type') == 'pending_topic' or raw.get('content_status') == 'pending_body_confirmation' or raw.get('assessment_policy', {}).get('mode') == 'review_only':
            return False
        if subject == 'math':
            allowed = ('math-k12-knowledge' if grade <= 9 else 'math-highschool-knowledge') if type(grade) is int else None
            return allowed is not None and raw.get('knowledge_base_id') == allowed and raw.get('is_assessable') is True
        return True
    reviews = q.setdefault('knowledgeReview', [])
    def note(code, message):
        if not any(r.get('code') == code for r in reviews):
            reviews.append({'code': code, 'message': message})
    attr_ids = []
    for a in attrs:
        k = a.get('knowledge_point_id')
        if not k:
            continue
        r = record(k)
        if r and eligible(r) and a.get('status') == 'provisional' and a.get('evidence', '').strip() and a.get('knowledge_name') in (None, '', r['name']):
            if k not in attr_ids:
                attr_ids.append(k)
        elif k not in ids:
            note('attribution_unresolved', '归因引用尚不能作为正式知识点，需核对适用范围和依据。')
    if not ids and 0 < len(attr_ids) <= 3:
        ids = attr_ids
        note('recovered_from_attribution', '正式标签原为空，已从同题有依据的暂定归因恢复知识点；仍待复核。')
    elif any(k not in ids for k in attr_ids):
        note('attribution_mismatch', '题目标签与归因引用不一致，保留原选择，待核对核心考点。')
    q['knowledgeIds'] = ids
    names = [record(k)['name'] for k in ids if record(k)]
    candidates = q.get('pc_knowledge_points', []) + [a.get('knowledge_name') for a in attrs if not a.get('knowledge_point_id') and a.get('knowledge_name')]
    retained = q.setdefault('knowledgeSelectionCandidates', [])
    for name in dict.fromkeys(candidates):
        if name not in names and not any(c.get('name') == name for c in retained):
            retained.append({'name': name, 'reason': '未核实的描述，保留为候选，不展示为正式标签'})
    q['pc_knowledge_points'] = names
    if not ids:
        note('unmatched', '知识点尚未匹配；允许留空，需结合题干和知识库规则复核，不按名称强配。')
    # Compact, visible in the existing evidence field. No extra UI module or API call.
    if reviews:
        q['knowledgeSelectionReview'] = True
        for review in reviews:
            message = '知识关联检查：' + review['message']
            if message not in q.get('evidence', ''):
                q['evidence'] = (q.get('evidence') or '') + '；' + message
