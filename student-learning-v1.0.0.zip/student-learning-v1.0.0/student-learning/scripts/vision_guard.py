"""Bounded image-access reports. Reports are model/tool assertions, not proof of perception."""
import copy, datetime as dt, hashlib, json, re, uuid
from pathlib import Path

TIMEOUT_SECONDS=1200
BLOCKED_MESSAGE='当前会话无法读取图片，识别已停止，尚未写入题目或判定。请切换到支持读图的模型/会话，或直接在对话附上图片；确认可以看图后再明确重试。不要反复裁图、生成占位题目或编造答案。'
PATTERNS=('does not support images','does not support image inputs','image input is not supported','content filtered','image inputs are not supported','unable to view images','cannot view images','不支持图片','不支持图像','无法读取图片','图片读取被过滤')

def blocked_error(value):
    text=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False)
    return any(p in text.lower() for p in PATTERNS)

def validate_report(value,count):
    if not isinstance(value,dict):raise ValueError('缺少逐页读图报告 vision；未实际看图不得提交题目或判定。')
    if value.get('status')!='readable' or blocked_error(value.get('error','')) or blocked_error(value.get('toolError','')):
        raise ValueError(BLOCKED_MESSAGE)
    pages=value.get('pages')
    if not isinstance(pages,list) or len(pages)!=count:raise ValueError('读图报告必须逐页覆盖本组全部图片；不可见页面应报告阻断。')
    seen=set()
    for page in pages:
        if not isinstance(page,dict) or type(page.get('page')) is not int or not 1<=page['page']<=count or page['page'] in seen:raise ValueError('读图报告页码缺失、重复或超出范围。')
        seen.add(page['page'])
        if page.get('status')!='readable' or blocked_error(page.get('toolError','')) or blocked_error(page.get('error','')):raise ValueError(BLOCKED_MESSAGE)
        observation=page.get('observation')
        if not isinstance(observation,str) or not 2<=len(observation.strip())<=500:raise ValueError('每页需要一条实际可见的印刷标题/文字片段或图形特征，不能只填“已看图”。')
        if observation.strip() in ('已看图','可见','已读取','readable','success','已看清'):raise ValueError('不能用通用成功标记代替逐页可见内容记录。')
    return copy.deepcopy(value)

def digest(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
def stamp():return dt.datetime.now(dt.timezone.utc).timestamp()
def folder(root):return Path(root)/'drafts'/'vision-sessions'
def failure_path(root,gid):return folder(root)/('blocked-'+hashlib.sha256(gid.encode()).hexdigest()+'.json')
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)
    finally:temp.unlink(missing_ok=True)

def create(root,gid,fingerprint,images,retry=False):
    failure=failure_path(root,gid)
    if failure.exists() and not retry:raise ValueError(BLOCKED_MESSAGE+' 上次阻断仍保留；用户确认已换读图方式后，使用 conversation-export --retry-vision。')
    sid=uuid.uuid4().hex
    record={'version':2,'sessionId':sid,'root':str(Path(root).resolve()),'groupId':gid,'fingerprint':fingerprint,'images':images,'createdAt':stamp(),'expiresAt':stamp()+TIMEOUT_SECONDS,'state':'awaiting_read','reportTrust':'self_reported_not_independent_vision_proof'}
    write(folder(root)/(sid+'.json'),record)
    if retry:failure.unlink(missing_ok=True)
    return record

def load(root,manifest):
    sid=manifest.get('sessionId','')
    if manifest.get('version')!=2 or not isinstance(sid,str) or not re.fullmatch('[a-f0-9]{32}',sid):raise ValueError('请用 v0.2.1 重新导出识别任务；旧任务不能直接提交。')
    p=folder(root)/(sid+'.json')
    if not p.is_file():raise ValueError('识别任务不属于本档案，或会话记录缺失，请重新导出。')
    record=json.loads(p.read_text(encoding='utf-8'))
    for field in ('sessionId','root','groupId','fingerprint','images'):
        if record.get(field)!=manifest.get(field):raise ValueError('识别任务清单已变更或不属于本档案，请重新导出。')
    if record['root']!=str(Path(root).resolve()):raise ValueError('识别任务不属于当前档案。')
    if record.get('state') in ('blocked','consumed'):raise ValueError('识别任务已阻断或已提交，不能重复使用。')
    if stamp()>record['expiresAt']:raise ValueError('识别任务已超过20分钟，请停止旧任务；检查读图能力后重新导出。')
    return p,record

def report(root,manifest,value,count):
    p,r=load(root,manifest)
    try:value=validate_report(value,count)
    except ValueError as e:
        if isinstance(value,dict) and (str(e)==BLOCKED_MESSAGE or value.get('status')!='readable' or blocked_error(value)):
            block(root,manifest,value.get('error') or value.get('toolError') or str(e))
        raise
    r.update(state='reported_readable',vision=value,reportedAt=stamp());write(p,r)
    return r

def block(root,manifest,reason):
    p,r=load(root,manifest)
    r.update(state='blocked',reason=str(reason)[:2000],blockedAt=stamp());write(p,r);write(failure_path(root,r['groupId']),r)
    return r

def ready(root,manifest,result,count):
    p,r=load(root,manifest)
    if r.get('state')!='reported_readable':raise ValueError('尚未记录本次逐页读图情况。先执行 conversation-vision；读图失败则 conversation-block，不能提交答案。')
    if digest(validate_report(result.get('vision'),count))!=digest(r['vision']):raise ValueError('结果中的 vision 与本次读图记录不一致，请核对后重新记录。')
    return p,r

def consume_validated(session):
    # Finalize the already-validated receipt after the database commit, even at the deadline.
    p,r=session;r.update(state='consumed',submittedAt=stamp());write(p,r)


def native_event_blocked(event):
    """Inspect failure fields, never search successful command output or quoted instructions."""
    if not isinstance(event,dict):return False
    if event.get('type') in ('error','turn.failed'):
        return blocked_error(event.get('error') or event.get('message') or '')
    if event.get('type')!='item.completed':return False
    item=event.get('item') or {}
    if not isinstance(item,dict):return False
    if item.get('type')=='command_execution':
        return bool(item.get('exit_code')) and blocked_error(item.get('aggregated_output',''))
    if item.get('type')=='agent_message':
        text=item.get('text','').strip()
        if text.startswith('```json'):text=text[7:].removesuffix('```').strip()
        try:value=json.loads(text)
        except (ValueError,TypeError):return False
        return isinstance(value,dict) and value.get('status') in ('image_blocked','blocked')
    if item.get('error'):return blocked_error(item['error'])
    result=item.get('result') or {}
    return isinstance(result,dict) and bool(result.get('isError')) and blocked_error(result.get('content',result))
