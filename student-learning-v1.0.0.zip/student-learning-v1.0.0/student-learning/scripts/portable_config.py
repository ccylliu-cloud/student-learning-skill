"""Workspace-local runtime configuration; never reads production service config."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
from storage_checks import plain_path, probe_directory

SKILL = Path(__file__).resolve().parents[1]
INSTALL_ID = hashlib.sha256(str(SKILL).encode('utf-8')).hexdigest()[:16]
CONFIG = SKILL / 'runtime' / 'runtime.json'


def host():
    marker = SKILL / 'trial-install.json'
    value = json.loads(marker.read_text(encoding='utf-8')) if marker.exists() else {}
    result = value.get('host', 'workbuddy')
    if result not in ('codex', 'workbuddy'):
        raise ValueError('试用安装的 host 无效，请重新安装到新目录')
    return result


def infer_workspace():
    # Only a documented project Skill layout identifies a workspace, never cwd.
    if SKILL.parent.name == 'skills' and SKILL.parent.parent.name in ('.codebuddy','.workbuddy'):
        return SKILL.parent.parent.parent.resolve()
    return None


def read_config():
    if CONFIG.exists():
        value = json.loads(CONFIG.read_text(encoding='utf-8'))
        if value.get('version') != 1 or not isinstance(value.get('root'), str):
            raise ValueError('试用版运行设置格式无效：' + str(CONFIG))
        return value
    workspace = infer_workspace()
    if host() == 'workbuddy' and workspace is None:
        raise ValueError('尚未指定 WorkBuddy 工作区。请运行 setup_runtime.py --workspace "当前项目绝对目录"，不要猜测当前命令所在目录。')
    root = workspace / '学习档案' if workspace else Path.home() / '.local/share/student-learning/codex' / INSTALL_ID
    return {'version':1, 'root':str(root), **({'workspace':str(workspace)} if workspace else {})}


def atomic(path, raw):
    path = plain_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.runtime-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        # Only clean the exact temporary file created by this invocation.
        # Old/unknown .runtime-* files are ignored, never swept or treated as active config.
        if os.path.exists(temporary): os.unlink(temporary)


def validate_root(value, workspace=None):
    root = plain_path(value)
    if root == SKILL or SKILL in root.parents or root in SKILL.parents:
        raise ValueError('学习档案与 Skill 安装目录不可相同或互相嵌套')
    if host() == 'workbuddy':
        workspace = workspace or read_config().get('workspace')
        if not workspace: raise ValueError('请先明确设置 WorkBuddy 当前工作区 --workspace')
        workspace = plain_path(workspace)
        if root == workspace or workspace not in root.parents:
            raise ValueError('WorkBuddy 档案请选择当前工作区内部的独立目录：' + str(workspace / '学习档案'))
    return root


def select_root(value=None, workspace=None, reuse_existing=False):
    prior = read_config() if CONFIG.exists() else None
    if workspace is not None:
        workspace = plain_path(workspace)
        if not workspace.is_dir(): raise ValueError('工作区必须是已存在的项目目录')
        if prior and prior.get('workspace') and Path(prior['workspace']).resolve() != workspace:
            raise ValueError('本安装已绑定其他工作区。请使用新安装目录，或在网页设置中选择本工作区内的新档案位置。')
    else:
        workspace = (prior or {}).get('workspace') or infer_workspace()
    if host() == 'workbuddy' and workspace is None:
        raise ValueError('WorkBuddy 必须明确 --workspace；也可将 Skill 放在项目的 .codebuddy/skills/student-learning 目录')
    current = prior or {'version':1, 'root':str(Path(workspace)/'学习档案' if workspace else Path.home()/'.local/share/student-learning/codex'/INSTALL_ID)}
    root = validate_root(value or current['root'], workspace)
    if prior and Path(prior['root']).resolve() != root:
        raise ValueError('已有档案位置已配置。请在网页“学生设置”迁移，不能用 --root 静默切换；原档案保持不变。')
    if (root/'study.sqlite3').exists() and prior is None and not reuse_existing:
        raise ValueError('此目录已有学习档案。核对后加 --reuse-existing 明确复用；或选择新的空目录，不会覆盖原记录。')
    probe_directory(root)
    current = {**current,'root':str(root), **({'workspace':str(workspace)} if workspace else {})}
    if prior != current:
        atomic(CONFIG,json.dumps(current,ensure_ascii=False,indent=2).encode('utf-8'))
    return root
