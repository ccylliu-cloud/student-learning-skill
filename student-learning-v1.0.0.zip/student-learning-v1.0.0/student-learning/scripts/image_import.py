"""Local image decoding and evidence-preserving preparation; no OCR/network calls."""
from __future__ import annotations
import hashlib
import io
import subprocess
import sys
import tempfile
import warnings
from pathlib import Path
from PIL import Image, ImageOps, UnidentifiedImageError

ALLOWED = {'.png', '.jpg', '.jpeg', '.webp', '.heic', '.heif'}
HEIF_FORMATS = {'HEIF', 'HEIC'}
WEB_FORMATS = {'PNG', 'JPEG', 'WEBP'}

def _read(path):
    with warnings.catch_warnings():
        warnings.simplefilter('error', Image.DecompressionBombWarning)
        with Image.open(path) as original:
            if getattr(original, 'n_frames', 1) != 1:
                raise ValueError('包含多帧/多页图片，请先逐页导出静态图片后导入')
            fmt = original.format
            orientation = original.getexif().get(274, 1)
            image = ImageOps.exif_transpose(original)
            image.load()
            return image.copy(), fmt, orientation

def decode(path, work_dir=None):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f'找不到图片：{path.name}')
    if path.suffix.lower() not in ALLOWED:
        raise ValueError(f'{path.name}：格式不支持，请提供 PNG/JPEG/WebP/HEIC/HEIF；PDF 请先逐页导出图片')
    heif = path.suffix.lower() in {'.heic', '.heif'}
    plugin = False
    if heif:
        try:
            from pillow_heif import register_heif_opener
            register_heif_opener()
            plugin = True
        except ImportError:
            pass
    try:
        image, fmt, orientation = _read(path)
        if fmt not in WEB_FORMATS | HEIF_FORMATS:
            raise ValueError(f'{path.name}：文件实际为 {fmt}，不是支持的图片格式')
        return image, fmt, orientation, 'pillow-heif' if fmt in HEIF_FORMATS else 'Pillow'
    except PermissionError as exc:
        raise ValueError(f'{path.name}：没有读取图片的权限，请允许访问文件或复制到当前工作区后重试') from exc
    except (OSError, UnidentifiedImageError, SyntaxError) as first:
        if not heif:
            raise ValueError(f'{path.name}：图片损坏或内容不是有效图片，无法完整解码') from first
        if sys.platform != 'darwin':
            if not plugin:
                raise ValueError(f'{path.name}：缺少 HEIC 解码器，请通过安装器补装 pillow-heif 后重试，或导出 JPEG/PNG') from first
            raise ValueError(f'{path.name}：HEIC 无法解码，文件可能损坏或编码不受当前解码器支持') from first
        # WorkBuddy may only allow writes inside the selected archive/workspace.
        # Create this directory lazily: ordinary images and plugin decoding need no scratch files.
        if work_dir is not None:
            work_dir = Path(work_dir)
            work_dir.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='student-heic-', dir=work_dir) as work:
            out = Path(work) / 'decoded.png'
            try:
                result = subprocess.run(['/usr/bin/sips', '-s', 'format', 'png', str(path), '--out', str(out)], capture_output=True, timeout=60)
                if result.returncode or not out.is_file():
                    raise OSError('decoder failed')
                image, fmt, orientation = _read(out)
                if fmt != 'PNG':
                    raise OSError('invalid decoded output')
                return image, 'HEIF', orientation, 'macOS sips'
            except (OSError, subprocess.TimeoutExpired, SyntaxError) as exc:
                raise ValueError(f'{path.name}：macOS 未能完整解码 HEIC（文件损坏、编码不支持或系统解码权限受限）；请检查原图或导出 JPEG/PNG 后重试') from exc
    except (Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError(f'{path.name}：图片像素过大，请缩小后重试') from exc

def pixel_hash(image):
    """Exact oriented RGBA samples + dimensions + profile, not fuzzy page identity."""
    pixels = image.convert('RGBA')
    digest = hashlib.sha256()
    digest.update(f'rgba-exif-v1:{pixels.width}:{pixels.height}:'.encode())
    digest.update(hashlib.sha256(image.info.get('icc_profile') or b'').digest())
    digest.update(pixels.tobytes())
    return digest.hexdigest()

def prepare(root, source):
    import study
    path = Path(source).expanduser().resolve()
    image, fmt, orientation, decoder = decode(path, work_dir=Path(root) / 'drafts' / 'image-decoding')
    source_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    original = study.store_file(Path(root), path)
    converted = fmt in HEIF_FORMATS or orientation not in (None, 1)
    extensions = {'PNG': {'.png'}, 'JPEG': {'.jpg', '.jpeg'}, 'WEBP': {'.webp'}}
    mismatch = fmt in WEB_FORMATS and path.suffix.lower() not in extensions[fmt]
    if converted or mismatch:
        buffer = io.BytesIO()
        image.save(buffer, format='PNG')
        raw = buffer.getvalue(); sha = hashlib.sha256(raw).hexdigest()
        target = Path(root) / 'assets' / (sha + '.png')
        if not target.exists(): target.write_bytes(raw)
        asset = {'path': str(target.relative_to(root)), 'sha256': sha, 'original_name': path.name}
    else:
        asset = dict(original)
    return {'asset': asset, 'sourcePath': str(path), 'sourceName': path.name,
            'sourceSha256': source_hash, 'originalAsset': original,
            'pixelHash': pixel_hash(image), 'pixelHashVersion': 'rgba-exif-v1',
            'converted': bool(converted or mismatch), 'orientationApplied': orientation not in (None, 1),
            'decoder': decoder, 'width': image.width, 'height': image.height,
            'extensionMismatch': mismatch, 'qualityWarnings':(['page_resolution_review: 短边低于1600像素，请核对手写细节；不能仅据尺寸断言原图被压缩'] if min(image.size)<1600 else []), 'inputProvenance':'local_file_bytes', 'resampledBySkill':False}
