#!/usr/bin/env python3
"""Explicit opt-in setup of one installation-local virtual environment."""
import argparse
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import portable_config as config
from storage_checks import error_payload, plain_path, probe_directory

DEPENDENCIES = ('Pillow==12.3.0', 'python-docx==1.2.0')


def environment_python():
    root = config.SKILL/'runtime'/'venv'
    return root/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')


def subprocess_environment(create=False):
    """Environment only for our child processes; never changes os.environ/global HOME.

    Version/dependency checks do not create directories or use temporary files.
    Explicit setup creates these runtime-only directories before venv/ensurepip/pip.
    They are local installation artifacts and must never be distributed in a Skill.
    """
    runtime = plain_path(config.SKILL/'runtime')
    cache = runtime/'pip-cache'
    temporary = runtime/'setup-temp'
    if create:
        for folder in (cache, temporary):
            plain_path(folder).mkdir(parents=True, exist_ok=True)
    clean={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME')}
    return {**clean, 'PIP_CACHE_DIR':str(cache), 'TMPDIR':str(temporary),
            'TEMP':str(temporary), 'TMP':str(temporary), 'PYTHONDONTWRITEBYTECODE':'1'}


def dependency_check(python):
    script = """import importlib.metadata as m, importlib.util as u,json,re
missing=[]
for name,module,minimum in [('Pillow','PIL',(10,1)),('python-docx','docx',(1,1))]:
 try:
  version=tuple(int(v) for v in re.findall(r'\\d+',m.version(name))[:2]);ok=u.find_spec(module) is not None and version>=minimum
 except m.PackageNotFoundError:ok=False
 if not ok:missing.append({'Pillow':'Pillow==12.3.0','python-docx':'python-docx==1.2.0'}[name])
print(json.dumps({'missing':missing}))
"""
    result = subprocess.run([str(python),'-c',script],capture_output=True,text=True,timeout=30,env=subprocess_environment())
    if result.returncode: raise ValueError('所选 Python 无法检查依赖：'+result.stderr[-1200:])
    return json.loads(result.stdout)['missing']


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace',help='WorkBuddy 当前项目绝对目录')
    parser.add_argument('--root',help='首次选择档案目录（WorkBuddy 必须在工作区内）')
    parser.add_argument('--reuse-existing',action='store_true')
    parser.add_argument('--python',help='用于创建独立环境的 Python 3.10+ 解释器绝对路径，默认当前解释器')
    parser.add_argument('--install-deps',action='store_true',help='明确同意在本安装独立 venv 中安装所缺依赖；可能联网')
    parser.add_argument('--check',action='store_true',help='只检查本安装 venv，不创建或安装')
    args=parser.parse_args()
    selected=Path(args.python).expanduser().resolve() if args.python else Path(sys.executable).resolve()
    if not selected.is_file():raise ValueError('所选 Python 解释器不存在')
    version=subprocess.run([str(selected),'-c','import sys; print(".".join(map(str,sys.version_info[:3])))'],capture_output=True,text=True,timeout=15,env=subprocess_environment())
    if version.returncode or tuple(int(v) for v in version.stdout.strip().split('.')[:2])<(3,10):
        raise ValueError('所选解释器需要 Python 3.10 或以上')
    python=environment_python();runtime=python.parents[2];venv=python.parents[1]
    if args.check:
        value={'python':str(python),'exists':python.is_file(),'writes':False}
        if python.is_file():value['missing']=dependency_check(python)
        print(json.dumps(value,ensure_ascii=False));return
    if not args.install_deps:
        print(json.dumps({'ready':python.is_file(),'next':[str(selected),str(Path(__file__).resolve()),*(['--workspace',args.workspace] if args.workspace else []),'--install-deps'],'message':'这是独立环境准备命令。检查后加 --install-deps 明确安装依赖；不会改系统 Python。'},ensure_ascii=False));return
    config.select_root(args.root,workspace=args.workspace,reuse_existing=args.reuse_existing)
    probe_directory(runtime)
    child_env=subprocess_environment(create=True)
    owner=runtime/'venv-owner.json'
    if venv.exists() and not owner.exists():raise ValueError('venv 目录已有未知环境，未修改；请换一个全新 Skill 安装目录')
    if owner.exists():
        metadata=json.loads(owner.read_text(encoding='utf-8'))
        if metadata.get('owner')!='student-learning-runtime-v1' or metadata.get('installId')!=config.INSTALL_ID:
            raise ValueError('此环境不属于本安装，未修改')
    else:
        config.atomic(owner,json.dumps({'owner':'student-learning-runtime-v1','installId':config.INSTALL_ID,'basePython':str(selected)}).encode())
    if not python.is_file():
        result=subprocess.run([str(selected),'-m','venv',str(venv)],capture_output=True,text=True,timeout=180,env=child_env)
        if result.returncode:raise ValueError('独立环境创建失败，请确认该 Python 支持 venv；未改系统环境。详情：'+result.stderr[-1500:])
    missing=dependency_check(python)
    installed=bool(missing)
    if missing:
        result=subprocess.run([str(python),'-m','pip','install',*missing],capture_output=True,text=True,timeout=600,env=child_env)
        if result.returncode:raise ValueError('独立环境依赖安装失败。请检查网络或包源，解决后手动重试本 setup 命令；启动不会反复安装。详情：'+result.stderr[-1500:])
        missing=dependency_check(python)
        if missing:raise ValueError('安装后仍缺依赖：'+', '.join(missing))
    print(json.dumps({'ready':True,'python':str(python),'root':config.read_config()['root'],'next':[str(python),str(config.SKILL/'scripts/portable.py'),'serve','--open'],'installed':installed},ensure_ascii=False))


if __name__=='__main__':
    try:main()
    except (ValueError,OSError,subprocess.TimeoutExpired) as error:
        print(json.dumps(error_payload(error),ensure_ascii=False));sys.exit(1)
