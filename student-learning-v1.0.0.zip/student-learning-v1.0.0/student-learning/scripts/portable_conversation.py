"""Bounded conversation handoff. Local receipts permit save-only recovery.

No model API or subprocess is called here. The active host views exported images;
all model results remain unconfirmed. Jobs and raw responses live in the archive.
"""
from __future__ import annotations
import copy
import hashlib
import json
import re
import shutil
import uuid
from pathlib import Path
import study
import pc_store as s
import portable_config as config
import recognition_checkpoint as checkpoint
import vision_guard as vision
from recognition_contract import build_prompt, expand_result, _context, PROTOCOL
from recognition_recovery import normalize_result


def _write(path, value):
    vision.write(Path(path), value)


def _group(root, db, gid):
    rec = s.meta(db, 'pc_recognition', {'groups': [], 'pages': []})
    group = next((g for g in rec['groups'] if g['id'] == gid), None)
    s.require(group and group.get('pageIds'), '识别分组不存在或为空')
    pages = {p['id']: p for p in rec['pages']}
    return group, [s.source_path(root, pages[pid]['url']) for pid in group['pageIds']]


def _identity(root, db, group, mode):
    if mode == 'report':
        from report_recognition import context
        return context(root, db, group)
    return checkpoint.context(root, db, group)


def _current(root, db, job):
    group, files = _group(root, db, job['groupId'])
    s.require(_identity(root, db, group, job['mode'])['fingerprint'] == job['identity']['fingerprint'],
              '原图或分组资料已变更，旧结果不能写入；请重新导出当前资料')
    if job['mode'] == 'original':
        s.require(not group.get('recognized'), '本组已有识别结果，不能覆盖人工记录')
    else:
        key = 'reportTask' if job['mode'] == 'report' else 'supplementTask'
        task = group.get(key)
        s.require(group.get('recognized') and task and task['id'] == job['taskId']
                  and task['status'] != 'completed', '请求已更换或已完成，旧结果不会覆盖人工记录')
    s.require(not group.get('requested') and group.get('runStatus') not in ('queued', 'running'),
              '后台正在处理此分组，请等待结束后重试')
    return group, files


def _job_path(root, jid):
    s.require(isinstance(jid, str) and re.fullmatch('[a-f0-9]{32}', jid), '对话任务编号无效')
    return Path(root) / 'drafts' / ('conversation-' + jid) / 'job.json'


def _save(root, job):
    _write(_job_path(root, job['id']), job)


def _load(root, manifest_path):
    manifest = study.read_json(manifest_path)
    job = study.read_json(_job_path(root, manifest.get('jobId')))
    stage = job['stages'].get(manifest.get('stageId'))
    s.require(stage and stage['manifest'] == manifest, '任务清单已变更或不属于本档案')
    return job, stage


def _images(manifest_path, manifest):
    from portable import verify_export_images
    verify_export_images(manifest_path, manifest)


def _stage(root, job, sid, prompt, images, mapping=None):
    """Persist authoritative stage before exporting; a retry reuses its same receipt."""
    if sid in job['stages']:
        return job['stages'][sid]
    folder = Path(job['out']) / sid
    s.require(not folder.exists(), '阶段输出目录已存在，请勿覆盖：' + str(folder))
    records = [{'page': i, 'sha256': hashlib.sha256(Path(p).read_bytes()).hexdigest()}
               for i, p in enumerate(images, 1)]
    signature = checkpoint.digest({'input': job['identity'], 'mode': job['mode'], 'stage': sid,
                                   'prompt': prompt, 'images': records, 'mapping': mapping})
    session = vision.create(root, job['groupId'], signature, records, retry=job.get('retryVision', False))
    folder.mkdir(parents=True)
    (folder / 'images').mkdir()
    names = []
    for index, source in enumerate(images, 1):
        name = 'images/' + str(index).zfill(3) + Path(source).suffix.lower()
        shutil.copyfile(source, folder / name)
        names.append(name)
    manifest = {k: session[k] for k in ('version', 'sessionId', 'root', 'groupId', 'fingerprint', 'images', 'expiresAt')}
    manifest.update(jobId=job['id'], stageId=sid, mode=job['mode'], imageFiles=names,
                    protocol='student-conversation-v3')
    _write(folder / 'manifest.json', manifest)
    (folder / 'prompt.txt').write_text(prompt, encoding='utf-8')
    from release_runtime import stage_record
    stage_record(folder,prompt,images)
    stage = {'manifest': manifest, 'folder': str(folder), 'mapping': mapping, 'status': 'awaiting_read'}
    job['stages'][sid] = stage
    _save(root, job)
    return stage


def _handoff(stage):
    folder = Path(stage['folder'])
    return {'manifest': str(folder / 'manifest.json'), 'prompt': str(folder / 'prompt.txt'),
            'images': [str(folder / p) for p in stage['manifest']['imageFiles']],
            'stage': stage['manifest']['stageId'], 'status': stage['status']}


def _pending(job):
    return [_handoff(stage) for stage in job['stages'].values() if stage['status'] != 'completed']


def export(root, db, args):
    from storage_checks import plain_path
    group, files = _group(root, db, args.group_id)
    mode = args.mode
    s.require(not group.get('requested') and group.get('runStatus') not in ('queued', 'running'), '后台识别正在运行')
    if mode == 'original':
        s.require(not group.get('recognized'), '已有识别结果，不能覆盖人工记录；整卷报告请用 --mode report --consent')
    else:
        s.require(group.get('recognized') and group.get('kind') != 'practice', '报告和圈选补题需要已识别原卷')
    if mode == 'report':
        s.require(args.consent is True, '整卷识别将增加 Token 消耗，须先取得用户明确同意，再加 --consent')
    destination = plain_path(args.out)
    if config.host() == 'workbuddy':
        workspace = Path(config.read_config()['workspace']).resolve()
        s.require(workspace in destination.parents, 'WorkBuddy 识别任务目录必须在当前工作区内')
    s.require(not destination.exists(), '导出目录已存在，请选择新目录')
    # Fail before queueing if the previous image-access failure has not been addressed.
    s.require(args.retry_vision or not vision.failure_path(root, group['id']).exists(), vision.BLOCKED_MESSAGE)
    jid = uuid.uuid4().hex
    job = {'version': 3, 'id': jid, 'groupId': group['id'], 'mode': mode,
           'identity': _identity(root, db, group, mode), 'out': str(destination),
           'retryVision': args.retry_vision, 'stages': {}, 'status': 'awaiting_read'}
    work = _job_path(root, jid).parent
    work.mkdir(parents=True)
    if mode == 'report':
        import report_recognition as report
        task = report.queue_task(root, db, {'groupId': group['id'], 'requestId': str(uuid.uuid4()), 'consent': True}, s.revision(db))
        if task['status'] == 'completed':
            return {'status': 'completed', 'cached': True, 'message': '整卷报告已有缓存，直接回网页查看。'}
        job.update(taskId=task['id'], consent=True)
        report.stamp(root, group['id'], task['id'], 'awaiting_conversation', error='等待当前对话识别；请按导出任务实际看图后提交。')
        prompt, sid, images = build_prompt(root, db, group, files), 'report', files
    elif mode == 'supplement':
        import supplement_recognition as supplement
        old = group.get('supplementTask') or {}
        pid = args.page_id or old.get('pageId')
        box = json.loads(args.box) if args.box else old.get('box')
        rid=old['id'] if old.get('status')=='awaiting_conversation' and old.get('pageId')==pid and old.get('box')==box else str(uuid.uuid4())
        task = supplement.queue_task(root, db, {'groupId': group['id'], 'requestId': rid, 'pageId': pid, 'box': box}, s.revision(db))
        job['taskId'] = task['id']
        job['task'] = task
        supplement.stamp(root, group['id'], task['id'], 'awaiting_conversation', error='等待当前对话识别圈选区域；原有题目和人工结果保留。')
        source = files[group['pageIds'].index(pid)]
        crop = work / 'selected-region.png'
        supplement.crop_region(source, task['box'], crop)
        prompt = supplement.supplement_prompt(root, db, {**group, 'pageIds': [pid]}, source)
        sid, images = 'supplement', [crop]
    elif group.get('kind') == 'practice':
        prompt, sid, images = build_prompt(root, db, group, files), 'practice', files
    else:
        from selective_recognition import detection_prompt
        prompt, sid, images = detection_prompt(group, len(files)), 'detect', files
    _save(root, job)
    try:
        stage = _stage(root, job, sid, prompt, images)
    except Exception:
        # Tasks remain terminal, never displayed as an unbounded background operation.
        raise
    return {**_handoff(stage), 'next': '立即实际查看第一张图；不支持读图就 conversation-block 并停止。每阶段20分钟。逐图记录 vision 后执行 conversation-vision；再用 conversation-submit 提交。定位阶段禁止解题或抄写整卷。所有结果仍待人工复核。'}


def _fail(root, job, error, available=False):
    message = str(error)[:500]
    if available:
        message += ' 已保存当前响应；请使用 conversation-retry 本地重试，不要重新看图。'
    if job['mode'] == 'original':
        from codex_bridge import Runner
        runner = Runner(root)
        try:
            runner.stamp(job['groupId'], 'failed', message, recovery={'available': available})
        finally:
            runner.close()
    elif job['mode'] == 'report':
        from report_recognition import stamp
        stamp(root, job['groupId'], job['taskId'], 'failed', error=message, recovery={'available': available})
    else:
        from supplement_recognition import stamp
        stamp(root, job['groupId'], job['taskId'], 'failed', error=message)


def _activate(root, db, job):
    db.execute('BEGIN IMMEDIATE')
    try:
        _current(root, db, job)
        rec = s.meta(db, 'pc_recognition', {'groups': []})
        group = next(g for g in rec['groups'] if g['id'] == job['groupId'])
        if job['mode'] == 'original':
            group.update(requested=True, requestId='conversation-' + job['id'], runStatus='running')
        else:
            key = 'reportTask' if job['mode'] == 'report' else 'supplementTask'
            group[key]['status'] = 'running'
        s.put_meta(db, 'pc_recognition', rec)
        db.commit()
    except Exception:
        db.rollback()
        raise


def _diagrams(root, result):
    for q in result['questions']:
        if q.get('diagram'):
            from pc_diagram import render_diagram
            asset = render_diagram(root, q.pop('diagram'))
            q['content']['blocks'].append({'type': 'image', 'asset': asset})
            q['diagramReviewRequired'] = True


def _commit(root, db, job, compact, detection=None):
    group, files = _current(root, db, job)
    if job['mode'] == 'supplement':
        pid = job['task']['pageId']
        source = files[group['pageIds'].index(pid)]
        s.require(isinstance(compact.get('questions'), list) and len(compact['questions']) == 1, '一次圈选只能识别一道题')
        compact = copy.deepcopy(compact)
        compact['questions'][0].pop('box', None)
        result = expand_result(root, db, {**group, 'pageIds': [pid]}, [source], compact)
    elif compact['questions']:
        result = expand_result(root, db, group, files, compact)
    else:
        s.require(detection is not None, '需要逐题识别结果')
        result = {'schema_version': 1, 'paper': {**compact['paper'], **_context(root, db, group, files), 'grade': group.get('grade')}, 'questions': []}
    if detection is not None:
        result['paper']['recognition_scope'] = 'mistakes'
    _diagrams(root, result)
    _activate(root, db, job)
    if job['mode'] == 'report':
        from report_recognition import save_report
        save_report(root, db, group['id'], job['taskId'], job['identity'], result)
    elif job['mode'] == 'supplement':
        from supplement_recognition import save_question
        save_question(root, db, group['id'], job['taskId'], result)
    else:
        s.put_results(root, db, group['id'], result, expected_request_id='conversation-' + job['id'])
        from codex_bridge import Runner
        runner = Runner(root)
        notes = ['本次只定位批改错题并识别候选，未验算整卷；题框、材料及正误待人工复核。'] if detection else []
        if detection and detection['status'] == 'unmarked':
            notes.append('未发现批改痕迹，不能判断全对。须先询问用户并明确同意后，使用 --mode report --consent 进行整卷验算。')
        try:
            runner.stamp(group['id'], 'completed', request_id='conversation-' + job['id'], recovery={'available': False}, notes=notes)
        finally:
            runner.close()
        if detection:
            db.execute('BEGIN IMMEDIATE')
            try:
                rec = s.meta(db, 'pc_recognition', {'groups': []})
                current = next(g for g in rec['groups'] if g['id'] == group['id'])
                current.update(recognitionScope='mistakes', detection={'status': detection['status'], 'candidateCount': len(detection['candidates']), 'locationIssues':detection.get('rejected_candidates',[]), 'scannedPages': compact['paper']['scanned_pages']})
                s.put_meta(db, 'pc_recognition', rec)
                db.commit()
            except Exception:
                db.rollback()
                raise
    with db:
        rec=s.meta(db,'pc_recognition',{'groups':[]})
        current=next(g for g in rec['groups'] if g['id']==group['id'])
        current.pop('conversationHandoff',None)
        s.put_meta(db,'pc_recognition',rec)
    job['status'] = 'completed'
    _save(root, job)
    return {'groupId': group['id'], 'status': '待人工复核', 'mode': job['mode'], 'questions': len(result['questions']), 'autoConfirmed': False,
            'next': '请先询问用户是否同意整卷验算；确认前不再识别。' if detection and detection['status'] == 'unmarked' else '回网页核对识别结果。'}


def _process(root, db, job, stage, raw):
    group, files = _current(root, db, job)
    data, repairs = normalize_result(raw)
    if data.get('status') in ('image_blocked', 'blocked'):
        raise ValueError(vision.BLOCKED_MESSAGE)
    s.require(vision.digest(vision.validate_report(data.get('vision'), len(stage['manifest']['images']))) ==
              vision.digest(stage['receipt']['vision']), '保存内容的 vision 与已记录读图报告不一致')
    sid = stage['manifest']['stageId']
    if sid == 'detect':
        from selective_recognition import _detection, _crops, detail_prompt, BATCH_SIZE
        detected, reported, repairs = _detection(raw, len(files))
        if any(key.startswith('detail-') for key in job['stages']):
            s.require(job.get('detection') == detected, '裁图阶段已建立，不能改写原定位；请继续已有候选任务')
        job['detection'] = detected
        _save(root, job)
        if detected['candidates']:
            base = build_prompt(root, db, group, files)
            for offset in range(0, len(detected['candidates']), BATCH_SIZE):
                name = 'detail-' + str(offset // BATCH_SIZE + 1).zfill(3)
                if name in job['stages']:
                    continue
                work = _job_path(root, job['id']).parent / name
                work.mkdir(exist_ok=True)
                images, mapping = _crops(work, detected['candidates'][offset:offset + BATCH_SIZE], files)
                _stage(root, job, name, detail_prompt(base, mapping, len(images)), images, mapping)
            stage['status'] = 'completed'
            _save(root, job)
            return {'status': 'needs_candidate_details', 'candidateCount': len(detected['candidates']), 'tasks': _pending(job),
                    'next': '只查看各详情任务裁图，逐阶段记录 vision 并提交；不要重读原卷。'}
        stage['status'] = 'completed'
    elif sid.startswith('detail-'):
        from selective_recognition import _remap
        questions, repairs = _remap(raw, stage['mapping'], len(stage['manifest']['images']))
        preview={'protocol':PROTOCOL,'vision':job['detection']['vision'],'paper':{'assessment_mode':'teacher_marks','coverage':'partial','expected_question_count':None,'scanned_pages':list(range(1,len(files)+1))},'questions':questions}
        expand_result(root,db,group,files,preview)
        stage.update(status='completed', questions=questions)
        _save(root, job)
        if _pending(job):
            return {'status': 'awaiting_details', 'tasks': _pending(job), 'next': '本阶段已保存，继续未完成的裁图阶段。'}
    else:
        return _commit(root, db, job, data)
    detected = job['detection']
    compact = {'protocol': PROTOCOL, 'vision': detected['vision'],
               'paper': {'assessment_mode': 'unmarked' if detected['status'] == 'unmarked' else 'teacher_marks',
                         'coverage': 'partial', 'expected_question_count': None, 'scanned_pages': list(range(1, len(files) + 1))},
               'questions': [q for key, item in job['stages'].items() if key.startswith('detail-') for q in item.get('questions', [])]}
    return _commit(root, db, job, compact, detected)


def dispatch(root, db, args):
    if args.cmd == 'conversation-export':
        return export(root, db, args)
    job, stage = _load(root, args.manifest)
    if job['status'] == 'completed':
        return {'status': 'already_saved', 'groupId': job['groupId'], 'message': '此任务已保存；原有人工记录保持不变。'}
    _current(root, db, job)
    manifest = stage['manifest']
    if args.cmd == 'conversation-block':
        vision.block(root, manifest, args.reason)
        _fail(root, job, vision.BLOCKED_MESSAGE)
        return {'status': 'image_blocked', 'questionsWritten': 0, 'message': vision.BLOCKED_MESSAGE}
    if args.cmd == 'conversation-vision':
        _images(args.manifest, manifest)
        try:
            vision.report(root, manifest, study.read_json(args.report), len(manifest['images']))
        except ValueError as error:
            _fail(root, job, error)
            raise
        return {'status': 'reported_readable', 'trust': '对话自述，不是独立视觉证明', 'next': '继续本阶段识别并提交含相同 vision 的结果。'}
    if args.cmd == 'conversation-renew':
        s.require(args.retry_vision, '请先确认当前会话确实能读图，再用 --retry-vision 续开未完成阶段；不要自动循环重试')
        s.require(not stage.get('rawFile'), '本阶段已有响应，请 conversation-retry 本地保存，不需要重新看图')
        _images(args.manifest, manifest)
        session = vision.create(root, job['groupId'], manifest['fingerprint'], manifest['images'], retry=True)
        for key in ('version', 'sessionId', 'root', 'groupId', 'fingerprint', 'images', 'expiresAt'):
            manifest[key] = session[key]
        _write(Path(stage['folder']) / 'manifest.json', manifest)
        _save(root, job)
        return {**_handoff(stage), 'next': '只处理本阶段已导出的图片；20分钟内记录vision并提交，不重读已完成阶段。'}
    retry = args.cmd == 'conversation-retry'
    if retry:
        s.require(stage.get('rawFile') and stage.get('receipt'), '本阶段没有已保存的响应，请先提交当前识别结果')
        raw_path = Path(stage['rawFile'])
        s.require(hashlib.sha256(raw_path.read_bytes()).hexdigest() == stage['rawHash'], '已保存响应校验失败，请恢复原响应')
        raw = Path(args.result).read_text(encoding='utf-8') if args.result else raw_path.read_text(encoding='utf-8')
        if args.result:
            repaired=raw_path.with_name(raw_path.stem+'-repair-'+uuid.uuid4().hex+'.txt')
            repaired.write_text(raw,encoding='utf-8')
            stage.setdefault('repairs',[]).append({'file':str(repaired),'sha256':hashlib.sha256(raw.encode()).hexdigest(),'origin':'conversation_local_revision','at':study.now()})
            _save(root,job)
    else:
        s.require(not stage.get('rawFile'), '本阶段响应已保存，请使用 conversation-retry；无需重新看图')
        _images(args.manifest, manifest)
        session_path, session = vision.load(root, manifest)
        s.require(session.get('state') == 'reported_readable', '先实际看图并执行 conversation-vision；看不到就立即 conversation-block')
        raw = Path(args.result).read_text(encoding='utf-8')
        s.require(len(raw.encode('utf-8')) <= 15_000_000, '识别结果过大')
        # Save before parsing. A malformed complete output can be repaired locally.
        raw_path = _job_path(root, job['id']).parent / (manifest['stageId'] + '-response.txt')
        raw_path.write_text(raw, encoding='utf-8')
        stage.update(rawFile=str(raw_path), rawHash=hashlib.sha256(raw_path.read_bytes()).hexdigest(), receipt=session)
        _save(root, job)
    try:
        result = _process(root, db, job, stage, raw)
        if not retry:
            vision.consume_validated((session_path, session))
        return result
    except Exception as error:
        blocked = str(error) == vision.BLOCKED_MESSAGE or vision.blocked_error(str(error))
        if blocked:
            # Blocked outputs never become a reusable response checkpoint.
            stage.pop('rawFile', None)
            stage.pop('receipt', None)
            record = dict(stage['manifest'], state='blocked', reason=str(error))
            _write(vision.failure_path(root, job['groupId']), record)
        _save(root, job)
        _fail(root, job, error, available=not blocked)
        raise
