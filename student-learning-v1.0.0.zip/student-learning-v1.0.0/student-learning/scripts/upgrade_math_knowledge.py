#!/usr/bin/env python3
"""Conservative KB 0.6 upgrade; preview is read-only and is the default.

python -B upgrade_math_knowledge.py --root /clone --plan question_mapping.json
python -B upgrade_math_knowledge.py --root /clone --plan question_mapping.json \
    --apply --revision PREVIEW_REVISION --backup-dir /outside-archive/backups

Only explicit knowledge fields are transformed. Unresolved references remain
readable historical references; pending migration markers never change grading.
No init_kb call, installed-skill writes, schema changes, or knowledge deletion.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import math_unified
import pc_store
import study

SKILL = Path(__file__).resolve().parents[1]
TABLES = ('questions', 'papers', 'reviews', 'mastery', 'meta')
META_KEYS = {'pc_drafts', 'pc_recognition', 'pc_practice', 'pc_reports'}
LIST_KEYS = {'knowledgeIds', 'knowledge_ids', 'knowledge_point_ids',
             'knowledgePointIds', 'verified_knowledge_ids', 'verifiedKnowledgeIds'}
SCALAR_KEYS = {'knowledge_point_id', 'knowledgePointId', 'knowledgeId', 'kp_id'}
NAME_KEYS = {'knowledgePoints', 'pc_knowledge_points', 'knowledge_names',
             'knowledge_point_names', 'knowledgeNames'}
SCALAR_NAMES = {'knowledge_name', 'knowledgeName', 'knowledgePoint', 'knowledge_point_name'}
# Knowledge-package examples and evidence bodies are not student tag containers.
OPAQUE = {'examples', 'example', 'rules', 'core_concepts_rules', 'shared_card_context',
          'text', 'fullText', 'content', 'sharedContext', 'student_answer', 'studentAnswer',
          'corrected_answer', 'expected_answer', 'answer', 'explanation', 'analysis',
          'evidence', 'observed_error', 'sources', 'assets', 'mathKnowledgeMigration'}
MATH_ID = re.compile(r'^(?:(?:HS)?MATH-K\d+(?:-S\d+)?|M4A-K\d+)$')
ACTIVE = {'queued', 'running', 'starting', 'processing', 'in_progress'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def digest(value):
    return hashlib.sha256(dumps(value).encode()).hexdigest()


def unique(values):
    return list(dict.fromkeys(values))


def open_db(path, write=False):
    db = sqlite3.connect(Path(path).resolve().as_uri() + ('?mode=rw' if write else '?mode=ro'),
                         uri=True, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    if not write:
        db.execute('PRAGMA query_only=ON')
    return db


def active_recognition(value, path='pc_recognition'):
    found = []
    if isinstance(value, dict):
        if value.get('requested') or any(isinstance(value.get(k), str) and value[k] in ACTIVE
                                        for k in ('runStatus', 'status', 'state')):
            found.append(path)
        for key, item in value.items():
            if key not in OPAQUE:
                found.extend(active_recognition(item, path + '/' + key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            found.extend(active_recognition(item, path + '/' + str(index)))
    return found


class Upgrade:
    def __init__(self, db, plan, skill):
        require(isinstance(plan, dict), '映射计划必须为 JSON 对象')
        require(not plan.get('defaultMapping'), '不接受全局 defaultMapping；分类必须逐题 override')
        self.plan = plan
        self.holds = {(r.get('question_id'), r.get('old_id')): r
                      for r in plan.get('unresolved', []) if isinstance(r, dict)}
        self.overrides = plan.get('questionOverrides', {})
        require(isinstance(self.overrides, dict), 'questionOverrides 必须为对象')
        self.points, self.bindings, _, self.manifest = math_unified.load(str(skill))
        self.newrecords = {}
        for stage in ('小初', '高中'):
            records, version = math_unified.records_for_stage(str(skill), stage)
            for raw in records:
                kid = raw['knowledge_point_id']
                self.newrecords[kid] = dict(id=kid, subject='math', name=raw['name'],
                                           version=version, payload=study.dumps(raw))
        require(set(self.newrecords) == set(self.points), '新知识行与 leaf 集不一致')
        self.records = {r['id']: dict(r) for r in db.execute('SELECT * FROM knowledge')}
        for kid in self.newrecords:
            require(kid not in self.records or self.records[kid]['subject'] == 'math',
                    '数学 ID 与其他学科冲突：' + kid)
        self.names = {}
        for kid, row in self.records.items():
            if row['subject'] == 'math':
                self.names.setdefault(row['name'], []).append(kid)
        for kid, row in self.newrecords.items():
            if kid not in self.names.get(row['name'], []):
                self.names.setdefault(row['name'], []).append(kid)
        for qid, mapping in self.overrides.items():
            require(isinstance(qid, str) and isinstance(mapping, dict), '逐题映射格式无效')
            for old, targets in mapping.items():
                require(self.is_math(old), 'override 只能修改数学 ID：' + str(old))
                require(isinstance(targets, list) and targets and all(isinstance(t, str) and t in self.points
                        for t in targets), 'override 必须指向活动 leaf：' + str(old))
        self.rows = {table: [dict(r) for r in db.execute(f'SELECT * FROM {table}')]
                     for table in TABLES}
        self.aliases, self.locals = {}, {}
        self.qsubjects = {}
        self.paper_aliases = {}
        for row in self.rows['papers']:
            p = json.loads(row['payload'])
            for key in ('id', 'pc_original_paper_id'):
                if p.get(key):
                    self.paper_aliases[p[key]] = row['id']
        for row in self.rows['questions']:
            q = json.loads(row['payload'])
            self.aliases[row['id']] = row['id']
            self.qsubjects[row['id']] = row['subject']
            if q.get('pc_scan_id'):
                self.add_alias(q['pc_scan_id'], row['id'])
            self.locals[(row['paper_id'], row['local_id'])] = row['id']
        rec = next((json.loads(r['value']) for r in self.rows['meta'] if r['key'] == 'pc_recognition'), {})
        self.active = active_recognition(rec)
        for group in rec.get('groups', []):
            for q in group.get('questions', []):
                sid, cid = q.get('id'), q.get('canonicalId') or q.get('savedQuestionId')
                if sid and cid:
                    self.add_alias(sid, cid)
                    self.aliases.setdefault(cid, cid)
        # Draft-only questions have the same deterministic scan ID as their projection.
        drafts = next((json.loads(r['value']) for r in self.rows['meta'] if r['key'] == 'pc_drafts'), {})
        if isinstance(drafts, dict):
            for gid, draft in drafts.items():
                if not isinstance(draft, dict):
                    continue
                pid = draft.get('paper', {}).get('id', '')
                for q in draft.get('questions', []):
                    local = q.get('local_id')
                    if local:
                        sid = q.get('pc_scan_id') or gid + '-q-' + hashlib.sha256(local.encode()).hexdigest()[:16]
                        if sid in self.aliases:
                            self.locals.setdefault((pid, local), self.aliases[sid])
        self.audit, self.unresolved = [], []
        self.missing = set()

    def add_alias(self, alias, canonical):
        require(alias not in self.aliases or self.aliases[alias] == canonical,
                '题目身份映射冲突：' + alias)
        self.aliases[alias] = canonical

    def is_math(self, kid):
        if not isinstance(kid, str):
            return False
        if kid in self.records:
            return self.records[kid]['subject'] == 'math'
        return kid in self.points or kid in self.bindings or bool(MATH_ID.fullmatch(kid))

    def context(self, value, context, paper):
        if isinstance(value.get('paper'), dict):
            paper = value['paper'].get('id', paper)
        paper = value.get('paper_id', value.get('paperId', paper))
        for key in ('canonicalId', 'savedQuestionId', 'question_id', 'questionId',
                    'source_question_id', 'sourceQuestionId', 'pc_scan_id', 'id'):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate in self.aliases:
                return self.aliases[candidate], paper
            if key in ('canonicalId', 'question_id', 'questionId') and isinstance(candidate, str):
                return candidate, paper
        local = value.get('local_id')
        if local is None and 'id' in value:
            local = value['id']
        return self.locals.get((self.paper_aliases.get(paper, paper), local),
                               self.locals.get((paper, local), context)), paper

    def rationale(self, context, kid):
        r = self.plan.get('rationale', {})
        if isinstance(r, dict):
            r = r.get(context, r.get(kid, r))
            if isinstance(r, dict):
                r = r.get(kid, r)
        return r or '逐题已审 override；未提供额外文字依据'

    def resolve(self, kid, context, path, scalar=False):
        if not self.is_math(kid):
            return [kid], None
        if kid not in self.records and kid not in self.points:
            self.missing.add(kid)
        binding = self.bindings.get(kid, {})
        hold = self.holds.get((context, kid))
        if hold:
            issue = dict(path=path, questionId=context or None, oldId=kid,
                         candidateIds=[], reason=hold.get('reason', '逐题审查明确保留待核'),
                         source='plan.unresolved')
            self.unresolved.append(issue)
            return [kid], issue
        if kid in self.overrides.get(context, {}):
            targets = unique(self.overrides[context][kid])
            source, rationale = 'questionOverrides', self.rationale(context, kid)
        elif binding.get('status') == 'resolved':
            targets = [binding['assessment_id']]
            require(all(t in self.points for t in targets), 'bindings 指向非 leaf：' + kid)
            source, rationale = 'binding_index', binding.get('reason', 'resolved 直接绑定')
        elif kid in self.points:
            targets, source, rationale = [kid], 'assessment_points', '已是活动末级知识点'
        else:
            reason = 'requires_selection：缺少逐题 override' if binding.get('status') == 'requires_selection' else '无已审映射，保留旧历史引用'
            issue = dict(path=path, questionId=context or None, oldId=kid,
                         candidateIds=binding.get('candidate_ids', []), reason=reason)
            self.unresolved.append(issue)
            return [kid], issue
        if scalar and len(targets) != 1:
            issue = dict(path=path, questionId=context or None, oldId=kid, candidateIds=targets,
                         reason='标量归因/掌握记录无法唯一选择；保留原引用，不拆分或复制',
                         source=source, rationale=rationale)
            self.unresolved.append(issue)
            return [kid], issue
        self.audit.append(dict(path=path, questionId=context or None, oldId=kid, newIds=targets,
                               source=source, rationale=rationale))
        return targets, None

    def transform(self, value, context='', paper='', path='', subject=''):
        if isinstance(value, list):
            return [self.transform(v, context, paper, f'{path}/{i}', subject) for i, v in enumerate(value)]
        if not isinstance(value, dict):
            return value
        subject = value.get('subject', subject)
        if isinstance(value.get('paper'), dict):
            subject = value['paper'].get('subject', subject)
        if subject and subject not in ('math', '数学'):
            return copy.deepcopy(value)
        context, paper = self.context(value, context, paper)
        if self.qsubjects.get(context, 'math') != 'math':
            return copy.deepcopy(value)
        out = copy.deepcopy(value)
        pending, mapped_fields = [], {}
        for key in sorted(LIST_KEYS | SCALAR_KEYS):
            if key not in value:
                continue
            original = value[key]
            ids = original if key in LIST_KEYS and isinstance(original, list) else [original]
            if not any(self.is_math(k) for k in ids):
                continue
            require(all(isinstance(k, str) for k in ids), '知识 ID 类型无效：' + path + '/' + key)
            start = len(self.audit)
            targets = []
            for kid in ids:
                result, issue = self.resolve(kid, context, path + '/' + key, key in SCALAR_KEYS)
                targets.extend(result)
                if issue:
                    pending.append(issue)
            targets = unique(targets)
            if key == 'knowledgeIds' and len(targets) > 3 and targets != ids:
                issue = dict(path=path + '/' + key, questionId=context or None, oldIds=ids,
                             candidateIds=targets, reason='映射超过3个正式标签；保留原列表待核')
                self.unresolved.append(issue)
                pending.append(issue)
                del self.audit[start:]
                targets = ids
            out[key] = targets if key in LIST_KEYS else targets[0]
            mapped_fields[key] = targets
        # Refresh names alongside their IDs, including same-ID version upgrades.
        list_ids = next((mapped_fields[k] for k in ('knowledgeIds', 'knowledge_point_ids',
                        'knowledgePointIds', 'knowledge_ids') if k in mapped_fields), None)
        scalar_ids = next((mapped_fields[k] for k in sorted(SCALAR_KEYS) if k in mapped_fields), None)
        for key in sorted(NAME_KEYS):
            if key not in value or not isinstance(value[key], list):
                continue
            names = []
            for name in value[key]:
                candidates = self.names.get(name, []) if isinstance(name, str) else []
                explicit = []
                for id_key in LIST_KEYS | SCALAR_KEYS:
                    raw_ids = value.get(id_key, [])
                    explicit.extend(raw_ids if isinstance(raw_ids, list) else [raw_ids])
                linked = [kid for kid in unique(explicit) if kid in candidates]
                if linked:
                    candidates = linked
                # A label already matches a linked current leaf; do not reinterpret
                # it via a same-named retired category on subsequent runs.
                if list_ids and name in [self.name(k) for k in list_ids if k in self.newrecords]:
                    names.append(name)
                    continue
                if len(candidates) == 1:
                    targets, issue = self.resolve(candidates[0], context, path + '/' + key)
                    if issue:
                        pending.append(issue)
                    names.extend(self.name(t) for t in targets)
                else:
                    names.append(name)
                    if len(candidates) > 1:
                        issue = dict(path=path + '/' + key, questionId=context or None,
                                     oldName=name, reason='旧名称对应多个 ID，无法仅凭名称确定')
                        self.unresolved.append(issue)
                        pending.append(issue)
            # If IDs were held for selection, keep their associated labels consistent.
            if list_ids is not None and any(p['path'] == path + '/knowledgeIds' for p in pending):
                names = value[key]
            out[key] = unique(names)
        for key in sorted(SCALAR_NAMES):
            if key in value and scalar_ids and len(scalar_ids) == 1 and scalar_ids[0] in self.newrecords:
                out[key] = self.name(scalar_ids[0])
            elif key in value and list_ids and key == 'knowledgePoint' and list_ids[0] in self.newrecords:
                out[key] = self.name(list_ids[0])
        ids_for_version = scalar_ids or list_ids
        # Never stamp an unresolved historical reference with the new KB version.
        local_issues = [p for p in pending if p['path'].rsplit('/', 1)[-1] in SCALAR_KEYS | LIST_KEYS]
        if ids_for_version and not local_issues and all(k in self.newrecords for k in ids_for_version):
            libraries = {json.loads(self.newrecords[k]['payload'])['knowledge_base_id'] for k in ids_for_version}
            for key in ('knowledge_version', 'knowledgeVersion'):
                if key in out or (scalar_ids and key == 'knowledge_version'):
                    out[key] = self.newrecords[ids_for_version[0]]['version']
            for key in ('kb_version', 'library_version', 'libraryVersion'):
                if key in out or (scalar_ids and key == 'library_version'):
                    out[key] = self.manifest['version']
            if len(libraries) == 1 and ('knowledge_base_id' in out or scalar_ids):
                out['knowledge_base_id'] = next(iter(libraries))
        if pending:
            out['mathKnowledgeMigration'] = {'status': 'pending', 'issues': pending}
        elif 'mathKnowledgeMigration' in out:
            out.pop('mathKnowledgeMigration')
        for key, item in value.items():
            if key not in LIST_KEYS | SCALAR_KEYS | NAME_KEYS | SCALAR_NAMES | OPAQUE and isinstance(item, (dict, list)):
                child_context = self.aliases.get(key, context)
                out[key] = self.transform(item, child_context, paper, path + '/' + key, subject)
        return out

    def name(self, kid):
        return (self.newrecords.get(kid) or self.records.get(kid) or {}).get('name', kid)

    def prepare(self):
        changes = []
        for table, rows in self.rows.items():
            keycol, payload = ('key', 'value') if table == 'meta' else ('id', 'payload')
            for row in rows:
                key = row[keycol]
                if table == 'meta' and key not in META_KEYS:
                    continue
                if row.get('subject', 'math') != 'math':
                    continue
                before = json.loads(row[payload])
                context = row.get('question_id', key if table == 'questions' else '')
                paper = row.get('paper_id', key if table == 'papers' else '')
                start = len(self.audit)
                after = self.transform(before, context, paper, table + '/' + key, row.get('subject', ''))
                extra = {}
                if table == 'mastery' and self.is_math(row['kp_id']):
                    targets, issue = self.resolve(row['kp_id'], self.context(before, '', '')[0], table + '/' + key + '/@kp_id', True)
                    if targets[0] != row['kp_id']:
                        extra['kp_id'] = targets[0]
                    if issue:
                        marker = after.setdefault('mathKnowledgeMigration', {'status': 'pending', 'issues': []})
                        if issue not in marker['issues']:
                            marker['issues'].append(issue)
                if after != before or extra:
                    changes.append(dict(table=table, key=key, keycol=keycol, column=payload,
                                        before=before, after=after, extra=extra,
                                        mappings=copy.deepcopy(self.audit[start:])))
        catalog = []
        for kid, row in self.records.items():
            if row['subject'] == 'math' and kid not in self.newrecords:
                raw = json.loads(row['payload'])
                raw.update(active=False, is_assessable=False, legacy_reference=True)
                if raw != json.loads(row['payload']):
                    catalog.append((row, dict(row, payload=study.dumps(raw))))
        for kid, row in self.newrecords.items():
            old = self.records.get(kid)
            if old is None or any(old[k] != row[k] for k in ('subject', 'name', 'version')) or json.loads(old['payload']) != json.loads(row['payload']):
                catalog.append((old, row))
        # An archive missing its old catalog still gets readable, explicitly unverified stubs.
        for kid in sorted(self.missing - self.records.keys() - self.newrecords.keys()):
            catalog.append((None, dict(id=kid, subject='math', name=kid, version='unknown-legacy',
                payload=study.dumps(dict(knowledge_point_id=kid, name=kid, active=False,
                                        is_assessable=False, legacy_reference=True, missing_legacy_record=True)))))
        return changes, catalog


def asset_inventory(root):
    folder = root / 'assets'
    require(not folder.is_symlink(), '素材根目录为符号链接，无法证明备份边界')
    if not folder.exists():
        return {}
    result = {}
    for path in sorted(folder.rglob('*')):
        require(not path.is_symlink(), '素材含符号链接，拒绝不完整备份：' + str(path))
        if path.is_file():
            with path.open('rb') as f:
                h = hashlib.sha256()
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(block)
            result[str(path.relative_to(folder))] = h.hexdigest()
        else:
            require(path.is_dir(), '素材包含非普通文件：' + str(path))
    return result


def backup_archive(root, directory, revision, copy_assets=False):
    directory = Path(directory).expanduser().resolve()
    require(not directory.is_relative_to(root), '备份目录必须位于学生档案之外')
    directory.mkdir(parents=True, exist_ok=True)
    target = Path(tempfile.mkdtemp(prefix='math-kb-0.6-', dir=directory))
    inventory = asset_inventory(root)
    source = open_db(root / 'study.sqlite3')
    saved = sqlite3.connect(target / 'study.sqlite3')
    saved.row_factory = sqlite3.Row
    try:
        # The caller holds BEGIN IMMEDIATE. Use a second connection: backing up
        # the writer's open transaction on that same connection can deadlock.
        source.backup(saved)
        require(saved.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', '备份完整性校验失败')
        require(pc_store.revision(saved) == revision, '备份 revision 与预览不同')
    finally:
        source.close()
        saved.close()
    if copy_assets and (root / 'assets').exists():
        shutil.copytree(root / 'assets', target / 'assets')
        require(asset_inventory(target) == inventory, '素材副本校验失败')
    require(inventory == asset_inventory(root), '备份期间素材发生变化')
    (target / 'backup_manifest.json').write_text(dumps(dict(revision=revision, assets=inventory,
                                                         source=str(root),
                                                         assetMode='copy' if copy_assets else 'read-only-hash-manifest')), encoding='utf-8')
    return target, inventory


def migrate(root, plan=None, expected_revision=None, apply=False, backup_dir=None,
            skill=SKILL, expected_plan_hash=None, copy_assets=False):
    root = Path(root).expanduser().resolve()
    plan = {} if plan is None else plan
    require(not apply or expected_revision, '应用必须提供只读预览的 --revision')
    require(expected_plan_hash is None or digest(plan) == expected_plan_hash, '映射计划已改变，请重新预览')
    db = open_db(root / 'study.sqlite3', write=apply)
    backup = None
    try:
        # Both planning and writes see one consistent snapshot; no stale pre-lock plan.
        db.execute('BEGIN IMMEDIATE' if apply else 'BEGIN')
        revision = pc_store.revision(db)
        require(expected_revision is None or revision == expected_revision, '档案 revision 已变更，请重新预览')
        upgrade = Upgrade(db, plan, Path(skill))
        require(not apply or not upgrade.active, '识别任务活跃，暂不能迁移：' + ', '.join(upgrade.active))
        changes, catalog = upgrade.prepare()
        counts = {table: sum(c['table'] == table for c in changes) for table in TABLES}
        summary = dict(mode='apply' if apply else 'preview', revision=revision, version=upgrade.manifest['version'],
            planSha256=digest(plan), catalogSha256=upgrade.manifest['files']['assessment_points.json']['sha256'],
            counts=counts, catalogChanges=len(catalog), activeLeafCount=len(upgrade.newrecords),
            recognitionActive=upgrade.active, canApply=not upgrade.active,
            unresolved=upgrade.unresolved, planUnresolved=plan.get('unresolved', []),
            mappings=upgrade.audit, alreadyApplied=not changes and not catalog)
        unresolved_qids = sorted({r['questionId'] for r in upgrade.unresolved if r.get('questionId')})
        canonical_pending = sorted({r['questionId'] for r in upgrade.unresolved
                                    if r.get('questionId') and r['path'].startswith('questions/')})
        summary.update(unresolvedReferenceCount=len(upgrade.unresolved),
                       unresolvedQuestionCount=len(unresolved_qids), unresolvedQuestionIds=unresolved_qids,
                       canonicalQuestionPendingCount=len(canonical_pending),
                       canonicalQuestionPendingIds=canonical_pending,
                       historicalCopyOnlyQuestionCount=len(set(unresolved_qids) - set(canonical_pending)),
                       planUnresolvedQuestionCount=len({r.get('question_id') for r in plan.get('unresolved', [])
                                                        if isinstance(r, dict) and r.get('question_id')}))
        if not apply or summary['alreadyApplied']:
            db.rollback()
            return summary
        directory = backup_dir or root.parent / (root.name + '-math-kb-backups')
        backup, inventory = backup_archive(root, directory, revision, copy_assets)
        require(pc_store.revision(db) == revision, '事务内 revision 改变，迁移中止')
        for before, after in catalog:
            db.execute('INSERT INTO knowledge(id,subject,name,version,payload) VALUES(?,?,?,?,?) '
                       'ON CONFLICT(id) DO UPDATE SET name=excluded.name,version=excluded.version,payload=excluded.payload',
                       tuple(after[k] for k in ('id', 'subject', 'name', 'version', 'payload')))
            study.event(db, after['id'], 'math_kb_0_6_catalog', before, after)
        for change in changes:
            db.execute(f"UPDATE {change['table']} SET {change['column']}=? WHERE {change['keycol']}=?",
                       (study.dumps(change['after']), change['key']))
            for field, value in change['extra'].items():
                db.execute(f"UPDATE {change['table']} SET {field}=? WHERE {change['keycol']}=?", (value, change['key']))
            study.event(db, change['key'], 'math_kb_0_6_references', change['before'],
                        dict(payload=change['after'], extra=change['extra'], mappings=change['mappings'],
                             source='upgrade_math_knowledge', planSha256=summary['planSha256']))
        require(asset_inventory(root) == inventory, '迁移期间素材发生变化，已回滚数据库')
        study.event(db, 'math-knowledge', 'math_kb_0_6_upgrade', {'revision': revision},
                    dict(summary, backup=str(backup), rationale=plan.get('rationale', {})))
        db.commit()
        summary.update(backup=str(backup), backupAssets='copy' if copy_assets else 'read-only-hash-manifest',
                       afterRevision=pc_store.revision(db))
        return summary
    except Exception as exc:
        db.rollback()
        if backup:
            raise ValueError(f'{exc}；数据库事务已回滚，备份保留于 {backup}') from exc
        raise
    finally:
        db.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True, help='真实档案或测试克隆目录；绝不自动初始化')
    parser.add_argument('--plan', '--mapping', dest='plan', help='逐题 questionOverrides JSON；省略时仅按 resolved 绑定')
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--revision', help='前次预览返回的完整 revision')
    parser.add_argument('--plan-sha256', help='可选：同时校验预览的 planSha256')
    parser.add_argument('--copy-assets', action='store_true', help='同时复制素材；默认只记录只读内容哈希清单')
    parser.add_argument('--backup-dir', help='档案之外的备份父目录；apply 时自动建立唯一快照子目录')
    args = parser.parse_args(argv)
    try:
        plan = json.loads(Path(args.plan).read_text(encoding='utf-8')) if args.plan else {}
        result = migrate(args.root, plan, args.revision, args.apply, args.backup_dir,
                         expected_plan_hash=args.plan_sha256, copy_assets=args.copy_assets)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, sqlite3.Error) as exc:
        print(json.dumps({'error': str(exc), 'applied': False}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
