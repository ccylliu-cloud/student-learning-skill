"""Explicit, reviewed math-tag migration. Defaults to a read-only preview.

The plan contains defaultMapping and questionOverrides (old ID -> new card IDs).
Run --apply only after reviewing the preview and supplying its revision and a
fresh archive backup. No question content, grading, practice results or IDs change.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, re, sqlite3, tempfile, zipfile
from pathlib import Path
import study, pc_store

OLD = re.compile(r'^M4A-K\d+$')
LIST_KEYS = {'knowledgeIds', 'knowledge_point_ids', 'verified_knowledge_ids'}
SCALAR_KEYS = {'knowledge_point_id', 'kp_id'}
NAME_KEYS = {'knowledgePoints', 'pc_knowledge_points'}

def legacy_ids(value):
    if isinstance(value, dict):
        return set().union(*(legacy_ids(v) for v in value.values()), set())
    if isinstance(value, list):
        return set().union(*(legacy_ids(v) for v in value), set())
    return {value} if isinstance(value, str) and OLD.fullmatch(value) else set()

def unique(values): return list(dict.fromkeys(values))

def prepare(db, plan):
    records = {r['id']: dict(r) for r in db.execute('SELECT * FROM knowledge')}
    old = {k: v for k, v in records.items() if OLD.fullmatch(k)}
    if not old:
        for table,col in [('questions','payload'),('papers','payload'),('reviews','payload'),('mastery','payload'),('meta','value')]:
            for row in db.execute(f'SELECT {col} FROM {table}'):
                study.require(not legacy_ids(json.loads(row[0])), '知识库已移除但仍有旧引用，请从备份恢复后审查迁移')
        study.require(not db.execute("SELECT 1 FROM mastery WHERE kp_id LIKE 'M4A-K%'").fetchone(), '掌握记录仍有旧引用')
        return {'changes': [], 'oldIds': [], 'counts': {}, 'alreadyApplied': True}
    defaults = plan['defaultMapping']; overrides = plan.get('questionOverrides', {})
    old_names = {}
    for k, row in old.items(): old_names.setdefault(row['name'], []).append(k)
    def mapped(k, context):
        value = overrides.get(context, {}).get(k, defaults.get(k))
        if isinstance(value, str): value = [value]
        study.require(isinstance(value, list) and value, f'缺少已审映射：{context} / {k}')
        for target in value:
            r = records.get(target)
            study.require(r and r['subject'] == 'math' and json.loads(r['payload']).get('knowledge_base_id') in ('math-k12-knowledge','math-highschool-knowledge'), f'目标不是正式数学知识卡：{target}')
        return unique(value)
    def resolve(k, context): return mapped(k, context) if k in old else [k]
    canonical = {}
    for row in db.execute('SELECT id,paper_id,local_id,payload FROM questions'):
        q = json.loads(row['payload'])
        if q.get('pc_scan_id'): canonical[q['pc_scan_id']] = row['id']
        canonical[(row['paper_id'],row['local_id'])] = row['id']
    def transform(value, context='', paper_id=''):
        if isinstance(value, list): return [transform(x, context, paper_id) for x in value]
        if not isinstance(value, dict): return value
        out = copy.deepcopy(value)
        sid = value.get('pc_scan_id')
        if sid: context = canonical.get(sid, 'scan-question-'+sid)
        elif value.get('canonicalId'): context = value['canonicalId']
        elif value.get('question_id'): context = value['question_id']
        elif value.get('id') in canonical: context = canonical[value['id']]
        elif value.get('local_id') and (paper_id,value['local_id']) in canonical: context = canonical[(paper_id,value['local_id'])]
        if isinstance(value.get('paper'),dict): paper_id = value['paper'].get('id',paper_id)
        affected = False
        for key in LIST_KEYS:
            if isinstance(value.get(key),list):
                if not any(k in old for k in value[key] if isinstance(k,str)): continue
                affected = True
                out[key] = unique([target for k in value[key] for target in resolve(k,context)])
                if key == 'knowledgeIds': study.require(len(out[key]) <= 3, f'映射后超过3个知识点，需审查：{context}')
        for key in SCALAR_KEYS:
            if value.get(key) in old:
                targets = mapped(value[key],context)
                study.require(len(targets)==1, f'单条归因/掌握记录不能自动拆分：{context} / {value[key]}')
                kid = targets[0]; row = records[kid]; raw = json.loads(row['payload'])
                out[key] = kid; affected = True
                if 'knowledge_name' in out: out['knowledge_name'] = row['name']
                if 'knowledge_version' in out: out['knowledge_version'] = row['version']
                out['knowledge_base_id'] = raw['knowledge_base_id']
                out['library_version'] = raw.get('kb_version')
        for key in NAME_KEYS:
            if key not in out: continue
            names = value[key]
            if not affected and not any(n in old_names for n in names): continue
            # A name-only legacy label is resolvable only when unambiguous.
            converted=[]
            for name in names:
                if name in old_names:
                    ks=old_names[name]; study.require(len(ks)==1, f'旧知识名称不唯一：{name}')
                    converted.extend(records[k]['name'] for k in mapped(ks[0],context)); affected=True
                else: converted.append(name)
            if out.get('knowledgeIds'):
                standard = [records[k]['name'] for k in out['knowledgeIds'] if k in records]
                old_standard = {records[k]['name'] for k in value.get('knowledgeIds',[]) if k in records}
                # Retain unmatched descriptions as candidates, separate from formal tags.
                extras=[]
                for n in names:
                    if n in old_standard: continue
                    candidates=[records[k]['name'] for k in mapped(old_names[n][0],context)] if n in old_names else [n]
                    extras.extend(x for x in candidates if x not in standard)
                out[key]=unique(standard)
                if extras:
                    retained=out.setdefault('knowledgeSelectionCandidates',[])
                    for name in unique(extras):
                        if not any(c.get('name')==name for c in retained):
                            retained.append({'name':name,'reason':'迁移保留的旧描述，需核对后再关联正式知识点'})
                    out['knowledgeSelectionReview']=True
            else: out[key]=unique(converted)
        for key, v in list(out.items()):
            if key not in LIST_KEYS | SCALAR_KEYS | NAME_KEYS:
                out[key] = transform(v,context,paper_id)
        return out
    changes=[]; counts={}
    for table in ('questions','papers','reviews','mastery','meta'):
        key='key' if table=='meta' else 'id'; column='value' if table=='meta' else 'payload'
        for row in db.execute(f'SELECT * FROM {table}'):
            # Metadata carrying schema/profile/import provenance is not knowledge state.
            if table=='meta' and row[key] not in ('pc_drafts','pc_recognition','pc_practice'): continue
            before=json.loads(row[column]); after=transform(before, row['question_id'] if table=='reviews' else row[key] if table!='meta' else '', row['paper_id'] if table=='questions' else '')
            left=legacy_ids(after)
            study.require(not left, f'仍有未迁移引用：{table}/{row[key]} {sorted(left)}')
            extra={}
            if table=='mastery' and row['kp_id'] in old:
                targets=mapped(row['kp_id'],row[key]); study.require(len(targets)==1,'掌握记录映射不可拆分');extra['kp_id']=targets[0]
            if after!=before or extra:
                changes.append({'table':table,'key':row[key],'column':column,'before':before,'after':after,'extra':extra})
                counts[table]=counts.get(table,0)+1
    return {'changes':changes,'oldIds':sorted(old),'counts':counts,'alreadyApplied':False}

def migrate(db, plan, expected_revision=None, apply=False):
    revision=pc_store.revision(db)
    if expected_revision is not None: study.require(revision==expected_revision,'档案已变更，请重新预览映射')
    report=prepare(db,plan)
    summary={k:v for k,v in report.items() if k!='changes'};summary['revision']=revision
    if not apply or report['alreadyApplied']: return summary
    try:
        db.execute('BEGIN IMMEDIATE')
        study.require(pc_store.revision(db)==revision,'档案并发变更，请重新预览')
        recognition=pc_store.meta(db,'pc_recognition',{'groups':[]})
        study.require(not any(g.get('requested') or g.get('runStatus') in ('queued','running') or g.get('supplementTask',{}).get('status') in ('queued','running') for g in recognition['groups']),'识别任务进行中，暂不能迁移')
        for c in report['changes']:
            key='key' if c['table']=='meta' else 'id'
            db.execute(f"UPDATE {c['table']} SET {c['column']}=? WHERE {key}=?",(study.dumps(c['after']),c['key']))
            for field,value in c['extra'].items():db.execute(f"UPDATE {c['table']} SET {field}=? WHERE {key}=?",(value,c['key']))
            study.event(db,c['key'],'math_knowledge_unification',c['before'],c['after'])
        before=[dict(r) for r in db.execute("SELECT * FROM knowledge WHERE id LIKE 'M4A-K%'")]
        db.executemany('DELETE FROM knowledge WHERE id=?',[(k,) for k in report['oldIds']])
        study.event(db,'math-knowledge','math_knowledge_catalog_retired',before,{'activeLibraries':['math-k12-knowledge','math-highschool-knowledge'],'planSha256':hashlib.sha256(study.dumps(plan).encode()).hexdigest()})
        db.commit()
    except Exception: db.rollback();raise
    return summary

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True);p.add_argument('--plan',required=True);p.add_argument('--apply',action='store_true');p.add_argument('--revision');p.add_argument('--backup');a=p.parse_args()
    dbpath=Path(a.root).expanduser().resolve()/'study.sqlite3'
    db=sqlite3.connect('file:'+str(dbpath)+'?mode='+('rw' if a.apply else 'ro'),uri=True);db.row_factory=sqlite3.Row
    try:
        if a.apply:
            study.require(bool(a.revision),'应用必须提供预览 revision')
            study.require(a.backup and Path(a.backup).is_file(),'应用前必须提供档案备份')
            with zipfile.ZipFile(a.backup) as z:
                study.require('study.sqlite3' in z.namelist(),'备份不含档案数据库')
                with tempfile.TemporaryDirectory(prefix='math-migration-backup-') as tmp:
                    path=Path(tmp)/'study.sqlite3';path.write_bytes(z.read('study.sqlite3'))
                    saved=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);saved.row_factory=sqlite3.Row
                    try: study.require(pc_store.revision(saved)==a.revision,'备份不是当前预览版本，请重新备份并预览')
                    finally:saved.close()
        print(json.dumps(migrate(db,json.loads(Path(a.plan).read_text(encoding='utf-8')),a.revision,a.apply),ensure_ascii=False,indent=2))
    finally:db.close()
if __name__=='__main__':main()
