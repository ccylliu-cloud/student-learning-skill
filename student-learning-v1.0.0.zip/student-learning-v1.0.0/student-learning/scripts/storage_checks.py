"""Real local storage probes and actionable errors; no existing database writes."""
import errno
import os
from pathlib import Path
import sqlite3
import tempfile


def plain_path(value):
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ValueError('请输入绝对文件夹路径')
    for entry in (path, *path.parents):
        if entry.is_symlink():
            raise ValueError('存储路径不能经过符号链接：' + str(entry))
    return path.resolve()


def probe_directory(value):
    """Create, write, flush and SQLite-commit only our fresh disposable probe."""
    path = plain_path(value)
    path.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.student-learning-probe-', dir=path) as temporary:
        folder = Path(temporary)
        with (folder / 'write-test').open('xb') as stream:
            stream.write(b'student-learning storage probe'); stream.flush(); os.fsync(stream.fileno())
        db = sqlite3.connect(folder / 'probe.sqlite3', timeout=2)
        try:
            db.execute('CREATE TABLE probe(value TEXT)')
            db.execute('INSERT INTO probe VALUES(?)', ('ok',)); db.commit()
            if db.execute('SELECT value FROM probe').fetchone()[0] != 'ok':
                raise sqlite3.DatabaseError('SQLite probe readback failed')
        finally:
            db.close()
    return path


def error_payload(error, path=None):
    detail = str(error)
    if isinstance(error, PermissionError) or getattr(error, 'errno', None) in (errno.EACCES, errno.EPERM):
        code = 'storage_permission_denied'
        message = '无法写入所选位置。请选已授权的可写本地目录，并检查宿主的目录访问授权；未切换或删除原档案。'
    elif isinstance(error, sqlite3.Error):
        code = 'storage_database_error'
        if 'locked' in detail.lower() or 'busy' in detail.lower():
            message = '档案正被其他操作占用，请完成正在进行的操作后重试；不要删除数据库文件。'
        else:
            message = '数据库读写失败。请检查目标位置是否仍可访问、磁盘是否可用，以及宿主是否允许写入；也可能是数据库或文件系统错误。未切换或删除原档案。'
    elif isinstance(error, OSError):
        code = 'storage_io_error'
        message = '本地文件操作失败，请检查路径、磁盘可用空间和目录访问权限后重试；未切换或删除原档案。'
    else:
        code = 'invalid_request'; message = detail
    return {'error':message, 'errorCode':code, 'detail':detail, **({'path':str(path)} if path else {})}
