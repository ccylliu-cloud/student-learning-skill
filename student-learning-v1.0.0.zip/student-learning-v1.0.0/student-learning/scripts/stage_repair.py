"""Local detection geometry repair with immutable original response and audit."""
import hashlib,json,uuid
from pathlib import Path
from recognition_recovery import normalize_result
from selective_recognition import _detection
from recognition_checkpoint import write

def repair_detection(root,stage_dir,result):
    base=(Path(root)/'drafts').resolve();folder=Path(stage_dir).resolve()
    if base not in folder.parents or folder.name!='stage-detect' or folder.is_symlink():raise ValueError('只允许本档案drafts内的stage-detect恢复点')
    marker=folder/'ready.json';receipt=json.loads(marker.read_text(encoding='utf-8'));original=folder/'result.json'
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    if digest(original)!=receipt['sha256']:raise ValueError('原始响应哈希变化，不能重写恢复依据')
    old,_=normalize_result(original.read_text(encoding='utf-8'));path=Path(result)
    new,_=normalize_result(path.read_text(encoding='utf-8'))
    if len(new.get('candidates',[]))!=len(old.get('candidates',[])):raise ValueError('本入口只能修复题框，不能增删候选')
    for a,b in zip(old['candidates'],new['candidates']):
        if {k:v for k,v in a.items() if k not in ('box','context_boxes')}!={k:v for k,v in b.items() if k not in ('box','context_boxes')}:raise ValueError('本入口不能更改候选语义，只允许校正框')
    count=len(old.get('vision',{}).get('pages',[]));checked,_,_=_detection(path.read_text(encoding='utf-8'),count)
    if checked.get('rejected_candidates'):raise ValueError('修复结果仍含无效题框')
    if new.get('vision')!=old.get('vision') or new.get('status')!=old.get('status'):raise ValueError('不能改写原始读图报告或批改状态')
    name='geometry-repair-'+uuid.uuid4().hex+'.json';target=folder/name;target.write_bytes(path.read_bytes())
    record={'file':name,'sha256':digest(target),'origin':'local_geometry_revision','original_sha256':receipt['sha256']}
    receipt.setdefault('repair_history',[]).append(record);receipt['repair']=record;write(marker,receipt)
    return {'status':'geometry_repaired','original_unchanged':True,'repair':str(target),'next':'回网页重试，复用修复后的定位，仅继续未完成阶段；详情仍需模型处理'}
