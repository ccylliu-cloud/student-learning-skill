#!/usr/bin/env python3
"""Local trial launcher and current-conversation recognition handoff (Python 3.10+)."""
import argparse
import hashlib
import importlib.util
import importlib.metadata
import re
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import uuid
import webbrowser
import portable_config as config


def output(value):
    print(json.dumps(value, ensure_ascii=False), flush=True)


def dependencies():
    missing = []
    for module, package, minimum in (('PIL', 'Pillow', (10,1)), ('docx', 'python-docx', (1,1))):
        try:
            numbers = tuple(int(v) for v in re.findall(r'\d+', importlib.metadata.version(package))[:2])
            available = importlib.util.find_spec(module) is not None and numbers >= minimum
        except importlib.metadata.PackageNotFoundError:
            available = False
        if not available:
            missing.append(package + '>=' + '.'.join(map(str,minimum)))
    if missing:
        raise ValueError('缺少依赖：'+', '.join(missing)+'。请运行本安装 scripts/setup_runtime.py --install-deps 准备独立环境，然后使用它输出的 Python；不要修改系统 Python。')


def context(root, db, gid):
    import study, pc_store
    rec = pc_store.meta(db, 'pc_recognition', {'pages': [], 'groups': []})
    group = next((g for g in rec['groups'] if g['id'] == gid), None)
    study.require(group and group.get('pageIds'), '识别分组不存在或为空')
    study.require(not group.get('recognized'), '本组已有识别结果，请在网页修订，不能覆盖人工记录')
    pages = {p['id']: p for p in rec['pages']}
    files = [pc_store.source_path(root, pages[i]['url']) for i in group['pageIds']]
    return group, files


def fingerprint(group, files):
    payload = {'group': group, 'files': [hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files]}
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def verify_export_images(manifest_path, manifest):
    base=Path(manifest_path).resolve().parent
    names=manifest.get('imageFiles')
    records=manifest.get('images',[])
    if not isinstance(names,list) or len(names)!=len(records):raise ValueError('导出图片列表不完整，请重新导出')
    for name,record in zip(names,records):
        if not isinstance(name,str) or Path(name).is_absolute():raise ValueError('导出图片路径无效')
        path=(base/name).resolve()
        if base not in path.parents or not path.is_file():raise ValueError('导出图片缺失或路径越界，请重新导出')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=record['sha256']:raise ValueError('导出图片已变更，请重新导出；不能用其他图片替换识别任务')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', help='实际工作区绝对路径（WorkBuddy首次必需）')
    parser.add_argument('--reuse-existing',action='store_true',help='明确复用已有档案，不复制或覆盖')
    parser.add_argument('--root', help='明确选择独立档案目录；保存为此安装下次默认目录')
    sub = parser.add_subparsers(dest='cmd', required=True)
    sub.add_parser('check')
    sub.add_parser('doctor')
    sub.add_parser('pending')
    repair=sub.add_parser('repair-detection');repair.add_argument('--stage-dir',required=True);repair.add_argument('--result',required=True)
    configure=sub.add_parser('configure-recognition');configure.add_argument('--model',required=True);configure.add_argument('--reasoning-effort',default='medium',choices=('low','medium','high','xhigh','max','ultra'))
    sub.add_parser('init')
    launch = sub.add_parser('serve'); launch.add_argument('--port', type=int, default=8767); launch.add_argument('--open', action='store_true')
    stage = sub.add_parser('stage'); stage.add_argument('files', nargs='+'); stage.add_argument('--subject', choices=('math','chinese','english')); stage.add_argument('--practice-paper'); stage.add_argument('--date')
    group = sub.add_parser('group'); group.add_argument('--subject', required=True, choices=('math','chinese','english')); group.add_argument('--title', required=True); group.add_argument('--pages', nargs='+', required=True)
    sub.add_parser('groups')
    exp = sub.add_parser('conversation-export'); exp.add_argument('group_id'); exp.add_argument('--out', required=True); exp.add_argument('--retry-vision',action='store_true',help='用户确认已切换读图方式后重试')
    exp.add_argument('--mode', choices=('original','report','supplement'), default='original')
    exp.add_argument('--consent', action='store_true', help='用户已明确同意整卷识别消耗，仅用于整卷报告')
    exp.add_argument('--page-id', help='补题页面ID；省略则沿用网页最近圈选')
    exp.add_argument('--box', help='补题百分比框 JSON：x,y,width,height')
    renew = sub.add_parser('conversation-renew'); renew.add_argument('manifest'); renew.add_argument('--retry-vision', action='store_true')
    retry = sub.add_parser('conversation-retry'); retry.add_argument('manifest'); retry.add_argument('--result', help='可选本地修复JSON，不重新看图')
    submit = sub.add_parser('conversation-submit'); submit.add_argument('manifest'); submit.add_argument('--result', required=True)
    vision=sub.add_parser('conversation-vision');vision.add_argument('manifest');vision.add_argument('--report',required=True)
    block=sub.add_parser('conversation-block');block.add_argument('manifest');block.add_argument('--reason',required=True)
    args = parser.parse_args()
    if sys.version_info < (3, 10): raise ValueError('需要 Python 3.10 或以上版本')
    dependencies()
    if args.cmd=='configure-recognition':
        config.atomic(config.SKILL/'runtime/recognition.json',json.dumps({'model':args.model,'reasoning_effort':args.reasoning_effort}).encode())
        output(__import__('release_runtime').settings());return
    if args.cmd=='doctor':
        from release_checks import doctor
        output(doctor());return
    if args.cmd == 'check':
        output({'ok': True, 'host': config.host(), 'python': sys.executable, 'root': config.read_config()['root'], 'config': str(config.CONFIG), 'writes': False}); return
    root = config.select_root(args.root,workspace=args.workspace,reuse_existing=args.reuse_existing)
    import study, pc_store
    if args.cmd not in ('init', 'serve') and not (root / 'study.sqlite3').is_file():
        raise ValueError('档案尚未初始化，请先运行 portable.py init 或 serve')
    root, db = study.connect(root)
    try:
        if args.cmd in ('init', 'serve'):
            counts = study.init_kb(db)
            if args.cmd == 'init': output({'root':str(root), 'knowledge_points':counts}); return
            db.close()
            from pc_server import make_server
            server = make_server(root, args.port)
            server.runner.recover()
            url = 'http://127.0.0.1:' + str(server.server_port) + '/'
            output({'url': url, 'root': str(root), 'host': config.host(), 'mode': 'foreground', 'stop': 'Ctrl+C / 关闭此终端', 'recognition': 'current-conversation' if config.host() == 'workbuddy' else 'codex-cli'})
            if args.open: webbrowser.open(url)
            try: server.serve_forever()
            except KeyboardInterrupt: pass
            finally: server.runner.close(); server.server_close()
            return
        if args.cmd == 'stage':
            if args.practice_paper:
                study.require(args.date, '复练需要 --date YYYY-MM-DD')
                result = pc_store.stage_practice_pages(root, db, args.files, args.practice_paper, args.date)
            else:
                study.require(args.subject, '原卷需要 --subject')
                result = pc_store.stage_pages(root, db, args.files, args.subject)
            output({'stagedPageIds':result.get('stagedPageIds'),'importResults':result.get('importResults',[]), 'groups':[{'id':g['id'],'title':g['title']} for g in result['archive']['recognition']['groups']]})
        elif args.cmd == 'group':
            env = pc_store.read_archive(root, db)
            gid = 'conversation-' + uuid.uuid4().hex
            env['archive']['recognition']['groups'].append({'id':gid, 'title':args.title, 'subject':study.SUBJECTS[args.subject], 'pageIds':args.pages, 'questions':[], 'recognized':False, 'requested':False})
            pc_store.apply_archive(root, db, env['archive'], env['revision'])
            output({'groupId':gid})
        elif args.cmd=='repair-detection':
            from stage_repair import repair_detection
            output(repair_detection(root,args.stage_dir,args.result))
        elif args.cmd == 'pending':
            groups=pc_store.meta(db,'pc_recognition',{'groups':[]})['groups']
            output({'pending':[{'groupId':g['id'],'title':g['title'],'handoff':g.get('conversationHandoff'),'supplement':g.get('supplementTask'),'report':g.get('reportTask')} for g in groups if g.get('conversationHandoff') or g.get('runStatus')=='awaiting_conversation' or any(g.get(k,{}).get('status')=='awaiting_conversation' for k in ('reportTask','supplementTask'))]})
        elif args.cmd == 'groups':
            groups = pc_store.meta(db,'pc_recognition',{'groups':[]})['groups']
            output({'groups':[{'id':g['id'],'title':g['title'],'subject':g['subject'],'pages':len(g['pageIds']),'recognized':bool(g.get('recognized')),'runStatus':g.get('runStatus')} for g in groups]})
        elif args.cmd.startswith('conversation-'):
            import portable_conversation
            output(portable_conversation.dispatch(root, db, args))

    finally:
        db.close()


if __name__ == '__main__':
    try: main()
    except (ValueError, KeyError, TypeError, OSError, sqlite3.Error) as exc:
        from storage_checks import error_payload
        output(error_payload(exc)); sys.exit(1)
