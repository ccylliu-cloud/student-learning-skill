"""One user-selected region -> one pending question, without re-running the paper."""
from __future__ import annotations
import copy, hashlib, json, math, re, subprocess, time, uuid
from pathlib import Path
import study, pc_store as s
from recognition_contract import build_prompt, expand_result

ACTIVE = ('queued', 'running')

def queue_task(root, db, data, expected_revision):
    s.require(isinstance(data, dict) and set(data)=={'groupId','pageId','box','requestId'}, '补充题请求字段无效')
    gid,pid,rid=data['groupId'],data['pageId'],data['requestId']
    s.require(all(isinstance(x,str) and x for x in (gid,pid,rid)), '补充题请求缺少编号')
    try: s.require(str(uuid.UUID(rid))==rid, '请求编号无效')
    except (ValueError,AttributeError): raise ValueError('请求编号无效')
    box=s._box(data['box']);s.require(box['width']>=1 and box['height']>=1,'请圈选完整题目范围')
    db.execute('BEGIN IMMEDIATE')
    try:
        if s.revision(db)!=expected_revision:raise s.ConflictError('档案已更新，请重新提交圈选范围')
        rec=s.meta(db,'pc_recognition',{'pages':[],'groups':[]});g=next((x for x in rec['groups'] if x['id']==gid),None)
        s.require(g and g.get('recognized') and g.get('kind')!='practice','请在原卷识别结果中圈选补充题')
        s.require(not g.get('requested') and g.get('runStatus') not in ACTIVE,'该试卷正在识别，请稍候')
        s.require(g.get('reportTask',{}).get('status') not in ACTIVE,'整卷分析正在处理中，请完成后再补充题目')
        s.require(pid in g['pageIds'],'圈选页面不属于该试卷')
        previous=g.get('supplementTask')
        if previous and previous.get('status')=='awaiting_conversation' and previous['id']!=rid:
            raise ValueError('上一道圈选仍待对话处理，请先完成后再圈选；原范围已保留')
        if previous and previous['id']==rid:
            s.require(previous['pageId']==pid and previous['box']==box,'同一请求不能更换圈选范围')
            db.commit();return copy.deepcopy(previous)
        s.require(not previous or previous['status'] not in ACTIVE,'补充题正在识别，请完成后再圈选下一题')
        s.require(not db.execute("SELECT 1 FROM events WHERE entity_id=? AND kind='supplement_queued'",(rid,)).fetchone(),'该请求已处理，请刷新后重试')
        page=next(p for p in rec['pages'] if p['id']==pid);source=s.source_path(root,page['url']);now=study.now()
        task={'id':rid,'pageId':pid,'box':box,'status':'queued','sourceHash':hashlib.sha256(source.read_bytes()).hexdigest(),
              'sourceUrl':page['url'],'subject':g['subject'],'grade':g.get('grade'),
              'progress':{'phase':'preparing','startedAt':now,'updatedAt':now,'message':'补充题已提交，正在准备识别'}}
        g['supplementTask']=task;s.put_meta(db,'pc_recognition',rec)
        study.event(db,rid,'supplement_queued',previous,task);db.commit();return copy.deepcopy(task)
    except Exception:db.rollback();raise

def stamp(root,gid,task_id,status,phase=None,error=None,question_id=None,message=None):
    _,db=study.connect(root)
    try:
        db.execute('BEGIN IMMEDIATE');rec=s.meta(db,'pc_recognition',{'groups':[]});g=next((x for x in rec['groups'] if x['id']==gid),None)
        task=g.get('supplementTask') if g else None
        if not task or task['id']!=task_id or task['status'] not in ACTIVE:db.rollback();return
        from codex_bridge import PHASES
        now=study.now();task['status']=status;phase=phase or status
        task['progress'].update(phase=phase,updatedAt=now,message=message or PHASES.get(phase,'补充题正在识别'))
        if status in ('completed','failed'):task['progress']['finishedAt']=now
        if error:task['error']=error
        if question_id:task['questionId']=question_id
        s.put_meta(db,'pc_recognition',rec);db.commit()
    finally:db.close()

def crop_region(source,box,target):
    from PIL import Image,ImageOps
    s._box(box)
    with Image.open(source) as raw:
        image=ImageOps.exif_transpose(raw);w,h=image.size
        bounds=(max(0,math.floor(w*box['x']/100)),max(0,math.floor(h*box['y']/100)),min(w,math.ceil(w*(box['x']+box['width'])/100)),min(h,math.ceil(h*(box['y']+box['height'])/100)))
        s.require(bounds[2]-bounds[0]>=16 and bounds[3]-bounds[1]>=16,'圈选区域太小，请重新框选完整题面')
        image.crop(bounds).convert('RGB').save(target,'PNG')

def supplement_prompt(root,db,g,source):
    text=build_prompt(root,db,g,[str(source)])
    text=text.replace('逐页包括正确、错误、待定及无法判定题；按可独立练习单元计数，多空整题不再重复计空。','只识别本次圈选区域中的一道可独立练习题，多空视为一题。')
    return text+'''\n本次为用户圈选的补充题，附图仅是这一圈选区域。只输出一道题，禁止扩展到整卷。逐字保留区域内可见题干、选项、图形条件和学生作答，并验算参考答案、给出解析及已查证知识点。缺少跨区域共用条件时标pending或ungradable并说明，不猜缺失条件。题号用原印刷题号；看不到题号用“补充题”。paper固定coverage:"partial",expected_question_count:null,scanned_pages:[1]；page固定1；不输出box（由用户选框恢复）。具体知识规则的skill_id/skill_name仅写入evidence文本，不能新增协议字段。仅输出questions数组的一项；只返回JSON，不运行导入或更改档案。'''

def _same_question(a,b):
    # Conservative duplicate prevention: do not merge merely similar exercises.
    norm=lambda x:re.sub(r'\s+','',str(x or ''))
    return a.get('page')==b.get('page') and norm(a.get('number'))==norm(b.get('number')) and bool(norm(a.get('text'))) and norm(a.get('text'))==norm(b.get('text')) and norm(a.get('sharedContext'))==norm(b.get('sharedContext')) and norm(a.get('sectionTitle'))==norm(b.get('sectionTitle'))

def save_question(root,db,gid,task_id,result):
    prepared=s._prepare_paper(root,db,result);q=prepared['questions'][0]
    db.execute('BEGIN IMMEDIATE')
    try:
        rec=s.meta(db,'pc_recognition',{'pages':[],'groups':[]});g=next((x for x in rec['groups'] if x['id']==gid),None);task=g.get('supplementTask') if g else None
        s.require(task and task['id']==task_id and task['status'] in ACTIVE,'补充题请求已更新，旧结果不会写入')
        s.require(g.get('recognized') and g.get('kind')!='practice' and g['subject']==task['subject'] and g.get('grade')==task.get('grade'),'试卷来源或年级已改变，请重新圈选')
        pid=task['pageId'];page=next((p for p in rec['pages'] if p['id']==pid),None)
        s.require(page and pid in g['pageIds'] and page['url']==task['sourceUrl'] and hashlib.sha256(s.source_path(root,page['url']).read_bytes()).hexdigest()==task['sourceHash'],'原图已改变，请重新圈选')
        drafts=s.meta(db,'pc_drafts',{});s.require(gid in drafts,'原卷识别稿不存在，请先恢复原卷');draft=drafts[gid]
        q.update(local_id='supplement:'+task_id,pc_scan_id=gid+'-supplement-'+task_id,page=g['pageIds'].index(pid)+1,box=s.clone(task['box']),pc_box=s.clone(task['box']),boxVerified=True,decision_status='pending',pc_supplemental=True)
        old=s.clone(task);records,_=s.knowledge_catalog(db);duplicate=None
        for existing in draft['questions']:
            stored=db.execute('SELECT id,payload FROM questions WHERE paper_id=? AND local_id=?',(draft['paper']['id'],existing['local_id'])).fetchone()
            candidate=json.loads(stored['payload']) if stored else existing
            if _same_question(candidate,q) and not candidate.get('pc_excluded'):
                duplicate=s._scan_projection(candidate,g,records,stored['id'] if stored else None);break
        if duplicate:
            sid=duplicate['id'];message='识别完成，已定位到已有题目，原有内容与人工判定已保留'
        else:
            draft['questions'].append(q);draft['paper'].update(coverage='partial',expected_question_count=None)
            scan=s._scan_projection(q,g,records);g['questions'].append(scan);sid=scan['id'];g['finalized']=False
            g.update(coverage='partial',expectedQuestionCount=None)
            p_row=db.execute('SELECT payload FROM papers WHERE id=?',(draft['paper']['id'],)).fetchone()
            if p_row:
                p=json.loads(p_row[0]);p_after={**p,'coverage':'partial','expected_question_count':None}
                if p!=p_after:
                    db.execute('UPDATE papers SET payload=? WHERE id=?',(study.dumps(p_after),draft['paper']['id']))
                    study.event(db,draft['paper']['id'],'supplement_coverage',p,p_after)
            s.put_meta(db,'pc_drafts',drafts);message='补充题识别完成，请核对内容与正误'
        now=study.now();task.update(status='completed',questionId=sid);task.pop('error',None)
        task['progress'].update(phase='completed',updatedAt=now,finishedAt=now,message=message)
        s.put_meta(db,'pc_recognition',rec);study.event(db,task_id,'supplement_completed',old,{'task':task,'question':q if not duplicate else None,'reused':bool(duplicate)});db.commit();return sid
    except Exception:db.rollback();raise

def friendly_error(error,page_number):
    from vision_guard import blocked_error,BLOCKED_MESSAGE
    if isinstance(error,subprocess.TimeoutExpired):reason='本次识别等待超时，已停止。请稍后重试当前区域。'
    elif isinstance(error,json.JSONDecodeError):reason='识别结果格式不完整，未保存新题。请重试当前区域。'
    elif blocked_error(str(error)) or str(error)==BLOCKED_MESSAGE:reason='当前模型无法读取这张图片。请在支持看图的 Codex 会话中处理此区域。'
    elif '未找到 Codex' in str(error):reason='未找到本机 Codex，请在 Codex 中打开学习记录册后重试。'
    elif '连接或用量' in str(error):reason='模型未完成识别。请检查 Codex 登录、网络及可用额度后重试当前区域。'
    elif '圈选区域太小' in str(error):reason='圈选区域太小，请重新框选完整题面。'
    else:reason='本次结果未能通过保存校验，未添加新题。请重试当前区域；若仍失败，请把此提示发回对话排查。'
    return f'第 {page_number} 页圈选区域：{reason} 原有题目和人工判定已保留。'

def run_task(runner,gid,task_id):
    from codex_bridge import command
    root=runner.root;work=root/'drafts'/('supplement-'+uuid.uuid4().hex)
    start=time.monotonic();page_number=1
    metrics={'version':1,'kind':'supplement','protocol':'student-scan-v3','group_id':gid,'request_id':task_id,'started_at':study.now(),'usage':None,'usage_complete':False,'tool_calls':0,'tool_output_chars':0,'connection_retry_events':0,'status':'preparing'}
    try:
        work.mkdir(parents=True)
        _,db=study.connect(root)
        try:
            rec=s.meta(db,'pc_recognition',{'groups':[],'pages':[]});g=next(x for x in rec['groups'] if x['id']==gid);task=g.get('supplementTask')
            if not task or task['id']!=task_id or task['status'] not in ACTIVE:metrics['status']='skipped';return
            page_number=g['pageIds'].index(task['pageId'])+1
            page=next(x for x in rec['pages'] if x['id']==task['pageId']);source=s.source_path(root,page['url'])
            s.require(hashlib.sha256(source.read_bytes()).hexdigest()==task['sourceHash'],'原图已改变')
            virtual={**g,'pageIds':[task['pageId']]};prompt=supplement_prompt(root,db,virtual,source)
        finally:db.close()
        crop=work/'selected-region.png';crop_region(source,task['box'],crop);output=work/'result.json'
        metrics.update(page_number=page_number,page_count=1,prompt_chars=len(prompt))
        stamp(root,gid,task_id,'running',phase='preparing')
        callback=lambda phase:stamp(root,gid,task_id,'running',phase=phase)
        rc=runner._execute(gid,command(work,output,[str(crop)]),prompt,work,task_id,metrics,stamp_callback=callback)
        if rc or not output.exists():
            metrics['usage_complete']=False
            raise ValueError('Codex 未完成本次识别，请检查连接或用量后重试。')
        raw=output.read_text(encoding='utf-8').strip()
        if raw.startswith('```'):raw=raw.split('\n',1)[1].rsplit('```',1)[0].strip()
        compact=json.loads(raw)
        if isinstance(compact,dict) and compact.get('status') in ('image_blocked','blocked'):
            from vision_guard import BLOCKED_MESSAGE
            raise ValueError(BLOCKED_MESSAGE)
        s.require(isinstance(compact,dict) and isinstance(compact.get('questions'),list) and len(compact['questions'])==1,'一次圈选只能识别一道完整题目')
        # Crop-relative model boxes are deliberately ignored: the user's box is authoritative.
        compact['questions'][0].pop('box',None)
        callback('saving');_,db=study.connect(root)
        try:
            result=expand_result(root,db,virtual,[str(source)],compact)
            q=result['questions'][0]
            if q.get('diagram'):
                from pc_diagram import render_diagram
                asset=render_diagram(root,q.pop('diagram'));q['content']['blocks'].append({'type':'image','asset':asset});q['diagramReviewRequired']=True
            save_question(root,db,gid,task_id,result)
        finally:db.close()
        metrics.update(status='completed',question_count=1)
    except Exception as error:
        metrics.update(status='failed',error_kind=type(error).__name__,error=str(error)[:1000])
        if isinstance(error,subprocess.TimeoutExpired):metrics['usage_complete']=False
        stamp(root,gid,task_id,'failed',error=friendly_error(error,page_number))
    finally:
        metrics.update(finished_at=study.now(),elapsed_seconds=round(time.monotonic()-start,3))
        try:(work/'usage.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
        finally:
            with runner.lock:runner.active.pop(gid,None);runner.processes.pop(gid,None)
