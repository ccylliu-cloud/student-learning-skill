#!/usr/bin/env python3
"""Local storage and publishing only. All semantic assessment is performed by Codex."""
from pc_content import has_question_content
import argparse, collections, datetime as dt, hashlib, json, mimetypes, os, re, secrets, shutil, sqlite3, sys, unicodedata, uuid, zipfile
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote

SKILL = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = Path.home()/'.local/share/codex-student-learning'
def default_root():
    from portable_config import read_config
    return Path(read_config()['root']).expanduser().resolve()

SUBJECTS = {'math':'数学','english':'英语','chinese':'语文'}
VERDICTS = {'wrong','correct','pending','ungradable'}
STATUSES = {'pending','provisional','confirmed'}
MASTERY = {'pending':'待确认','not_mastered':'未掌握','partially_mastered':'部分掌握','mastered':'已掌握'}
CAUSE_NAMES = {'math':['概念模糊','思路错误','运算错误','审题错误','作答规范错误','粗心大意','完全不会'], 'english':['拼写错误','词汇错误','语法错误','用词不当','审题错误','理解错误','粗心大意','完全不会','听辨错误'], 'chinese':['基础积累错误','语言运用错误','审题错误','阅读理解错误','表达错误','粗心大意','完全不会']}
CAUSES = {f'{prefix}_E{i:02}':{'subject':s,'name':name} for s,prefix in [('math','MATH'),('english','ENG'),('chinese','CHN')] for i,name in enumerate(CAUSE_NAMES[s],1)}

def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def uid(): return uuid.uuid4().hex
def dumps(x): return json.dumps(x,ensure_ascii=False,allow_nan=False)
def read_json(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def require(ok, msg):
    if not ok: raise ValueError(msg)
def nonempty(s): return isinstance(s,str) and bool(s.strip())
def date(s):
    require(isinstance(s,str),'日期必须是 YYYY-MM-DD'); dt.date.fromisoformat(s); return s

def connect(root):
    root=Path(root).expanduser().resolve(); root.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(root/'study.sqlite3',timeout=30); db.row_factory=sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript('''
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS papers(id TEXT PRIMARY KEY,digest TEXT NOT NULL,payload TEXT NOT NULL,created TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS questions(id TEXT PRIMARY KEY,paper_id TEXT NOT NULL REFERENCES papers(id),local_id TEXT NOT NULL,subject TEXT NOT NULL,fingerprint TEXT NOT NULL,payload TEXT NOT NULL,UNIQUE(paper_id,local_id));
    CREATE TABLE IF NOT EXISTS reviews(id TEXT PRIMARY KEY,question_id TEXT NOT NULL REFERENCES questions(id),payload TEXT NOT NULL,created TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS mastery(id TEXT PRIMARY KEY,subject TEXT NOT NULL,kp_id TEXT NOT NULL,payload TEXT NOT NULL,created TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS events(seq INTEGER PRIMARY KEY AUTOINCREMENT,entity_id TEXT NOT NULL,kind TEXT NOT NULL,before_json TEXT,after_json TEXT NOT NULL,created TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS knowledge(id TEXT PRIMARY KEY,subject TEXT NOT NULL,name TEXT NOT NULL,version TEXT NOT NULL,payload TEXT NOT NULL);
    ''')
    version=db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
    require(not version or version[0]=='1','数据库版本不兼容，请迁移后再使用')
    db.execute("INSERT OR IGNORE INTO meta VALUES('schema_version','1')"); db.commit()
    return root,db

def init_kb(db):
    files=[('english',SKILL/'references/knowledge/english/knowledge_points.json'),('chinese',SKILL/'references/knowledge/chinese/语文两级知识库.json')]
    with db:
        for s,f in files:
            data=read_json(f); records=data if isinstance(data,list) else data['points' if s=='chinese' else 'records']
            version=hashlib.sha256(f.read_bytes()).hexdigest()
            for r in records:
                k=r.get('knowledge_point_id',r.get('kp_id')); name=r.get('三级细分考点',r.get('point',r.get('name')))
                db.execute('INSERT OR REPLACE INTO knowledge VALUES(?,?,?,?,?)',(k,s,name,version,dumps(r)))
    from math_k12 import records as math_records
    from math_highschool import records as highschool_records
    incoming=[]
    for loader in (math_records,highschool_records):
        cards,version=loader(SKILL)
        incoming.extend((r['knowledge_point_id'],'math',r['name'],version,dumps(r)) for r in cards)
    active_ids={r[0] for r in incoming}
    with db:
        for row in db.execute("SELECT id,payload FROM knowledge WHERE subject='math'").fetchall():
            if row['id'] not in active_ids:
                raw=json.loads(row['payload']); raw.update(active=False,is_assessable=False,legacy_reference=True)
                db.execute('UPDATE knowledge SET payload=? WHERE id=?',(dumps(raw),row['id']))
        db.executemany('INSERT OR REPLACE INTO knowledge VALUES(?,?,?,?,?)',incoming)
    return {s:len(incoming) if s=='math' else db.execute('SELECT count(*) FROM knowledge WHERE subject=?',(s,)).fetchone()[0] for s in SUBJECTS}

def event(db,entity,kind,before,after):
    db.execute('INSERT INTO events(entity_id,kind,before_json,after_json,created) VALUES(?,?,?,?,?)',(entity,kind,dumps(before) if before is not None else None,dumps(after),now()))

def clear_correct_attributions(q):
    """Manual verdict changes keep prior causes in the event before_json audit."""
    if q.get('verdict') == 'correct':
        q['attributions'] = []
        q['observed_error'] = ''
        q.pop('pc_reasons', None)


def validate_question(db,q,subject,*,historical=None,machine_import=False,canonical_id=None):
    if machine_import:
        from evidence_contract import validate
        validate(db,q,subject)
    for key in ['local_id','number','text','observed_error','evidence']:
        require(isinstance(q.get(key),str),f'{key} 必须为文字')
    require(nonempty(q['local_id']) and nonempty(q['number']),'题号不能为空')
    require(q.get('verdict') in VERDICTS,'判题状态无效')
    require(q.get('decision_status') in {'pending','confirmed'},'判题确认状态无效')
    require(q.get('evidence_level') in {'A','B','C'},'证据等级无效')
    require(q.get('basis') in {'teacher_mark','model_reasoning','user_confirmed'},'判题依据无效')
    require(type(q.get('page')) is int and q['page']>0,'页码必须为正整数')
    for key in ['student_answer','corrected_answer','expected_answer','explanation']:
        require(q.get(key) is None or isinstance(q.get(key),str),f'{key} 必须为文字或 null')
    if q['verdict']=='wrong' and q['decision_status']=='confirmed' and not q.get('pc_excluded'):
        require(has_question_content(q) and nonempty(q['evidence']),'确认错题需要题干和证据')
        require(q['evidence_level']=='A' or q['basis']=='user_confirmed','B/C 级题须经用户确认才能成为确定错题')
    if 'knowledgeIds' in q:
        from pc_store import validate_knowledge
        validate_knowledge(db,q,subject,historical=historical)
    require(isinstance(q.get('attributions',[]),list),'attributions 必须为数组')
    if q['verdict']=='correct':
        legacy_note = not machine_import and historical is not None and historical.get('verdict')=='correct' and q.get('attributions',[])==historical.get('attributions',[]) and all(q.get(key)==historical.get(key) for key in ('observed_error','text','student_answer','evidence'))
        require((not q.get('attributions') and not nonempty(q.get('observed_error'))) or legacy_note, '正确题不得新增或修改错误归因或首错表现')
    if machine_import and q['verdict']=='wrong':
        require(nonempty(q.get('observed_error')), '机器识别错题必须保存首错步骤 observed_error')
        require(bool(q.get('attributions')), '机器识别错题必须保存归因；未知原因使用 pending 并说明证据缺口')
    for a in q.get('attributions',[]):
        require(isinstance(a,dict),'归因必须为对象')
        require(a.get('status') in STATUSES,'归因状态无效')
        require(nonempty(a.get('evidence')),'归因必须提供证据或待确认说明')
        unchanged_attribution = historical is not None and a in historical.get('attributions',[])
        k=a.get('knowledge_point_id'); cause=a.get('error_cause_id')
        if k:
            row=db.execute('SELECT * FROM knowledge WHERE id=?',(k,)).fetchone()
            require(row and row['subject']==subject,f'知识点不存在或学科不符：{k}')
            raw=json.loads(row['payload'])
            unchanged_history=historical is not None and a in historical.get('attributions',[]) and raw.get('legacy_reference') is True
            if subject=='math': require(raw.get('is_assessable') is True or unchanged_history,'请选择现行数学末级知识点；历史分类编号需要核对后迁移')
            a['knowledge_version']=row['version']
            a['knowledge_name']=row['name']
            if subject=='chinese' and raw.get('library_version'): a['library_version']=raw['library_version']
            if raw.get('knowledge_base_id')in ('math-k12-knowledge','math-highschool-knowledge'):
                a['knowledge_base_id']=raw['knowledge_base_id']; a['library_version']=raw['kb_version']
            restricted=raw.get('node_type')=='pending_topic' or raw.get('content_status')=='pending_body_confirmation' or raw.get('assessment_policy',{}).get('mode')=='review_only'
            require(not(restricted and a['status']=='confirmed'),'待正文核实/争议知识点不能形成确认归因')
        else:
            require(a['status']!='confirmed','未映射知识点只能暂定或待确认')
            require(a.get('knowledge_name') is None or isinstance(a.get('knowledge_name'),str),'候选知识名称必须为文字；未匹配可留空')
        if cause:
            require(cause in CAUSES and CAUSES[cause]['subject']==subject,'错因 ID 不存在或学科不符')
            if CAUSES[cause]['name']=='粗心大意' and a['status']=='confirmed':
                unchanged = unchanged_attribution and q.get('observed_error') == historical.get('observed_error') and q.get('evidence') == historical.get('evidence') and q.get('student_answer') == historical.get('student_answer') and q.get('text') == historical.get('text')
                if not unchanged:
                    proof=a.get('carelessness_verification')
                    require(isinstance(proof,dict),'确认粗心必须提供本题结构化核实证据 carelessness_verification')
                    require(proof.get('kind') in {'unprompted_correction','same_question_mastery'},'粗心须有本题无提示纠正或本题掌握证据')
                    identities={canonical_id,q.get('local_id'),q.get('pc_scan_id')} - {None,''}
                    require(proof.get('question_id') in identities,'粗心证据必须指向本题，不能用其他题替代')
                    require(proof.get('source') in {'user_confirmed','recorded_attempt'},'粗心证据必须来自用户针对本题确认或已记录复练')
                    require(nonempty(proof.get('evidence')),'粗心核实证据不能为空')
                    if proof['source']=='user_confirmed':
                        require(q.get('basis')=='user_confirmed','本题粗心核实需经用户确认')
                    else:
                        attempt=db.execute('SELECT question_id,payload FROM reviews WHERE id=?',(proof.get('attempt_id'),)).fetchone()
                        require(attempt,'本题掌握证据所引复练不存在')
                        review_question_id=attempt['question_id']
                        attempt=json.loads(attempt['payload'])
                        require(canonical_id is not None and review_question_id==canonical_id and attempt.get('result')=='correct' and attempt.get('independent') is True,'复练证据必须为本题独立正确作答')
        else: require(a['status']!='confirmed','确认归因必须有错因 ID')
    require(isinstance(q.get('assets',[]),list),'assets 必须为数组')
    for asset in q.get('assets',[]):
        require(isinstance(asset,dict) and asset.get('role') in {'original','question_clean'},'素材需要 original 或 question_clean 角色')
        require(nonempty(asset.get('path')),'素材需要路径')
    if q.get('requires_image'):
        require(bool(q.get('assets')),'图形/版式题必须保留图像素材')
    for key in ['score','max_score']:
        value=q.get(key)
        require(value is None or type(value) in (int,float) and value>=0 and value<float('inf'),f'{key} 必须为非负有限数值或 null')
    if q.get('score') is not None and q.get('max_score') is not None: require(q['score']<=q['max_score'],'得分不可超过满分')
    return q

def store_file(root,source):
    source=Path(source).expanduser().resolve(); require(source.is_file(),f'找不到素材：{source}')
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    dest=root/'assets'/f'{digest}{source.suffix.lower()}'
    dest.parent.mkdir(exist_ok=True)
    if not dest.exists(): shutil.copy2(source,dest)
    return {'path':str(dest.relative_to(root)),'sha256':digest,'original_name':source.name}

def fingerprint(subject,text,content=None):
    norm=re.sub(r'\s+','',unicodedata.normalize('NFKC',text))
    if not norm and content:
        images=[b['asset']['url'] for b in content.get('blocks',[]) if b.get('type')=='image']
        if images: norm='image-content-v1:'+dumps(images)
    return hashlib.sha256((subject+'\n'+norm).encode()).hexdigest()

def ingest(root,db,data):
    require(data.get('schema_version')==1,'导入契约版本必须是 1')
    p=data['paper']; questions=data['questions']
    if 'grade' not in p:
        existing=db.execute('SELECT payload FROM papers WHERE id=?',(p.get('id'),)).fetchone()
        if existing:
            old=json.loads(existing['payload'])
            if 'grade' in old:p['grade']=old['grade']
        else:
            from student_profile import read_profile
            p['grade']=read_profile(root,db).get('grade')
    require(nonempty(p.get('id')) and nonempty(p.get('title')),'试卷 ID 和名称不能为空')
    require(p.get('subject') in SUBJECTS,'学科必须为 math/english/chinese'); date(p.get('date'))
    require(p.get('coverage') in {'full','partial'},'coverage 必须为 full/partial')
    require(p.get('assessment_mode') in {'teacher_marks','unmarked'},'判题模式无效')
    require(type(p.get('page_count')) is int and p['page_count']>0,'需要总页数')
    scanned=p.get('scanned_pages'); require(isinstance(scanned,list) and all(type(n) is int and 1<=n<=p['page_count'] for n in scanned),'逐页检查清单无效')
    require(len(set(scanned))==len(scanned),'重复扫描页码')
    require(p['coverage']!='full' or set(scanned)==set(range(1,p['page_count']+1)),'完整分析必须检查所有页面')
    require(isinstance(questions,list) and len(questions)>0,'需提供逐题记录')
    require(len({q['local_id'] for q in questions})==len(questions),'同卷题目 ID 重复')
    expected=p.get('expected_question_count')
    require(expected is None or type(expected) is int and expected>=len(questions),'预期题数无效')
    if p['coverage']=='full': require(expected==len(questions),'完整分析须核对原卷独立题目总数')
    sources=p.get('sources'); require(isinstance(sources,list) and sources,'必须保留原卷源文件')
    for q in questions:
        from pc_content import validate_fields, content_plain_text
        validate_fields(root,q)
        if q.get('content'): require(content_plain_text(q['content'])==q['text'],'题干文字与格式化内容不一致')
        from knowledge_selection import limit_knowledge,route_knowledge
        from knowledge_quality import reconcile_knowledge
        reconcile_knowledge(db,q,p['subject'],p.get('grade'))
        route_knowledge(db,q,p['subject'],p.get('grade'))
        limit_knowledge(db,q,p['subject'])
        validate_question(db,q,p['subject'],machine_import=True); require(q['page'] in scanned,'题目页码未列入已检查页')
        if p['assessment_mode']=='teacher_marks' and q['basis']=='model_reasoning':
            require(q['decision_status']=='pending','已批改试卷的模型验算仅作待复核提示')
    # Digest uses actual file contents, not temporary input paths.
    canonical=json.loads(dumps(data))
    for i,s in enumerate(sources): canonical['paper']['sources'][i]=hashlib.sha256(Path(s).expanduser().read_bytes()).hexdigest()
    for q in canonical['questions']:
        for a in q.get('assets',[]): a['path']=hashlib.sha256(Path(a['path']).expanduser().read_bytes()).hexdigest()
    digest=hashlib.sha256(dumps(canonical).encode()).hexdigest()
    row=db.execute('SELECT digest FROM papers WHERE id=?',(p['id'],)).fetchone()
    if row:
        require(row[0]==digest,'试卷 ID 已存在但内容不同；请用修订命令，或为另一场作答使用新 ID')
        return {'status':'already_imported','paper_id':p['id']}
    p['sources']=[store_file(root,s) for s in sources]
    for q in questions:
        q['assets']=[dict(store_file(root,a['path']),role=a['role']) for a in q.get('assets',[])]
    with db:
        db.execute('INSERT INTO papers VALUES(?,?,?,?)',(p['id'],digest,dumps(p),now()))
        for q in questions:
            qid=uid(); db.execute('INSERT INTO questions VALUES(?,?,?,?,?,?)',(qid,p['id'],q['local_id'],p['subject'],fingerprint(p['subject'],q['text'],q.get('content')),dumps(q)))
            event(db,qid,'import',None,q)
        event(db,p['id'],'paper_import',None,p)
    return {'status':'imported','paper_id':p['id'],'questions':len(questions)}

def edit_question(root,db,qid,patch,reason):
    require(nonempty(reason),'修订需要简短理由')
    row=db.execute('SELECT * FROM questions WHERE id=?',(qid,)).fetchone(); require(row,'题目不存在')
    old=json.loads(row['payload']); new=json.loads(row['payload'])
    allowed={'text','student_answer','corrected_answer','expected_answer','explanation','verdict','decision_status','evidence','evidence_level','basis','observed_error','attributions','score','max_score','note','assets','basis','content','sectionTitle','sharedContext','answerLayout','knowledgeIds','requires_image'}
    require(set(patch)<=allowed,'包含不可修订字段'); new.update(patch)
    if old.get('verdict')!='correct' and new.get('verdict')=='correct': clear_correct_attributions(new)
    from pc_content import validate_fields,content_plain_text
    validate_fields(root,new)
    if new.get('content'): require(content_plain_text(new['content'])==new['text'],'富题面文字与题干不一致')
    validate_question(db,new,row['subject'],historical=old,canonical_id=row['id'])
    if 'assets' in patch:
        new['assets']=[dict(store_file(root,a['path']),role=a['role']) for a in patch['assets']]
    with db:
        db.execute('UPDATE questions SET payload=?,fingerprint=? WHERE id=?',(dumps(new),fingerprint(row['subject'],new['text'],new.get('content')),qid))
        event(db,qid,'revision',old,{'question':new,'reason':reason})
    return {'status':'saved','question_id':qid}

def add_question(root,db,pid,q,expected_total=None):
    row=db.execute('SELECT payload FROM papers WHERE id=?',(pid,)).fetchone(); require(row,'试卷不存在')
    p=json.loads(row['payload']); old=json.loads(row['payload'])
    from pc_content import validate_fields, content_plain_text
    validate_fields(root,q)
    if q.get('content'): require(content_plain_text(q['content'])==q['text'],'题干文字与格式化内容不一致')
    validate_question(db,q,p['subject'])
    require(q['page'] in p['scanned_pages'],'补录题目必须在已扫描页内')
    require(not db.execute('SELECT id FROM questions WHERE paper_id=? AND local_id=?',(pid,q['local_id'])).fetchone(),'本卷已存在该题号，请修订原题')
    if p['assessment_mode']=='teacher_marks' and q['basis']=='model_reasoning': require(q['decision_status']=='pending','模型验算仅作待复核提示')
    total=db.execute('SELECT count(*) FROM questions WHERE paper_id=?',(pid,)).fetchone()[0]+1
    require(expected_total is None or type(expected_total) is int and expected_total>=total,'原卷总题数不能少于补录后题数')
    p['expected_question_count']=expected_total
    p['coverage']='full' if expected_total==total and len(p['scanned_pages'])==p['page_count'] else 'partial'
    q['assets']=[dict(store_file(root,a['path']),role=a['role']) for a in q.get('assets',[])]
    with db:
        qid=uid(); db.execute('INSERT INTO questions VALUES(?,?,?,?,?,?)',(qid,pid,q['local_id'],p['subject'],fingerprint(p['subject'],q['text'],q.get('content')),dumps(q)))
        db.execute('UPDATE papers SET payload=? WHERE id=?',(dumps(p),pid))
        event(db,qid,'add_question',None,q); event(db,pid,'coverage_revision',old,p)
    return {'status':'added','question_id':qid,'coverage':p['coverage']}

def review(db,qid,r):
    require(db.execute('SELECT id FROM questions WHERE id=?',(qid,)).fetchone(),'题目不存在')
    require(nonempty(r.get('id')),'复做记录需要稳定 ID，防止重复计数'); date(r.get('date'))
    require(r.get('result') in {'correct','wrong','partial','pending'},'复做结果无效')
    require(type(r.get('independent')) is bool,'必须注明是否独立无提示完成')
    require(nonempty(r.get('evidence')) and isinstance(r.get('answer'),str),'需保存本次作答及证据')
    q=json.loads(db.execute('SELECT payload FROM questions WHERE id=?',(qid,)).fetchone()[0])
    eligible={a.get('knowledge_point_id') for a in q.get('attributions',[]) if a.get('knowledge_point_id')}
    require(isinstance(r.get('knowledge_point_ids'),list) and bool(r['knowledge_point_ids']) and set(r['knowledge_point_ids'])<=eligible,'须明确此次复做验证的已关联知识点')
    existing=db.execute('SELECT question_id,payload FROM reviews WHERE id=?',(r['id'],)).fetchone()
    if existing:
        require(existing['question_id']==qid and existing['payload']==dumps(r),'复做 ID 已存在且内容不同')
        return {'status':'already_recorded'}
    with db:
        db.execute('INSERT INTO reviews VALUES(?,?,?,?)',(r['id'],qid,dumps(r),now())); event(db,qid,'review',None,r)
    return {'status':'recorded'}

def set_mastery(db,m):
    require(m.get('status') in MASTERY,'掌握状态无效')
    require(nonempty(m.get('reason')),'掌握状态需要证据说明')
    require(m.get('subject') in SUBJECTS,'学科无效')
    k=db.execute('SELECT subject,payload FROM knowledge WHERE id=?',(m.get('knowledge_point_id'),)).fetchone()
    require(k and k[0]==m['subject'],'知识点与学科不符')
    if m['subject']=='math':require(json.loads(k[1]).get('is_assessable') is True,'掌握记录必须关联现行数学末级知识点')
    date(m.get('date'))
    with db:
        mid=uid(); db.execute('INSERT INTO mastery VALUES(?,?,?,?,?,?)',(mid,m['subject'],m['knowledge_point_id'],dumps(m),now())); event(db,mid,'mastery',None,m)
    return {'status':'saved'}

def snapshot(db):
    ps={r['id']:dict(json.loads(r['payload']),id=r['id']) for r in db.execute('SELECT * FROM papers ORDER BY created DESC')}
    qs=[]; reviews=collections.defaultdict(list)
    for r in db.execute('SELECT * FROM reviews ORDER BY created'):
        reviews[r['question_id']].append(dict(json.loads(r['payload']),recorded_at=r['created']))
    for row in db.execute('SELECT * FROM questions ORDER BY rowid DESC'):
        q=dict(json.loads(row['payload']),id=row['id'],paper_id=row['paper_id'],subject=row['subject'],fingerprint=row['fingerprint'])
        q['reviews']=reviews[q['id']]; q['paper_title']=ps[q['paper_id']]['title']; q['date']=ps[q['paper_id']]['date']; qs.append(q)
    groups=collections.defaultdict(list); knowledge=collections.defaultdict(list)
    for q in qs:
        if q['verdict']=='wrong' and q['decision_status']=='confirmed' and not q.get('pc_excluded'):
            for a in q.get('attributions',[]):
                k=a.get('knowledge_point_id')
                if k:
                    knowledge[k].append(q)
                    if a['status']=='confirmed': groups[(q['subject'],k,a.get('error_cause_id'))].append(q)
    repeated=[]
    for (s,k,c),items in groups.items():
        unique={q['id']:q for q in items}
        if len(unique)>1: repeated.append({'subject':s,'knowledge_point_id':k,'error_cause_id':c,'count':len(unique),'paper_count':len({q['paper_id'] for q in unique.values()}),'question_ids':list(unique)})
    master=[]
    manual={}
    for r in db.execute('SELECT * FROM mastery ORDER BY created'): manual[r['kp_id']]=json.loads(r['payload'])
    for k in set(knowledge)|set(manual):
        items=list({q['id']:q for q in knowledge[k]}.values()); obs=[]
        for q in items:
            for r in q['reviews']:
                if r['independent'] and k in r['knowledge_point_ids'] and r['result']!='pending': obs.append(dict(r,fingerprint=q['fingerprint']))
        obs.sort(key=lambda r:(r['date'],r['recorded_at'])); last=obs[-3:]
        suggestion='pending'
        if last:
            suggestion='partially_mastered'
            if len(last)==3 and all(r['result']=='correct' for r in last) and len({r['date'] for r in last})>=2 and len({r['fingerprint'] for r in last})>=2: suggestion='mastered'
            if any(q['date']>last[-1]['date'] for q in items): suggestion='partially_mastered'
        row=db.execute('SELECT name,subject FROM knowledge WHERE id=?',(k,)).fetchone()
        master.append({'knowledge_point_id':k,'name':row['name'],'subject':row['subject'],'suggested_status':suggestion,'manual':manual.get(k),'independent_attempts':len(obs),'last_review_date':obs[-1]['date'] if obs else None})
    counts={}
    for s in SUBJECTS:
        items=[q for q in qs if q['subject']==s]
        counts[s]={'papers':sum(p['subject']==s for p in ps.values()),'questions':len(items),'wrong':sum(q['verdict']=='wrong' and q['decision_status']=='confirmed' and not q.get('pc_excluded') for q in items),'pending':sum(q['verdict']=='pending' or q['decision_status']=='pending' or q.get('pc_excluded',False) for q in items),'ungradable':sum(q['verdict']=='ungradable' for q in items),'repeated_patterns':sum(r['subject']==s for r in repeated)}
    for pid,p in ps.items():
        items=[q for q in qs if q['paper_id']==pid]
        confirmed=[q for q in items if q['decision_status']=='confirmed' and q['verdict'] in {'wrong','correct'} and not q.get('pc_excluded')]
        p['counts']={'recorded':len(items),'assessed':len(confirmed),'wrong':sum(q['verdict']=='wrong' for q in confirmed),'correct':sum(q['verdict']=='correct' for q in confirmed),'pending':sum(q['decision_status']=='pending' or q['verdict']=='pending' or q.get('pc_excluded',False) for q in items),'ungradable':sum(q['verdict']=='ungradable' for q in items)}
        p['error_rate']=p['counts']['wrong']/len(confirmed) if confirmed else None
        p['rate_scope']='整卷已确认且可判定题目' if p['coverage']=='full' else '仅已录入且已确认的可判定题目'
        p['calculated_score']=sum(q['score'] for q in items) if p['coverage']=='full' and all(q.get('score') is not None and q['decision_status']=='confirmed' for q in items) else None
        p['calculated_max_score']=sum(q['max_score'] for q in items) if p['coverage']=='full' and all(q.get('max_score') is not None for q in items) else None
    pc_practice_row=db.execute("SELECT value FROM meta WHERE key='pc_practice'").fetchone()
    pc_practice=json.loads(pc_practice_row[0]) if pc_practice_row else {}
    return {'pc_practice':pc_practice,'generated_at':now(),'subjects':SUBJECTS,'counts':counts,'papers':list(ps.values()),'questions':qs,'repeated':repeated,'mastery':master,'causes':CAUSES}

def export_docx(root,db,out,subject=None,paper=None,mode='analysis',question_ids=None):
    data=snapshot(db); qs=[q for q in data['questions'] if q['verdict']=='wrong' and q['decision_status']=='confirmed' and not q.get('pc_excluded') and (not subject or q['subject']==subject) and (not paper or q['paper_id']==paper)]
    if question_ids is not None:
        require(isinstance(question_ids,list) and bool(question_ids) and len(set(question_ids))==len(question_ids),'组卷题目列表为空或重复')
        by_id={q['id']:q for q in qs}
        require(all(qid in by_id for qid in question_ids),'组卷含不存在或未确认的错题，请重新核对')
        qs=[by_id[qid] for qid in question_ids]
    else: qs=list(reversed(qs))
    require(qs,'没有符合条件的已确认错题')
    from pc_word import export_questions
    return export_questions(root,qs,out,subject,mode)

def backup(root,db,out):
    out=Path(out).expanduser().resolve(); require(not out.exists(),'备份目标已存在，请换文件名'); out.parent.mkdir(parents=True,exist_ok=True)
    temp=root/f'.backup-{uid()}.sqlite3'
    try:
        dest=sqlite3.connect(temp); db.backup(dest); dest.close()
        with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
            z.write(temp,'study.sqlite3')
            for f in (root/'assets').glob('*'): z.write(f,'assets/'+f.name)
            z.writestr('manifest.json',dumps({'schema_version':1,'created':now(),'restore':'解压到新的空目录，再以 --root 指向该目录；保留旧档案直到核验通过。'}))
    finally: temp.unlink(missing_ok=True)
    return {'path':str(out)}

def serve(root,port):
    from pc_server import serve as serve_pc
    return serve_pc(root,port)


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--root',default=str(default_root())); sub=p.add_subparsers(dest='cmd',required=True)
    sub.add_parser('init'); sub.add_parser('snapshot')
    s=sub.add_parser('search'); s.add_argument('query'); s.add_argument('--subject',choices=SUBJECTS); s.add_argument('--limit',type=int,default=5)
    s=sub.add_parser('knowledge'); s.add_argument('id')
    s=sub.add_parser('import-paper'); s.add_argument('file')
    s=sub.add_parser('add-question'); s.add_argument('paper_id'); s.add_argument('file'); s.add_argument('--expected-total',type=int)
    s=sub.add_parser('edit-question'); s.add_argument('id'); s.add_argument('file'); s.add_argument('--reason',required=True)
    s=sub.add_parser('review'); s.add_argument('id'); s.add_argument('file')
    s=sub.add_parser('mastery'); s.add_argument('file')
    s=sub.add_parser('history'); s.add_argument('--question'); s.add_argument('--knowledge'); s.add_argument('--cause')
    s=sub.add_parser('export-word'); s.add_argument('out'); s.add_argument('--subject',choices=SUBJECTS); s.add_argument('--paper'); s.add_argument('--mode',choices=['analysis','practice'],default='analysis')
    s=sub.add_parser('backup'); s.add_argument('out')
    s=sub.add_parser('serve'); s.add_argument('--port',type=int,default=8765)
    s=sub.add_parser('stage-pages'); s.add_argument('files',nargs='+'); s.add_argument('--subject',choices=SUBJECTS); s.add_argument('--practice-paper'); s.add_argument('--date')
    sub.add_parser('requests'); sub.add_parser('pc-snapshot')
    s=sub.add_parser('recognition-result'); s.add_argument('group_id'); s.add_argument('file')
    s=sub.add_parser('practice-result'); s.add_argument('paper_id'); s.add_argument('file')
    a=p.parse_args(); root,db=connect(a.root)
    try:
        if a.cmd=='init': result={'root':str(root),'knowledge_points':init_kb(db)}
        elif a.cmd=='snapshot': result=snapshot(db)
        elif a.cmd=='knowledge':
            row=db.execute('SELECT * FROM knowledge WHERE id=?',(a.id,)).fetchone(); require(row,'知识点不存在，请先 init'); result=dict(row); result['payload']=json.loads(result['payload'])
        elif a.cmd=='search':
            terms=a.query.lower().split(); rows=db.execute('SELECT * FROM knowledge'+(' WHERE subject=?' if a.subject else ''),(a.subject,) if a.subject else ())
            found=[]
            for r in rows:
                if r['subject']=='math' and not json.loads(r['payload']).get('is_assessable'): continue
                raw=r['payload'].lower(); score=sum(3*(t in r['name'].lower())+raw.count(t) for t in terms)
                if score: found.append({'id':r['id'],'name':r['name'],'subject':r['subject'],'score':score})
            result=sorted(found,key=lambda r:-r['score'])[:max(1,min(a.limit,30))]
        elif a.cmd=='import-paper': result=ingest(root,db,read_json(a.file))
        elif a.cmd=='add-question': result=add_question(root,db,a.paper_id,read_json(a.file),a.expected_total)
        elif a.cmd=='edit-question': result=edit_question(root,db,a.id,read_json(a.file),a.reason)
        elif a.cmd=='review': result=review(db,a.id,read_json(a.file))
        elif a.cmd=='mastery': result=set_mastery(db,read_json(a.file))
        elif a.cmd=='history':
            data=snapshot(db); result=[q for q in data['questions'] if (not a.question or q['id']==a.question) and (not a.knowledge or any(t.get('knowledge_point_id')==a.knowledge for t in q.get('attributions',[]))) and (not a.cause or any(t.get('error_cause_id')==a.cause for t in q.get('attributions',[])))]
            if a.question: result={'questions':result,'events':[dict(r) for r in db.execute('SELECT * FROM events WHERE entity_id=? ORDER BY seq',(a.question,))]}
        elif a.cmd=='export-word': result=export_docx(root,db,a.out,a.subject,a.paper,a.mode)
        elif a.cmd=='backup': result=backup(root,db,a.out)
        elif a.cmd in {'stage-pages','requests','pc-snapshot','recognition-result','practice-result'}:
            import pc_store
            if a.cmd=='stage-pages':
                if a.practice_paper:
                    require(a.date,'复练卷需要实际作答日期 --date YYYY-MM-DD')
                    result=pc_store.stage_practice_pages(root,db,a.files,a.practice_paper,a.date)
                else:
                    require(a.subject,'原卷需要 --subject')
                    result=pc_store.stage_pages(root,db,a.files,a.subject)
            elif a.cmd=='recognition-result': result=pc_store.put_results(root,db,a.group_id,read_json(a.file))
            elif a.cmd=='practice-result': result=pc_store.put_practice_results(root,db,a.paper_id,read_json(a.file))
            elif a.cmd=='pc-snapshot': result=pc_store.read_archive(root,db)
            else:
                envelope=pc_store.read_archive(root,db); archive=envelope['archive']; rec=archive.get('recognition',{'pages':[],'groups':[]}); pages={p['id']:p for p in rec['pages']}
                result={'groups':[{**g,'pages':[{**pages[i],'source_path':str(pc_store.source_path(root,pages[i]['url']))} for i in g['pageIds']]} for g in rec['groups'] if g.get('requested') and not g.get('recognized')]}
        elif a.cmd=='serve': db.close(); return serve(root,a.port)
        print(dumps(result))
    except (ValueError,KeyError,TypeError,OSError,sqlite3.Error) as e:
        print(dumps({'error':str(e)}),file=sys.stderr); sys.exit(1)
    finally: db.close()
if __name__=='__main__': main()
