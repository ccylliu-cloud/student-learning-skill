"""Host boundary: WorkBuddy never launches the Codex subprocess."""
import portable_config
import codex_bridge_native as native
from codex_bridge_native import PHASES

MESSAGE = '当前安装使用 WorkBuddy 对话识别。请回到 WorkBuddy 当前对话，用 portable.py conversation-export 导出图片与提示词，实际看图后提交，再回网页人工复核。已保存的输出可用 conversation-retry 本地重试保存，无需重新看图。本次未调用 Codex。'


def require_codex():
    if portable_config.host() != 'codex':
        raise ValueError(MESSAGE)


def executable():
    require_codex()
    return native.executable()


def command(*args, **kwargs):
    require_codex()
    return native.command(*args, **kwargs)


class Runner(native.Runner):
    def _handoff(self,gid,key=None,task_id=None):
        import study,pc_store
        _,db=study.connect(self.root)
        try:
            with db:
                rec=pc_store.meta(db,'pc_recognition',{'groups':[]})
                group=next(g for g in rec['groups'] if g['id']==gid)
                if key:
                    task=group.get(key)
                    if not task or task['id']!=task_id:return False
                    task.update(status='awaiting_conversation',error=None)
                    task['progress'].update(phase='awaiting_conversation',message='圈选与请求已保存，请回到对话说“处理待识别试卷”。本次未启动后台模型。')
                else:
                    group.update(requested=False,runStatus='awaiting_conversation')
                    group.pop('error',None)
                group['conversationHandoff']={'mode':'supplement' if key=='supplementTask' else 'report' if key else 'original','message':'请求已保存，请回到当前对话说“处理待识别试卷”','taskId':task_id}
                pc_store.put_meta(db,'pc_recognition',rec)
                study.event(db,gid,'conversation_handoff',None,group['conversationHandoff'])
        finally:db.close()
        return True

    def submit(self, gid):
        if portable_config.host()=='codex':return super().submit(gid)
        return self._handoff(gid)

    def run(self, gid):
        require_codex()
        return super().run(gid)

    def _execute(self, *args, **kwargs):
        require_codex()
        return super()._execute(*args, **kwargs)

    def submit_supplement(self,gid,task_id):
        if portable_config.host()=='codex':return super().submit_supplement(gid,task_id)
        return self._handoff(gid,'supplementTask',task_id)

    def submit_report(self,gid,task_id):
        if portable_config.host()=='codex':return super().submit_report(gid,task_id)
        return self._handoff(gid,'reportTask',task_id)

    def recover(self):
        if portable_config.host() == 'codex':
            return super().recover()
        import study, pc_store
        _, db = study.connect(self.root)
        try:
            groups = pc_store.meta(db, 'pc_recognition', {'groups': []})['groups']
        finally:
            db.close()
        for group in groups:
            for key, method in (('reportTask', self.submit_report), ('supplementTask', self.submit_supplement)):
                task = group.get(key)
                if task and task.get('status') in ('queued', 'running'):
                    method(group['id'], task['id'])
            if group.get('requested') or group.get('runStatus') in ('queued', 'running'):
                self._handoff(group['id'])
