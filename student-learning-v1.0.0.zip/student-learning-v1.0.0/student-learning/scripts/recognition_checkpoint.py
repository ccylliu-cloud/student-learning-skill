"""Local recovery checkpoints; never call a model or reuse changed source material."""
import hashlib,json
from pathlib import Path
import pc_store as s
from recognition_contract import _practice

def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def context(root,db,group):
    pages={p['id']:p for p in s.meta(db,'pc_recognition',{'pages':[]})['pages']}
    data={k:group.get(k) for k in ('id','kind','title','subject','grade','date','resultDate','practicePaperId','pageIds')}
    data['sources']=[{'id':pid,'url':pages[pid]['url'],'sha256':hashlib.sha256(s.source_path(root,pages[pid]['url']).read_bytes()).hexdigest()} for pid in group['pageIds']]
    if group.get('kind')=='practice':
        paper,canonical=_practice(db,group);data['practice']={'paper':paper,'canonical':canonical}
    return {'version':1,'group_id':group['id'],'fingerprint':digest(data),'context':data}

def write(path,data):
    path=Path(path);temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)

def ready(work,identity):
    output=Path(work)/'result.json'
    write(Path(work)/'result-ready.json',{**identity,'result_sha256':hashlib.sha256(output.read_bytes()).hexdigest()})

def find(root,identity):
    """Only server-attested completed outputs from an identical trusted input."""
    matches=[]
    for marker in (Path(root)/'drafts').glob('recognition-*/result-ready.json'):
        if marker.is_symlink() or marker.parent.is_symlink():continue
        try:
            data=json.loads(marker.read_text(encoding='utf-8'));result=marker.parent/'result.json'
            if data.get('group_id')!=identity['group_id'] or data.get('fingerprint')!=identity['fingerprint']:continue
            if result.is_symlink() or result.stat().st_size>15_000_000:continue
            if data.get('result_sha256')!=hashlib.sha256(result.read_bytes()).hexdigest():continue
            try:
                value=json.loads(result.read_text(encoding='utf-8'))
                if isinstance(value,dict) and value.get('status') in ('image_blocked','blocked'):continue
            except ValueError:pass  # Malformed complete JSON remains available for local repair.
            matches.append((marker.stat().st_mtime_ns,result))
        except (ValueError,OSError):continue
    return max(matches,key=lambda item:item[0])[1] if matches else None

def same_input(root,db,gid,identity,request_id):
    group=next((g for g in s.meta(db,'pc_recognition',{'groups':[]})['groups'] if g['id']==gid),None)
    s.require(group and not group.get('recognized') and group.get('requested') and group.get('requestId')==request_id,'请求已变更或已有结果，旧识别不会覆盖人工记录')
    s.require(context(root,db,group)['fingerprint']==identity['fingerprint'],'原图或试卷信息已变更，已停止保存旧结果；请对当前试卷重新识别')
    return group

def failure_message(error,has_result):
    from vision_guard import blocked_error,BLOCKED_MESSAGE
    message=str(error)
    if has_result:
        return '识别内容已保留，保存未完成。原因：'+message[:220]+'。请先点“重试保存”（不重新调用AI）；若仍失败，将此提示发回对话修复。不要反复重读整卷。'
    if blocked_error(message) or message==BLOCKED_MESSAGE:
        return '当前识别模型无法读取图片，尚未生成结果。请在支持看图的 Codex 中处理；无需因此重拍试卷。'
    if '未找到 Codex' in message:return '未找到本机 Codex 程序。请在 Codex 中重新打开学习记录册后重试；无需重拍图片。'
    return message[:400]


def execution_failure(metrics):
    raw=metrics.get('failure_message','').lower()
    if 'not supported' in raw or 'model' in raw and 'not found' in raw:
        return '当前模型不受本机识别账号支持，未生成结果。请把此提示发回对话修正模型配置；不用重复识别或重拍。'
    if any(word in raw for word in ('usage limit','rate limit','quota','usage_limit')):
        return 'Codex 当前识别额度受限。请等待额度恢复后再试；反复点击不会解决，无需重拍。'
    if any(word in raw for word in ('unauthorized','authentication','401','login')):
        return 'Codex 登录已失效或未完成。请先在 Codex 重新登录，再回到此处重试；无需重拍。'
    return '连接中断或服务未完整返回结果。请先确认 Codex 能正常响应，再重试识别；原图已保留，无需重拍。'
