"""Stage-specific view of the unified mathematics release."""
from math_unified import records_for_stage
KB_ID='math-highschool-knowledge'
def records(skill):
    return records_for_stage(skill,'高中')
