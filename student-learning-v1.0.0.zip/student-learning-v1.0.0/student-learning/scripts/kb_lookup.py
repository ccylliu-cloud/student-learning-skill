#!/usr/bin/env python3
"""Bounded knowledge lookup for the read-only recognition worker (no migrations)."""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
import sqlite3

MAX_IDS = 24
MAX_OUTPUT_CHARS = 100000
SEMANTIC_FIELDS = (
    'assessment_id', 'display_name', 'is_assessable', 'active', 'path_ids', 'path_names',
    'rules', 'shared_card_context', 'prerequisite_references', 'transfer_references',
    'related_assessment_ids', 'owner_card_id', 'sources',
    'rule', 'assessment_policy', 'common_errors', 'confusable_ids', 'related_grammar_ids',
    'version', 'kb_version', 'difference_ids', '典型题型',
    'school_stages', 'stage_basis', 'difficulty', 'highschool_supplements',
    'prerequisite_ids', 'extends_ids',
    'knowledge_base_id', 'core_concepts_rules', 'typical_problem_types', 'strategies',
    'common_pitfalls', 'error_attribution', 'prerequisites', 'transferable_to',
    'problem_keywords', 'curriculum_role', 'review_status', 'release_ready', 'release_scope',
    'domain', 'module', 'variants',
    'library_version', 'level', 'category_id', 'category', 'type', 'aliases',
    'definition', 'include', 'exclude', 'observable_criteria', 'related_points',
    'stage', 'stage_profiles', 'stage_retrieval_enabled', 'retrieval_priority',
    'definition_basis', 'boundary_basis', 'criteria_basis', 'enabled_for_matching',
    'teaching_rules_status', 'validation_status', 'source_refs', 'tags',
    'classification_basis', 'quality_issue_ids', 'status', 'node_type', 'content_status',
    '核心概念/规则', '常用解法/策略', '易错点', '常见错因', 'diagnosis_hint',
    '内容证据', '规则来源性质', 'source_field_policy', 'auto_training_eligible',
)


def details(db, subject, ids, *, bounded=True):
    """SELECT only; retain full semantic rules and restrictions, omit source inventories."""
    if subject not in ('math', 'english', 'chinese'):
        raise ValueError('学科无效')
    if not isinstance(ids, list) or not all(isinstance(k, str) and k for k in ids):
        raise ValueError('知识点ID必须为文字数组')
    ids = list(dict.fromkeys(ids))
    if bounded and not 1 <= len(ids) <= MAX_IDS:
        raise ValueError(f'每批只允许1至{MAX_IDS}个明确ID，禁止倾倒全库')
    result = []
    for kid in ids:
        requested=kid
        if subject=='math':
            from math_unified import binding
            mapped=binding(Path(__file__).resolve().parents[1],kid)
            if mapped and mapped['status']=='resolved':kid=mapped['assessment_id']
            elif mapped:
                result.append({'requested_id':requested,**mapped})
                continue
        row = db.execute('SELECT id,name,payload FROM knowledge WHERE id=? AND subject=?', (kid, subject)).fetchone()
        if row is None:
            raise ValueError(f'知识点不存在或学科不符：{kid}')
        raw = json.loads(row[2])
        item = {'id': row[0], 'name': row[1], **{k: raw[k] for k in SEMANTIC_FIELDS if k in raw}}
        if raw.get('assessment_id'):
            item.pop('core_concepts_rules',None)  # Same rules already exposed once, without doubling tokens.
        if requested!=kid:item['requested_id']=requested
        if raw.get('knowledge_base_id')in ('math-k12-knowledge','math-highschool-knowledge'):
            item['examples']=raw.get('examples',[])
        elif 'examples' in raw:
            item['examples'] = [{k: e[k] for k in ('text', 'use') if k in e} if isinstance(e, dict) else e for e in raw['examples']]
        result.append(item)
    if bounded and len(json.dumps(result, ensure_ascii=False)) > MAX_OUTPUT_CHARS:
        raise ValueError('本批知识详情过长，请拆成更小的ID批次；不会截断规则')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--subject', choices=('math', 'english', 'chinese'), required=True)
    parser.add_argument('--ids', nargs='+', required=True)
    args = parser.parse_args()
    path = Path(args.root).expanduser().resolve() / 'study.sqlite3'
    # URI mode=ro refuses missing archives; never call study.connect/init_kb.
    db = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    try:
        db.execute('PRAGMA query_only=ON')
        result = details(db, args.subject, args.ids)
        print(json.dumps(result, ensure_ascii=False, separators=(',', ':'), allow_nan=False))
    finally:
        db.close()


if __name__ == '__main__':
    main()
