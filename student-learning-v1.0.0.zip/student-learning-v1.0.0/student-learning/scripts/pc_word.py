"""Print reviewed questions as a local exercise sheet; never changes the archive."""
from __future__ import annotations

import copy
import datetime as dt
import io
import math
import re
from collections import OrderedDict
from pathlib import Path
from urllib.parse import unquote, urlparse

BODY_PT = 12
META_PT = 10.5
FONT = 'Arial Unicode MS'
_LATEX = re.compile(r'\\(?:frac|sqrt|begin|sum|int|over|left|right|(?:sub|super)script)\b|\$[^$]+\$')
_SECTION = re.compile(r'^(?:Read and (?:write|choose)|Rewrite the following sentences as required|Choose the (?:best|correct) answer|Fill in the blanks|Complete the (?:sentences|passage)|Translate the following sentences)(?:\s*[（(][^（）()\n]*[）)])?\s*[.：:]?\s*$', re.I)


def _plain(block):
    return ''.join(r.get('text', '') for r in block.get('runs', [])) if block.get('type') == 'paragraph' else ''


def _legacy_paragraph(text):
    """Convert only explicit, uniquely located underline annotations, not guesses."""
    match = re.search(r'[；;]\s*划线部分[：:]\s*([^）)\n]+)(?=[）)])', text)
    if not match:
        return {'type': 'paragraph', 'runs': [{'text': text}]}
    target = match.group(1).strip()
    instruction = text.rfind('（', 0, match.start())
    if instruction < 0:
        instruction = text.rfind('(', 0, match.start())
    prefix = text[:instruction] if instruction >= 0 else ''
    if not target or prefix.count(target) != 1:
        return {'type': 'paragraph', 'runs': [{'text': text}]}
    clean = text[:match.start()] + text[match.end():]
    start = prefix.index(target)
    return {'type': 'paragraph', 'runs': [
        {'text': clean[:start]}, {'text': target, 'underline': True},
        {'text': clean[start + len(target):]},
    ]}


def _layout(q, text, section):
    existing = q.get('answerLayout')
    if existing is not None:
        return copy.deepcopy(existing)
    # Explicit writing spaces always take precedence over inference.
    if re.search(r'_{2,}|＿{2,}|[（(]\s*[）)]|[□]{2,}', text):
        return {'kind': 'inline'}
    if re.search(r'rewrite|改写|改为|对划线部分提问|连词成句|翻译', section + '\n' + text, re.I):
        return {'kind': 'lines', 'lines': 2}
    if re.search(r'竖式|递等式|脱式|计算|解方程|求值|简便运算', section + '\n' + text):
        return {'kind': 'space', 'heightCm': 3}
    if q.get('subject') == 'math':
        return {'kind': 'space', 'heightCm': 4}
    if re.search(r'choose|选择|判断|填空', section + '\n' + text, re.I):
        return {'kind': 'inline'}
    return {'kind': 'lines', 'lines': 2}


def normalize_legacy_content(q):
    """Return lossless presentation fields. Caller decides whether to persist them."""
    section = (q.get('sectionTitle') or '').strip()
    content = copy.deepcopy(q.get('content'))
    if content is None:
        lines = str(q.get('text') or '').splitlines()
        if lines and len(lines) > 1 and ((section and lines[0].strip() == section) or (not section and _SECTION.match(lines[0].strip()))):
            section = section or lines[0].strip()
            lines = lines[1:]
        content = {'version': 1, 'blocks': [_legacy_paragraph(line) for line in lines]}
    else:
        blocks = content.get('blocks', []) if isinstance(content, dict) else []
        if len(blocks) > 1 and blocks[0].get('type') == 'paragraph':
            first = _plain(blocks[0]).strip()
            if (section and first == section) or (not section and _SECTION.match(first)):
                section = section or first
                content['blocks'] = blocks[1:]
    text = '\n'.join(_plain(b) for b in content.get('blocks', [])) if isinstance(content, dict) else ''
    return {'content': content, 'sectionTitle': section, 'answerLayout': _layout(q, text, section)}


def _asset_path(root, asset):
    root = Path(root).expanduser().resolve()
    if not isinstance(asset, dict):
        raise ValueError('题图资料格式不正确，请重新粘贴图片')
    if asset.get('url'):
        parsed = urlparse(asset['url'])
        if parsed.scheme or parsed.netloc or parsed.query or parsed.fragment or not parsed.path.startswith('/files/'):
            raise ValueError('题图必须保存到本地档案，请重新粘贴图片')
        path = root / 'assets' / unquote(parsed.path[len('/files/'):])
    elif asset.get('path'):
        path = root / asset['path']
    else:
        raise ValueError('题图没有可用文件，请重新粘贴图片')
    path = path.resolve()
    if not path.is_relative_to((root / 'assets').resolve()) or not path.is_file():
        raise ValueError('找不到本地题图，请重新粘贴或补充图片')
    return path


def _image_data(root, asset):
    from PIL import Image, ImageOps
    path = _asset_path(root, asset)
    if path.suffix.lower() not in {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.tif', '.tiff'}:
        raise ValueError('题图需为 PNG、JPEG 或其他可读图片；PDF 或矢量图请先转换为 PNG')
    try:
        with Image.open(path) as original:
            image = ImageOps.exif_transpose(original)
            image.load()
            if image.width < 1 or image.height < 1:
                raise ValueError('empty')
            output = io.BytesIO()
            image.convert('RGBA' if 'A' in image.getbands() else 'RGB').save(output, format='PNG')
            output.seek(0)
            return output, image.width, image.height
    except (OSError, ValueError) as exc:
        raise ValueError('题图无法读取，请重新粘贴完整图片') from exc


def _images(q, content, mode):
    blocks = [b for b in content.get('blocks', []) if b.get('type') == 'image']
    if blocks:
        return blocks, []
    clean = [a for a in q.get('assets', []) if a.get('role') == 'question_clean']
    chosen = clean or ([a for a in q.get('assets', []) if a.get('role') == 'original'] if mode == 'analysis' else [])
    return [], chosen


def _validate(q, root, mode):
    if not isinstance(q.get('sectionTitle') or '', str) or not isinstance(q.get('sharedContext') or '', str):
        raise ValueError('大题标题和共用材料必须为文字')
    normalized = normalize_legacy_content(q)
    content = normalized['content']
    if not isinstance(content, dict) or content.get('version') != 1 or not isinstance(content.get('blocks'), list):
        raise ValueError('题面格式不正确，请重新保存题干')
    text = []
    meaningful = False
    for block in content['blocks']:
        if not isinstance(block, dict):
            raise ValueError('题面段落格式不正确')
        if block.get('type') == 'paragraph':
            runs = block.get('runs')
            if not isinstance(runs, list) or any(not isinstance(r, dict) or not isinstance(r.get('text'), str) for r in runs):
                raise ValueError('题面文字格式不正确')
            value = _plain(block)
            text.append(value)
            meaningful = meaningful or bool(value.strip())
        elif block.get('type') == 'image':
            _image_data(root, block.get('asset'))
            meaningful = True
            width = block.get('widthCm', 12)
            if type(width) not in (int, float) or not math.isfinite(width) or width <= 0:
                raise ValueError('题图宽度应为大于零的数字')
        else:
            raise ValueError('题面包含尚未支持的段落，请转换为文字或题图后导出')
    if not meaningful:
        raise ValueError('题干为空，请补齐题干或题图')
    image_blocks, assets = _images(q, content, mode)
    if mode=='practice' and q.get('diagramReviewRequired'):
        raise ValueError('机器重建题图尚未对照原图核对，请先核对尺寸、标注与图形条件再生成练习卷')
    if q.get('requires_image') and not image_blocks and not assets:
        raise ValueError('缺少可用于练习的完整题图，请在题干中补图；如已确认纯文字足以表达本题，可取消“需要题图”')
    for asset in assets:
        _image_data(root, asset)
    texts = [*text, normalized['sectionTitle'], str(q.get('sharedContext') or '')]
    if mode == 'analysis':
        texts.extend(str(q.get(k) or '') for k in ['student_answer', 'corrected_answer', 'expected_answer', 'explanation', 'evidence'])
    if _LATEX.search('\n'.join(texts)):
        raise ValueError('含有尚未排版的数学公式，请先将公式转换为已核对的题图或规范数学文字')
    layout = normalized['answerLayout']
    if not isinstance(layout, dict) or layout.get('kind') not in {'inline', 'lines', 'space'}:
        raise ValueError('作答位置设置无效，请选择题内填空、横线或留白')
    if layout['kind'] == 'lines' and (type(layout.get('lines', 2)) is not int or not 1 <= layout.get('lines', 2) <= 12):
        raise ValueError('作答横线数应为 1 至 12 行')
    if layout['kind'] == 'space' and (type(layout.get('heightCm', 3)) not in (int, float) or not math.isfinite(layout.get('heightCm', 3)) or not 1 <= layout.get('heightCm', 3) <= 15):
        raise ValueError('作答留白高度应为 1 至 15 厘米')
    return normalized


def check_questions(root, qs, mode='practice'):
    """Return all blocking issues; never silently omit an individual question."""
    issues = []
    for index, q in enumerate(qs, 1):
        try:
            _validate(q, root, mode)
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            issues.append({'questionId': q.get('id', ''), 'number': q.get('number') or str(index), 'message': str(exc)})
    return issues


def _font(run, size=BODY_PT, bold=None):
    from docx.shared import Pt, RGBColor
    from docx.oxml.ns import qn
    run.font.name = FONT
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor(0, 0, 0)
    if bold is not None:
        run.bold = bold
    fonts = run._element.get_or_add_rPr().get_or_add_rFonts()
    for key in ['ascii', 'hAnsi', 'eastAsia', 'cs']:
        fonts.set(qn('w:' + key), FONT)
    return run


def _paragraph(doc, text='', size=BODY_PT, bold=False, after=4, keep=False):
    from docx.shared import Pt
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.keep_with_next = keep
    p.paragraph_format.widow_control = True
    if text:
        _font(p.add_run(text), size, bold)
    return p


def _add_image(doc, root, asset, width=12):
    from docx.shared import Cm
    stream, w, h = _image_data(root, asset)
    width = min(float(width), 17, 10.5 * w / h)
    p = _paragraph(doc, after=5)
    _font(p.add_run()).add_picture(stream, width=Cm(width))
    return p


def _blank_positions(text, context):
    """Only enlarge writable placeholders in fill-in arithmetic, not shape labels."""
    if not re.search(r'填|横线|运算符|[＿_]{2,}', context):
        return set()
    positions = set()
    for match in re.finditer(r'[□○〇]', text):
        index = match.start()
        # Instructions such as “在○内填…” retain ordinary body typography.
        left = text[:index].rstrip()[-1:]
        right = text[index + 1:].lstrip()[:1]
        if re.search(r'[\u4e00-\u9fffA-Za-z]', left + right):
            continue
        clause_start = max(text.rfind(c, 0, index) for c in '\n。；;：:') + 1
        ends = [p for c in '\n。；;：:' if (p := text.find(c, index)) >= 0]
        clause = text[clause_start:min(ends) if ends else len(text)]
        if re.search(r'[▲△■●◆◇]|圆心|直径|半径|图形', clause):
            continue
        if match.group() == '□':
            if re.search(r'[=＝×÷+＋−－*/]', clause):
                positions.add(index)
        elif re.search(r'[0-9＿_]', left + right):
            positions.add(index)
    return positions


def _add_writing_blank(paragraph, symbol):
    """A fixed physical size survives font substitution and A4 Word/PDF export."""
    from PIL import Image, ImageDraw
    from docx.shared import Mm
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    width_mm, height_mm = (12, 8) if symbol == '□' else (8, 8)
    # 600 dpi-equivalent primitives; no photo or student asset is altered.
    scale = 24
    image = Image.new('RGBA', (width_mm * scale, height_mm * scale), (255, 255, 255, 0))
    draw = ImageDraw.Draw(image)
    bounds = (3, 3, image.width - 4, image.height - 4)
    if symbol == '□':
        draw.rectangle(bounds, outline='black', width=4)
    else:
        draw.ellipse(bounds, outline='black', width=4)
    stream = io.BytesIO()
    image.save(stream, format='PNG')
    stream.seek(0)
    run = _font(paragraph.add_run())
    picture = run.add_picture(stream, width=Mm(width_mm), height=Mm(height_mm))
    picture._inline.docPr.set('descr', symbol + (' 数字填写框' if symbol == '□' else ' 运算符填写圈'))
    # Lower the inline picture so its centre aligns with the surrounding 12pt text.
    position = OxmlElement('w:position')
    position.set(qn('w:val'), '-14')
    run._element.get_or_add_rPr().append(position)


def _add_content(doc, root, content, subject=None, section=''):
    context = section + '\n' + '\n'.join(_plain(b) for b in content['blocks'])
    paragraphs = []
    for b in content['blocks']:
        if b['type'] == 'image':
            paragraphs.append(_add_image(doc, root, b['asset'], b.get('widthCm', 12)))
        else:
            p = _paragraph(doc)
            blanks = _blank_positions(_plain(b), context) if subject in {'math', '数学'} else set()
            offset = 0
            for item in b['runs']:
                value = item['text']
                start = 0
                for index in range(len(value) + 1):
                    if index < len(value) and offset + index not in blanks:
                        continue
                    if index > start:
                        r = _font(p.add_run(value[start:index]))
                        r.underline = bool(item.get('underline'))
                        r.bold = bool(item.get('bold'))
                        r.italic = bool(item.get('italic'))
                    if index < len(value):
                        _add_writing_blank(p, value[index])
                    start = index + 1
                offset += len(value)
            paragraphs.append(p)
    return paragraphs


def _answer_space(doc, layout):
    from docx.shared import Pt, Cm
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    paragraphs = []
    if layout['kind'] == 'lines':
        for _ in range(layout.get('lines', 2)):
            p = _paragraph(doc, ' ', after=7)
            p.paragraph_format.line_spacing = Pt(19)
            p.paragraph_format.right_indent = Cm(.2)
            borders = OxmlElement('w:pBdr')
            bottom = OxmlElement('w:bottom')
            for key, value in [('val', 'single'), ('sz', '4'), ('color', '888888'), ('space', '1')]:
                bottom.set(qn('w:' + key), value)
            borders.append(bottom)
            between = copy.deepcopy(bottom)
            between.tag = qn('w:between')
            borders.append(between)
            p._p.get_or_add_pPr().append(borders)
            paragraphs.append(p)
    elif layout['kind'] == 'space':
        # A single modest empty paragraph preserves the task's working space.
        p = _paragraph(doc, ' ', after=0)
        p.paragraph_format.line_spacing = Pt(float(layout.get('heightCm', 3)) / 2.54 * 72)
        paragraphs.append(p)
    return paragraphs


def export_questions(root, qs, out, subject=None, mode='practice'):
    """Export selected canonical question payloads in deterministic section order."""
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    if mode not in {'practice', 'analysis'}:
        raise ValueError('导出类型无效')
    if not qs:
        raise ValueError('没有符合条件的已确认错题')
    issues = check_questions(root, qs, mode)
    if issues:
        raise ValueError('无法生成 Word：' + '；'.join(f'第 {i["number"]} 题：{i["message"]}' for i in issues))
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.top_margin, sec.bottom_margin = Cm(1.8), Cm(1.8)
    sec.left_margin, sec.right_margin = Cm(2), Cm(2)
    sec.header_distance = Cm(.75)
    for style in doc.styles:
        if style.type == 1:
            style.font.name = FONT
            style.font.color.rgb = RGBColor(0, 0, 0)
            fonts = style.element.get_or_add_rPr().get_or_add_rFonts()
            for key in list(fonts.attrib):
                del fonts.attrib[key]
            for key in ['ascii', 'hAnsi', 'eastAsia', 'cs']:
                fonts.set(qn('w:' + key), FONT)
    normal = doc.styles['Normal']
    normal.font.size = Pt(BODY_PT)
    normal.paragraph_format.line_spacing = 1.25
    normal.paragraph_format.space_after = Pt(4)
    header = sec.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    _font(header.add_run(dt.date.today().isoformat()))
    groups = OrderedDict()
    for index, q in enumerate(qs):
        normalized = normalize_legacy_content(q)
        section = normalized['sectionTitle']
        shared = q.get('sharedContext') or ''
        # Different passage/context content never shares a heading group.
        key = (section, shared) if section else ('', index)
        groups.setdefault(key, []).append((q, normalized))
    number = 0
    for key, members in groups.items():
        section = key[0]
        shared = members[0][0].get('sharedContext') or ''
        if section:
            p = _paragraph(doc, section, bold=True, after=7, keep=True)
            p.paragraph_format.space_before = Pt(8 if number else 0)
        if shared:
            _paragraph(doc, shared, after=7, keep=True)
        for q, normalized in members:
            number += 1
            original = str(q.get('number') or '')
            metadata = f'{number}.  原题 {original}' if original else f'{number}.'
            if q.get('date'):
                metadata += f'  ·  {q["date"]}'
            start = _paragraph(doc, metadata, META_PT, after=4, keep=True)
            parts = [start, *_add_content(doc, root, normalized['content'], q.get('subject') or subject, normalized['sectionTitle'])]
            _, assets = _images(q, normalized['content'], mode)
            for asset in assets:
                parts.append(_add_image(doc, root, asset))
            if mode == 'practice':
                parts.extend(_answer_space(doc, normalized['answerLayout']))
            else:
                from study import CAUSES
                for label, field in [('原始作答', 'student_answer'), ('订正作答', 'corrected_answer'), ('参考答案', 'expected_answer'), ('卷面证据', 'evidence'), ('解析', 'explanation')]:
                    if q.get(field):
                        parts.append(_paragraph(doc, f'{label}：{q[field]}'))
                for attribution in q.get('attributions', []):
                    cause = CAUSES.get(attribution.get('error_cause_id'), {}).get('name', '待确认')
                    status = {'confirmed': '已确认', 'provisional': '暂定', 'pending': '待确认'}.get(attribution.get('status'), '待确认')
                    parts.append(_paragraph(doc, f'知识点：{attribution.get("knowledge_name", "待映射")}｜错因：{cause}（{status}）\n依据：{attribution.get("evidence", "待确认")}'))
            # Keep ordinary short questions together. Long passages remain pageable.
            estimate = sum(max(1, math.ceil(len(p.text) / 65)) for p in parts)
            has_images = any(b.get('type') == 'image' for b in normalized['content']['blocks']) or bool(assets)
            if estimate <= 16 and not has_images and mode == 'practice':
                for p in parts[:-1]:
                    p.paragraph_format.keep_with_next = True
            elif len(parts) > 2:
                parts[1].paragraph_format.keep_with_next = True
            parts[-1].paragraph_format.keep_with_next = False
            parts[-1].paragraph_format.space_after = Pt(11)
    out = Path(out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    return {'path': str(out), 'questions': len(qs), 'mode': mode, 'render_check_required': True}
