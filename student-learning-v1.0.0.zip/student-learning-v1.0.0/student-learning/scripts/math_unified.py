"""Hash-checked, standalone assessment records; no source files or student writes."""
import hashlib,json
from pathlib import Path
from functools import lru_cache

@lru_cache(maxsize=4)
def load(skill):
    folder=Path(skill)/'references/knowledge/math-unified'
    manifest=json.loads((folder/'release_manifest.json').read_text(encoding='utf-8'))
    data={}
    for name in ('assessment_points.json','binding_index.json','hierarchy.json'):
        content=(folder/name).read_bytes()
        if hashlib.sha256(content).hexdigest()!=manifest['files'][name]['sha256']:
            raise ValueError('数学知识包内容校验失败：'+name)
        data[name]=json.loads(content)
    points=data['assessment_points.json']; hierarchy=data['hierarchy.json']
    leaves={n['knowledge_point_id'] for n in hierarchy if n['is_assessable']}
    if set(points)!=leaves or len(points)!=manifest['counts']['after']['assessment_points']:
        raise ValueError('数学知识点层级或数量不一致')
    return points,data['binding_index.json'],hierarchy,manifest

def records_for_stage(skill,stage):
    points,_,_,manifest=load(str(skill)); result=[]
    kb='math-k12-knowledge' if stage=='小初' else 'math-highschool-knowledge'
    for kid,point in points.items():
        if point['stage']!=stage:continue
        path=point['path_names']; ids=point['path_ids']; context=point['shared_card_context']
        result.append({**point,'knowledge_point_id':kid,'name':point['display_name'],
            'knowledge_base_id':kb,'kb_version':manifest['version'],'active':True,
            'domain':path[0],'module':path[1], 'parent_id':ids[-2],
            'catalog_domain_id':ids[0],'catalog_topic_id':ids[1],
            'core_concepts_rules':point['rules'],
            'typical_problem_types':context.get('typical_problem_types',[]),
            'common_pitfalls':context.get('common_pitfalls',[]),
            'release_scope':{'release_ready':False,'pending_source_review':manifest['counts']['pending_source_review'],
              'review_definition':'正文核对与内部审校；不代表外部教师审校或学生实测。'}})
    return result,manifest['files']['assessment_points.json']['sha256']

def binding(skill,kid):
    return load(str(skill))[1].get(kid)
