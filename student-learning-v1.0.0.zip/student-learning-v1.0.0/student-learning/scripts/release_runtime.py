"""Release identity and explicit, installation-scoped recognition configuration."""
import hashlib,json,os,platform,sys,importlib.metadata
from pathlib import Path
VERSION='1.0.0'
SKILL=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def settings():
    path=SKILL/'runtime/recognition.json'
    saved=json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {}
    model=os.environ.get('STUDENT_LEARNING_MODEL') or saved.get('model') or 'gpt-6-astra'
    effort=os.environ.get('STUDENT_LEARNING_REASONING') or saved.get('reasoning_effort') or 'medium'
    if not isinstance(model,str) or not model.strip() or any(c.isspace() for c in model):raise ValueError('识别模型配置无效')
    if effort not in ('low','medium','high','xhigh','max','ultra'):raise ValueError('推理设置无效')
    return {'model':model,'reasoning_effort':effort,'source':'environment' if os.environ.get('STUDENT_LEARNING_MODEL') or os.environ.get('STUDENT_LEARNING_REASONING') else 'installation' if saved else 'release_default'}
def dependency_versions():
    result={}
    for name in ('Pillow','python-docx','pillow-heif'):
        try:result[name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:result[name]=None
    return result
def snapshot():
    files=('SKILL.md','scripts/recognition_contract.py','scripts/selective_recognition.py','scripts/evidence_contract.py','scripts/codex_bridge_native.py')
    import portable_config
    host=portable_config.host()
    kb=json.loads((SKILL/'knowledge-integration.json').read_text(encoding='utf-8')) if (SKILL/'knowledge-integration.json').exists() else {}
    return {'version':VERSION,'host':host,'recognition':{**settings(),'mode':'codex-cli' if host=='codex' else 'conversation'},'capabilities':{'automaticRecognition':host=='codex','conversationRecognition':True},'knowledge':kb,'dependencies':dependency_versions(),'python':platform.python_version(),'platform':sys.platform,'hashes':{f:sha(SKILL/f) for f in files if (SKILL/f).is_file()}}
def stage_record(folder,prompt,files,command=None):
    from PIL import Image,ImageOps
    entries=[]
    for i,p in enumerate(files,1):
        with Image.open(p) as image:
            oriented=ImageOps.exif_transpose(image)
            entries.append({'page':i,'sha256':sha(p),'encoded_size':list(image.size),'oriented_size':list(oriented.size),'exif_orientation':image.getexif().get(274,1)})
    result={**snapshot(),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'images':entries,'command':command,'response_model':None,'response_model_note':'实际返回身份未提供时保持未知；request不证明服务端内部路由'}
    Path(folder).mkdir(parents=True,exist_ok=True)
    (Path(folder)/'run-context.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    (Path(folder)/'prompt.txt').write_text(prompt,encoding='utf-8')
    return result
