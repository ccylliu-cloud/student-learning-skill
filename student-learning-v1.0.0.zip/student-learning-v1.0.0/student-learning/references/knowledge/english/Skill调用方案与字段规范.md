# Skill / 知识库调用方案 v1.2

## 分层存储

一级是模块，二级是知识点组，三级是可检索、可关联错题的考点。相同规则在多书出现只保留一个 `kp_id`，多个出处放入 `sources`。条件、意义或教学层次改变时，保留独立考点并用 `extends_ids`、`confusable_ids` 关联，不把它们压成一句口诀。

本版已经填入完整知识记录，并提供JSON和JSONL两种格式。JSONL一行一条，适合向量检索或分块；JSON保留可整体导入的数据包。二者内容相同，不应当成两套数据重复入库。

知识、词项、题目、学生作答、诊断是五种不同实体。知识条目说明规则；词项表保存不规则形式；题目必须单独有答案集和评分边界；学生作答关联题目；诊断关联知识及可观察证据。不要将例句、所有OCR练习或编制者推导的错因直接当成已验证题库。

## 已实现字段

|字段|含义与约束|
|---|---|
|`kp_id`|稳定主键，用于错题、掌握状态和跨版本关联。|
|`canonical_key`|可读语义键，例如 `tense.present.negative`；可作为检索别名，重命名须留旧别名。|
|`module_id/module`|一级模块的ID及中文名称。|
|`topic_id/topic`|二级知识点组的ID及名称。|
|`point`|三级细分考点名称。|
|`rule.summary`|归纳后的教学规则。|
|`rule.applies_if`|适用条件；检索命中不等于满足条件。|
|`rule.decision_steps`|条件确认→规则应用→边界检查的判定路径。|
|`rule.boundaries`|例外、变体、语境限制及不可外推范围。|
|`rule.provenance_type`|明确规则为教材归纳，边界可能为编制者限定。|
|`examples`|典型例句及来源类型。本版为基于书内内容编写或改写，非逐字引文。|
|`common_errors`|候选错误或易混模式，带推导来源说明；不表示已测得学生发生频率。|
|`error_tag_ids`|指向统一的候选错因标签词表。|
|`difficulty`|建议难度1/2/3；具体年级未知时为null。并非课标认定。|
|`sources`|来源书、课/章、印刷页段、PDF页段、抽取方式及证据范围。|
|`prerequisite_ids`|编辑建议先修图，用于回补基础；不声称是教材官方教学顺序。|
|`extends_ids`|基础→扩展关系，不等于必须先学。|
|`confusable_ids`|容易混淆的相邻考点。|
|`difference_ids`|多份资料合并及差异处理记录。|
|`quality_issue_ids`|教材冲突、笔误、多解等疑点。|
|`assessment_policy`|普通记录也必须检查语境；`review_only`禁止单独作为自动判错依据。|
|`version/status`|知识版本和有效状态，后续支持deprecated与replaced_by。|

`sources`中的页段定位到教学单元或相关练习页段，不冒充逐句引文定位。一个来源条目并不表示其中每页都讲授该规则的全部细节。需要逐条法律式引文证据的应用，应在本版基础上增加 `evidence_snippet`、`page_bbox` 和人工核验状态。

## ID命名

|实体|格式|例子|
|---|---|---|
|知识库|`EG-KB-主题范围`|`EG-KB-PRIMARY-4BOOKS`|
|书籍来源|`EG-SRC-Bnn`|`EG-SRC-B01`|
|书内章节|`EG-CH-Bnn-Lnn/Cnn/Unn`|`EG-CH-B03-L61`、`EG-CH-B04-C08`|
|一级模块|`EG-M-nn`|`EG-M-01`|
|二级知识点组|`EG-T-nnn`|`EG-T-001`|
|三级考点|`EG-KP-nnnnnn`|`EG-KP-000001`|
|错因类别|`EG-ERR-nnn`|`EG-ERR-001`|
|资料差异/疑点|`EG-DIFF-nnn` / `EG-ISS-nnn`|`EG-ISS-001`|
|词项|`EG-LEX-nnnn`|`EG-LEX-0001`|
|后续题目|`EG-Q-nnnnnnnn`|`EG-Q-00000001`|
|后续错误模式|`EG-PAT-nnnnnn`|`EG-PAT-000001`|

数字ID发布后固定，不随标题、年级、模块移动或新增来源变化。新增编号只追加，不重排；旧知识合并时置为deprecated并保存 `replaced_by`，不复用旧编号。不要把书名、章节号、年级写进 `kp_id`，否则同一知识的四书去重及版本维护会困难。版本放在独立字段：纠正文案升补丁号，新增条件或考点升次版本，字段或含义不兼容时升主版本。

## 错题归因与调用

先保存完整题干、选项、学生原答、期望答案集合、语体与上下文。先检题目质量，再检知识；没有正确选项、多解、缺图或教材争议时，返回 `ungradable_item` 或 `needs_clarification`，不要把题目问题记成学生弱项。

每次检索召回3—5个候选考点，按难度、主句/从句位置、词性、主语人称数、时间参照等条件过滤。读取命中条目的边界与相邻易混点，再返回主考点和相关考点。难度未知的学生先从小学基础候选开始；不要因为素材中有新概念高级章节就推送给小学生。

错误形式与错误原因应分两层：例如“does后仍加s”是可观察偏差；“忘了规则”“没识别三单”“粗心”是尚待验证的原因。通过最小对照题确认原因，不能单凭一次选择题给心理归因。没有验证数据时，置信度留空或用说明，不虚构精确概率。

v1.2分享包不附带演示题；例句仅说明规则，正式训练题需另行命题和审核。

## 建议后续扩展

1. 建立 `questions`：题干、选项、全部合规答案、规范化规则、评分依据、核心/相关考点、必须上下文、来源及原创/改编标记。
2. 建立 `error_patterns`：可观察错误形式、正确对照、可能原因、用于区分原因的追问题。
3. 建立 `attempts`：匿名学习者、题目版本、原答、诊断证据、知识版本；真实作答与教学示例分库存。
4. 学生掌握度由多次作答与迁移情况计算；知识条目不直接写某学生“掌握/未掌握”。
5. 将已隔离的排他规则完成权威复核后再开放判分。此版没有外查裁定，也没有把教材全量练习转成已验证题库。

机器字段契约见 `skill_call_contract.json`，知识记录结构见 `knowledge_point.schema.json`。前者是后续Skill的调用建议，不会安装或修改用户现有Skill。


## v1.1 固定搭配扩展

新增二级组EG-T-036（动词固定搭配），沿用一级模块EG-M-06。新增考点000274、000275；原ID不重排。`search_aliases`收录常见写法，`related_grammar_ids`只作背景检索关系，不自动产生题目标签或错误归因。

`sources`现在兼容两种来源：原书仍使用book_id、chapter_ids与双页码；外部来源使用source_id、source_type=web、title、publisher、url、accessed_date、evidence_role，不伪造book_id或页码。


## v1.2 学段与高中来源

`school_stages`为数组：primary（小学）、junior_secondary（初中）、senior_secondary（高中）。`stage_basis`记录建议入门学段、证据材料和判断性质；它与难度不是同一字段。`stage_profiles.json`可用于召回排序或训练范围建议，学段未知时不可硬过滤；高中遇到基础漏洞仍可回溯小学考点。不得宣称这些标签是官方课标或教材年级。

`highschool_supplements`保存旧ID新增的高中细节；轻量知识读取也会返回该字段、学段与先修关系。旧的`assessment_policy.default_primary_enabled`只关系默认小学训练，不应被理解为“禁止初高中使用”。`review_only`仍禁止形成确认归因。

新增DOCX来源B05、B06以`source_type:docx`区分，`block_ranges`使用1起始闭区间。块号是word/document.xml正文body直接子元素编号，包含空段、表格和section属性；`B05-P02551`中的P为历史定位前缀，**不表示页码**。表格算一个块，表内文字可按行内容核对。文件SHA-256不一致时，不能继续沿用原块号。8个旧式EQ域的规则已单独核读，不能仅抽取w:t而漏掉w:instrText。

B05是讲解与练习，B06是答案解析；`evidence_role`区分规则、练习模式、答案交叉核对与外部边界核对。来源中不含path，原文不随包发送。若某题来自B05，不能仅靠题号从B06取答案，必须核对章节、题干、选项与版本。

稳定kb_id沿用历史EG-KB-PRIMARY-4BOOKS以兼容；显示名称使用“英语语法知识库”，实际覆盖看scope_note和school_stages。所有既有ID和canonical_key保留；本次新增000276—000355、二级037—039。新增其他高中考点从000356继续，不能按学段重编号。

接口建议返回：kp_id、point、rule、highschool_supplements、school_stages、prerequisite_ids、extends_ids、assessment_policy、version、kb_version和sources。sources可按需查询完整记录；网页识别的轻量查询不返回完整来源目录，以减少输入量。版本升级不得重写历史题目的原归因、版本引用或作答。
