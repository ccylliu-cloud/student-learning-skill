# 安装与宿主适配 1.0

Python 3.10+。先在新目录安装，不覆盖旧安装与唯一档案；升级先用旧版backup在线备份，使用新安装明确复用档案并检查历史。首次姓名、年级、目录由用户确认。WorkBuddy的安装与档案均应在当前项目内。

Codex：`python install.py --host codex --target "新Skill绝对目录"`
WorkBuddy：`python install.py --host workbuddy --workspace "项目绝对目录" --target "项目/.workbuddy/skills/student-learning"`

本安装准备依赖：`python scripts/setup_runtime.py --install-deps`（WorkBuddy加`--workspace "项目绝对目录"`）。只创建本安装runtime/venv，不改系统Python。启动脚本与后续命令使用该venv。宿主PYTHONPATH中间层导致EEXIST时，Mac/Linux仅对本安装子进程使用`env -u PYTHONPATH -u PYTHONHOME`；不修改全局环境。

`portable.py doctor`核对发布文件、三科知识库与依赖；`portable.py check`只读配置；`portable.py init`只初始化知识库不创建学生作答。`portable.py serve --port 8767 --open`绑定127.0.0.1；关闭终端/Ctrl+C正常停止。端口冲突不结束其他进程。使用完整本地路径启动，不以项目同名文件替代安装脚本。

## 当前对话识别（两宿主共用）

1. `portable.py stage "原始图片路径" ... --subject math`，按返回页序核对哈希与尺寸，`portable.py group --subject math --title "原卷标题" --pages 页面ID...`。已在网页分组直接`groups`查找，不能重复建卷。
2. `portable.py pending`查网页保存的任务，或`groups`查已有分组。
3. `portable.py conversation-export 分组ID --out "新任务目录"`。补题加`--mode supplement`，复用网页圈选；报告加`--mode report --consent`，只有用户已在网页或对话明确同意才使用。
4. 读取返回prompt和images，实际看图。不能看图则`conversation-block manifest路径 --reason "实际错误"`，立即停止。能看图逐图写vision报告文件，`conversation-vision manifest路径 --report 报告路径`。
5. 严格按prompt完成当前阶段，结果写为JSON，再`conversation-submit manifest路径 --result 结果路径`。检测只定位；详情每批最多4候选，必须查必要知识完整语义并保留引文。当前模型ID/推理设置能取得时记录于说明，未知不猜。
6. 返回后续tasks时逐个完成，不能声称只做完定位就完成整卷。错误只修复本地JSON，`conversation-retry manifest路径 --result 修复路径`保留原始响应与修订，不重读已完成阶段；没有重新看图就不声称新增视觉证据。缺裁图/原图证据需重新圈选该题。
7. 提交后回网页人工复核，分别确认正误和错因；知识insufficient、题图未清理、未定位候选必须继续处理或明确待办。

## 运行模型

Codex网页默认请求gpt-6-astra/medium，按本安装`portable.py configure-recognition --model 模型ID --reasoning-effort medium`修改，可被STUDENT_LEARNING_MODEL/STUDENT_LEARNING_REASONING覆盖。不支持时明确失败，不自动降级。WorkBuddy使用当前对话可读图模型，网页无已核实自动调用后端，页面保存交接任务，不伪装后台运行。两者使用同一导入校验，但模型识图能力仍可能不同。

## 图片与费用

使用本机原件路径优先，宿主剪贴板可能缩小。工具不自动放大补细节。20分钟模型阶段超时停止；默认识别候选，不反复验算整卷。订阅或模型计费由宿主提供，Skill不接新第三方模型服务，不收集凭据。
