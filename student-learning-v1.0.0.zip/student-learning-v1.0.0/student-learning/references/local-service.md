# 试用版运行入口

本分享包不安装常驻服务。请读 [试用版安装与宿主适配](trial-installation.md)，用 portable.py 启动。
