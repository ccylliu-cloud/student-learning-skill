# 语文两级知识库接入与匹配

后续语文题的知识／能力定位统一使用《语文两级知识库 v1.0》（1.0.0），原始权威文件为[语文两级知识库.json](knowledge/chinese/语文两级知识库.json)。[轻量索引](knowledge/chinese/节点检索索引.json)用于召回，[完整使用说明](knowledge/chinese/使用与Skill关联说明.md)用于解释结构与证据边界。

当前已接入本Skill：新档案init导入84个二级节点；网页与识别进程读取同一档案knowledge表。原发布包中的not_installed说明描述发布时状态，不代表当前安装状态。源包保持原样以便版本核验；关联示例未随运行Skill安装，更不能导入学生档案。

- 8个CHN-CAT大类仅显示与汇总，不作为归因ID。知识点和能力点都使用二级CHN-KP稳定ID；不把学段、文体、字词、篇目或修辞种类改成第三级。
- 先按小问或独立评分目标，通过search --subject chinese或轻量索引召回，再用knowledge ID或kb_lookup.py --subject chinese --ids ID...读取definition、include、exclude、related_points和stage_profiles。知识定位、实际失误点、CHN_E错因分别凭证据判断；主考点优先一个，必要时增加次考点，不自动追加所有相邻节点。
- knowledgeIds保存实际考查ID；归因每条单独绑定knowledge_point_id、error_cause_id、evidence、status。系统保存知识内容哈希和library_version；不把active/enabled_for_matching当作用户确认。无法匹配时保留候选名与pending/provisional，禁止伪造知识ID或因关键词相似强行确认。
- 该库基于课标与手册目录编制，只支持分类和能力边界；不包含已验证的教学规则、题目答案或标准化评分尺度。批改、解释需依据实际题干、材料、可靠参考与推理。开放答案不因措辞不同判错；学段只是检索提示，支持基础回溯。
- 此次接入不自动改写历史题目标签、判定、归因或掌握状态。后续版本升级先备份；确有旧草案ID时参考迁移表核对，无确定对应关系保留待映射。不得重编号或用初始化覆盖其他学科的用户更新。
