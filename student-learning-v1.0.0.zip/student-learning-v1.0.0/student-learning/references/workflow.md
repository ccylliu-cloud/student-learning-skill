# 操作与数据契约 v1

全部命令在 Skill 目录执行；路径均用绝对路径。以下 `python` 指可用的 Python 3.10+，文档命令使用当前宿主可用的带 python-docx / Pillow 的 Python 环境；先读试用版安装说明。

```text
python scripts/study.py init
python scripts/study.py search '位值' --subject math
python scripts/study.py knowledge MATH-K000021
python scripts/study.py import-paper /绝对路径/识别结果.json
python scripts/study.py snapshot
python scripts/study.py history --knowledge MATH-K000021 --cause MATH_E01
python scripts/study.py history --question 数据库题目ID
python scripts/study.py edit-question 数据库题目ID /绝对路径/修订.json --reason '家长确认原答正确'
python scripts/study.py review 数据库题目ID /绝对路径/复做.json
python scripts/study.py mastery /绝对路径/掌握.json
python scripts/study.py export-word /绝对路径/错题本.docx --subject math --mode analysis
python scripts/study.py export-word /绝对路径/练习.docx --paper 试卷ID --mode practice
python scripts/portable.py serve --port 8767
python scripts/study.py backup /绝对路径/学习档案-日期.zip
```

自定义档案路径：`python scripts/study.py --root /档案路径 命令 ...`。原图以内容哈希复制入 `assets/`；不依赖上传临时目录长期存在。核心数据库表为 papers、questions、reviews、mastery、events、knowledge、meta；PC 分组和复习卷也保存在同一 SQLite 中；学生只有一个，故没有用户表。events 保留每次修订前后内容。数据库题目 ID 在 snapshot 中读取；输入 local_id 是本卷稳定题号，两者不同。

## 试卷输入

下例仅说明字段，不能写入真实学生档案。

```json
{
  "schema_version": 1,
  "paper": {
    "id": "math-2026-09-12-001",
    "title": "数学作业",
    "subject": "math",
    "date": "2026-09-12",
    "assessment_mode": "teacher_marks",
    "coverage": "full",
    "page_count": 1,
    "scanned_pages": [1],
    "expected_question_count": 1,
    "sources": ["/绝对路径/原卷.png"],
    "analysis": "当前 Codex 根据逐题证据写的整卷分析。"
  },
  "questions": [{
    "local_id": "一-1",
    "number": "一、1",
    "page": 1,
    "text": "原卷上的完整题干、选项、单位与共用条件",
    "student_answer": null,
    "corrected_answer": null,
    "expected_answer": null,
    "explanation": null,
    "verdict": "pending",
    "decision_status": "pending",
    "evidence_level": "B",
    "basis": "teacher_mark",
    "evidence": "需核实批改符号及原始作答",
    "observed_error": "尚无法辨认",
    "score": null,
    "max_score": null,
    "requires_image": false,
    "assets": [{"path":"/绝对路径/原题局部.png","role":"original"}],
    "attributions": [{
      "knowledge_point_id": null,
      "knowledge_name": "待映射的知识点名称",
      "error_cause_id": null,
      "status": "pending",
      "evidence": "尚无充分证据",
      "secondary_cause_tag": null
    }]
  }]
}
```

学科 `math/english/chinese`。每份记录一个学科，混合材料拆分保存并关联相同源文件。

判题 `wrong/correct/pending/ungradable`；判题确认 `confirmed/pending`；归因 `confirmed/provisional/pending`。确认错题必须有完整题干及证据。自动识别的全部结果先设 `decision_status:pending`，由用户在页面确认；模型不得填写 `basis:user_confirmed`。A 级证据仅表示依据明确，不代表已经完成用户确认。未批改材料用 `assessment_mode:unmarked`，依据为 `model_reasoning`；模型仍需保留可检查的推理证据，模糊项 B 级待确认。错因不能随错题一并机械确认。

`full` 必须扫描 1 到总页数全部页，核对 `expected_question_count` 和输入题数一致。题目计数口径为可独立练习单元；一个多空题保留整道题时只能计一题，不能再重复计它的每个空。漏页、只上传错题或总题数未核实用 partial。原卷写出的总分可保留在附加字段 `reported_score`；只有每题分值完整时才计算总分。不得混用两种分数。

未知答案留 null，不填编造的标准答案。确实依赖图形、表格或版式的题用 `requires_image:true`；original 保留卷面证据，question_clean 或 `content` 中已核对的图片用于练习。若完整文字已足以表达所有条件，可在核对原图后取消图像依赖并记录修订依据，不能为绕过导出检查盲目取消。

knowledge_point_id 需实际存在且学科一致；脚本补入知识名称及知识库文件哈希版本。`prior_mastery_evidence` 是确认“粗心”必需字段。正式 ID 未映射时需给候选名称，不能 confirmed。

## 题面、作答位置与知识点

所有后续带图题按[图题可打印题面处理](diagram-cleaning.md)清理、校正、核对并回写原题；原始卷面和学习历史保留。纯图片 `content` 是有效题干，`text` 可为空，无需添加占位文字。

每题可增加下列字段；正文、页面与 Word 使用同一份题面，不能各自改写题意：

- `content:{version:1,blocks:[...]}`。文字块为 `{type:"paragraph",runs:[{text:"原题文字",underline:true,bold:false,italic:false}]}`；三种格式标记可省略。图片块为 `{type:"image",asset:{url:"/files/已存档文件名.png",label:"题图说明"},widthCm:12}`，宽度可省略，提供时大于 0 且不超过 18。图片必须已保存于本地档案，支持 PNG/JPEG/WebP，不能引用上传临时地址、外链或学生答案图。
- `sectionTitle`：大题说明；`sharedContext`：该组小题共用的阅读材料或条件。两者均为文字。具体题干放 `content`，`text` 与文字块纯文本一致；共用材料不同不能因大题标题相同就合并。
- `answerLayout:{kind:"inline"}` 表示题内空格；`{kind:"lines",lines:2}` 表示横线（1–12 行）；`{kind:"space",heightCm:3}` 表示演算或作图留白（1–15 cm）。依据题型及原卷留白决定，不能统一塞入“我的作答”区。
- `knowledgeIds`：每题实际关联的知识点 ID 数组，最多 3 个，必须存在且学科一致。正确题也关联知识点，无错因则 `attributions:[]`，不为图表补造错因。未映射项保留候选名称和待核实状态，不能伪造 ID。

英语显示三级考点名称，筛选器保留一级—二级—三级关系，各层可勾选。分布图按层级展示错题总数及题目级已掌握／未掌握数量；同一题命中父节点下多个考点，父节点按题目 ID 去重，不把标签数当题数。正式知识点关联与候选、人工错因标签分别保存。

简单题图重建使用 `diagram:{width:1200,height:800,elements:[...]}`，画布宽高均为 100–2400 的整数，所有坐标为画布内像素。每个图元是含 `type` 的对象，其余字段如下：支持 `line(x1,y1,x2,y2)`、`rect(x,y,width,height)`、`circle(cx,cy,r)`、`polygon(points:[[x,y],...])`、`text(x,y,text,size)`；文字字号 12–100，最多 300 个图元。由程序生成黑线白底 PNG，放入题干并标记 `diagramReviewRequired:true`；用户对照原图核对后才确认。只表达原题确定条件，禁止补尺寸、角度或学生答案。复杂且清晰时不勉强生成图元，转入图像编辑清理流程；信息不足或工具不可用时保留原件并明确待处理原因，不把带答案原图当作可打印图。

## 修订

JSON 为需修改的字段集合，例如：

```json
{"verdict":"correct","decision_status":"confirmed","basis":"user_confirmed","evidence":"家长核对原卷，红线是相邻题批注"}
```

允许题干、原答、订正、参考答案、解析、判定、证据、归因、得分、备注和素材修订；原始审计记录保留。修改 assets 时提供完整的素材数组与绝对路径（原始题图也要保留），脚本复制入档案。更换学科需在 Codex 中明确核对。

漏题补录：`python scripts/study.py add-question 试卷ID /绝对路径/单题.json --expected-total 核实后的全卷题数`。单题 JSON 与 questions 元素相同。没有重新核实全卷题数时省略 expected-total，整卷自动改为部分覆盖；同卷 local_id 不得重复。不得另建一份相同试卷来补题并重复统计原有题目。

## 复做和掌握

复做字段：

```json
{"id":"review-唯一稳定编号","date":"2026-09-13","answer":"学生本次真实作答","result":"correct","independent":true,"knowledge_point_ids":["MATH-K000021"],"evidence":"未看答案，无提示独立完成；说明了规则"}
```

结果为 correct/wrong/partial/pending。同一复做 ID 重试不会增加次数。归属原题已经关联的知识点，不能一次复做自动覆盖一题全部知识点。复做不修改原题是否曾错。

掌握字段：

```json
{"subject":"math","knowledge_point_id":"MATH-K000021","status":"partially_mastered","date":"2026-09-13","reason":"能完成直接题，迁移题仍需提示"}
```

人工状态和算法建议分开存储。建议规则不把一个独立错误直接判为未掌握；未掌握需具体证据后人工记录。已掌握建议至少三次独立成功且跨两天两题，最近错误使建议回到部分掌握；已保存的人工作答日期及说明在页面仍显示，需结合新证据重新评估。

## 整卷与重复统计

整卷表现是学生对本卷考点的掌握表现，不是模型识别表现。考点按实际层级横向联动（语文两列、数学最多四列、英语三列），仅显示选中分支；每项一行，名称后用绿／红／灰数字依次显示做对／做错／待确认（含无法判定），不使用条形图或细条；正确题也必须关联考点。易错点基于本卷已确认错题的错因。修改正误后重算统计与分析，不能继续展示已失效结论。

错题比例分母含已确认且可判定题目，以及满足全候选人工复核完成条件后报告推定的正确题（wrong + correct）；推定只影响报告，来源须说明，不回写原判定或掌握。历史“排除出错题本”不等于确认正确，须复核；无效或重复题框排除出有效题目计数。部分卷面的比例仅描述已录入可判定题。缺少分值时不算总分，报告说明待确认数与未覆盖范围。各层考点统计按题目 ID 去重。

重复模式按“知识点 + 已确认错因”聚合不同数据库题目，保留题数、试卷数；同一题多条相同归因去重。同卷不同题可以构成复错，但不能称为跨日期持续复错；解释历史时再核对日期和试卷数。同题文本指纹是保守匹配，拍照重传由卷 ID 约束，不自动声称具备语义去重。

## 页面和 Word

服务仅在本机运行，关闭服务页面就不能写回数据；启动时返回实际端口。不要把管理页复制到云端。仅本机固定来源加随机请求令牌可提交修订；这不是账号体系。

Word 页面下载只包含本次勾选的已确认错题。A4 练习卷不设“错题练习”大标题，右上仅日期，与正文同为 12 pt；题号与来源日期 10.5 pt 合为一行。同一 `sectionTitle` 合并成一个大题，但不同 `sharedContext` 必须分开；按 `answerLayout` 留空，不打印“我的作答”。标题不单独落页尾，题干、题图及必要作答空间尽量同页。分析版另保留答案、证据、解析与归因。

组卷与下载前预检所有选题，缺少可练习题图时指出具体题号，提供补图或用户取消该题的机会，不自动跳题，不打印带答案的原图。复杂公式需规范数学文字、核对后的公式图或 documents 的原生公式路径，不能空白或原样输出未排版 LaTeX。正式交付文档时用可用文档渲染工具逐页验证；工具缺失明确标未验证分页，让用户用 Word/WPS 检查。

## 本机 Word 渲染验证

已验证的 macOS 字体为 Arial Unicode MS，文档正文保持可编辑。当前 Codex 自带的无界面文档渲染器需要显式字体配置，否则可能丢失中文；仅为渲染进程设置 `FONTCONFIG_FILE` 为本 Skill 的 `assets/fonts-macos.conf` 绝对路径，再调用 documents 技能的 `render_docx.py`。不要修改系统字体或替换用户桌面软件。其他操作系统应使用实际可用的中文字体目录，不能照搬 macOS 字体路径。


## PC 图片分组与识别

### 原图缩放、拖拽与题框操作

维护或重建识别结果页面时，保留以下已确认交互，原卷与复练使用同一规则：

- 原图支持50%～300%缩放。鼠标位于原图区域时，滚轮以鼠标所指的图内位置为缩放锚点；加减按钮以视口中心缩放。“适应宽度”恢复100%并复位滚动位置。切换页面或试卷分组也复位视图。
- 按住鼠标左键拖拽原图进行横纵平移，放大后能直接拖到右侧或下方，不要求用户寻找滚动条。未超过拖动阈值时仍可点击题框选题；发生拖拽后抑制紧随其后的点击，防止误切题。
- “隐藏题框/显示题框”放在原图下方，与“调整当前题框”“补充漏题”同一操作栏；隐藏只控制显示，不删除题框或修改识别记录。
- 进入调整题框或补漏的绘框模式时，暂停图片平移与缩放，由拖动生成题框；保存或取消后恢复查看交互。题框始终按原图百分比坐标保存，缩放、平移和切页不改变已存范围。
- 图片小于视口或到达滚动边界时，锚点受可滚动范围限制；缩小后保持水平居中，不承诺边缘外无限平移。
- 修改该查看器后，在实际浏览器核验鼠标锚点、拖动到右侧、题框点击与拖动区分、绘框互斥、隐藏切换和切页复位。视图操作不写入题目、作答、标签、判定或复练数据。

`stage-pages` 接收原图并复制到同一档案，支持 PNG/JPEG/WebP/HEIC/HEIF，自动转正 EXIF 方向并保留原始证据；HEIC 使用本机 pillow-heif 或 Mac 系统 sips，失败给出明确说明。PDF 先逐页渲染并核对顺序。按返回的 `importResults` 核对输入来源、`pageId`、`previewUrl`、`status`、`duplicateMatch` 与 `suspectedDuplicates`，再确认页序和分组。只自动复用字节或转正后像素完全相同的页；同名或看起来相似不等于同一作答页。详见[输入保护](input-safety.md)。

```text
python scripts/study.py stage-pages /绝对路径/第1页.jpg /绝对路径/第2页.jpg --subject math
python scripts/study.py requests
python scripts/study.py recognition-result 分组ID /绝对路径/完整识别结果.json
python scripts/study.py pc-snapshot
python scripts/study.py practice-result 复习卷ID /绝对路径/本次复练结果.json
python scripts/portable.py serve --port 8767
```

网页分组完成后，原卷点击“定位并识别错题”（复练仍完整批改），本地 `serve` 服务直接调用已有 Codex CLI `exec --sandbox read-only`，沿用已有 ChatGPT 登录和默认模型；用户无需再发对话指令。后台模型只读本组原图与 Skill／知识库并输出 JSON，不运行导入、修改、服务命令，不调用第三方模型或外部模型 API。页面显示真实运行、完成或失败状态；同组重复点击不并发重复执行，中断或失败可重试。`requests` 与 `recognition-result` 保留为手工查看、恢复和导入工具，不是正常用户流程中的额外步骤。

`recognition-result` 使用本文件的完整 import-paper 契约。题目额外可写 `box:{x,y,width,height}`（相对于对应原图的百分比 0–100，必须整题覆盖），用于 PC 原图对照。识别内容写入待复核草稿，网页确认后才进入错题库；默认仅保存候选题，coverage=partial；用户确认启动整卷报告后，才保留全部可见题用于核算整卷。定位已完成但无候选可保存 questions:[]，仅允许 recognition_scope:"mistakes" 且 partial，不能伪造占位题。不要再对同一组调用 import-paper。

初次自动结果只包含错题候选且全部待用户确认；一键加入表示确认所选题为错题，用户可将误判的候选题改为正确。无效框或重复题可排除，历史排除不自动变成正确，归因确认独立处理。首次“查看试卷报告”弹窗说明额外较大 Token 消耗，经确认才读取全卷题目和知识点；已有完整报告直接读取缓存，不重复调用模型；“一键组卷”进入当前试卷已确认错题列表，默认勾选且可调整。错因图的扇区、图例、数量均可跳转错题库，并保留学科和当前试卷范围。PC 修改正文、答案与作答回写原始记录并记录审计；人工标签独立覆盖字段不抹去原有归因证据。冲突时页面拒绝旧版本保存，不静默覆盖另一个对话更新。

复练输入结构：`{date:"YYYY-MM-DD", results:{数据库题目ID:{result:"correct"或"wrong",answer:"本次实际作答",evidence:"判定依据",independent:true或false,knowledge_point_ids:[实际验证的ID]}}, sources:[复练卷绝对图片路径]}`。只有真实本次作答才能写入；不得用标准答案替代学生答案。复习卷ID与题目ID从 pc-snapshot 读取，避免重新生成不对应的卷子。

PC 人工题目掌握、标签与练习证据通过 pc-snapshot 读取，知识点证据与算法建议继续通过 snapshot/history 读取。页面三项数量按题目级状态统计，不能把“一个题已掌握”解释为对应知识点已全面掌握。

识别页展示约定：右侧题号和左侧原图标框只展示错题及待核对的错题候选；不提供“全部题目／正确”筛选栏。已排除候选保留恢复入口。一键加入仅确认错误候选，不批量确认隐藏的正确题；用户将某道候选明确改为正确时，保存确认结果并从识别列表移除。已生成的整卷逐题数据继续保存，首次未分析的题不作统计；报告不因页面隐藏而删除或改写原判定；错题候选全部人工复核后，按下述报告规则推定其余预测正确题。

知识分布显示：仪表盘与试卷报告采用按实际层级联动（语文两列、数学最多四列、英语三列），各列独立滚动；默认选择有记录的首个有效分支。仪表盘同行数字顺序为错题总数／已掌握／未掌握（深灰／绿／橙），报告为做对／做错／待确认（绿／红／灰），顶部统一标明含义。非叶子节点点击切换下级，叶子节点（语文二级、数学三级或四级、英语三级）点击进入对应错题列表。错题库筛选器保持原样；统计仍按节点内题目ID去重。


## 复练卷识别与确认

上传已生成组卷的做题图片时，先查 `pc-snapshot` 定位唯一的 practice 卷及 questionIds，再接收原图：

```text
python scripts/study.py stage-pages /绝对路径/复练第1页.jpg --practice-paper 复习卷ID --date YYYY-MM-DD
```

返回 `practice-scan-复习卷ID` 稳定分组；图片先显示在错题识别，网页按钮直接启动 Codex。同卷同日期重传不新增考试/题目/复练次数；新一次作答需新组卷，即使同一天也不复用旧卷记录。不得覆盖另一天的已保存作答。原卷继续使用 `stage-pages ... --subject english|math|chinese`。

复练 `recognition-result` 使用完整识别 JSON，questions 每项增加 `question_id`（原数据库题目 ID），必须与该复习卷 questionIds 完整一一对应；page 为本次图片页码，box 是该页百分比定位。保留真实 student_answer/evidence/independent/knowledgeIds；verdict 可为 wrong/correct/pending/ungradable。服务从原题恢复题干、答案、标签，不接受模型覆盖原题。初次识别仅保存待确认草稿，定论同步为 paper.results；不写 savedResults、不创建新原卷/错题。

识别页可核对原图、调整题框、本次作答和判定；正确题隐藏但完整保存。进入“查看批改结果”可查看全部题的本次作答和正确答案。全部题已判定后，复练“确认批改结果”或批改页“保存批改结果”同步整卷确认；有待判题不能完成。两处确认保持一致，部分确认不会提前更新正确率和次数。

确认投影：组卷正确率=本卷确认正确题数/卷内题数。原题 wrongCount=初始错误+独立复做及已确认组卷中的错误次数；correctCount=已确认正确复做次数；groupedCount=包含此题的组卷数量。每张组卷每题只有一次复练记录，重复保存幂等，纠正判定替换本次结果。题目掌握随最新已确认作答更新；知识点掌握仍按独立证据算法。不对同次组卷重复调用 review。

`practice-result` 保留给对话中已经完成的真实批改，结构沿用上文，并支持来源页码 `source_page`。它同时建立/同步识别入口；已有人工确认的冲突结果优先保留人工判断，提示复核。历史回填只使用实际 sources、作答和日期，缺题框用 boxVerified:false，不生成伪精确框。历史回填不增加正确/错误/组卷次数。


## 网页识别精简协议与可观测性

网页按钮的模型输出使用 `student-scan-v2`，由 `scripts/recognition_contract.py` 的 `build_prompt` 生成完整短契约，`expand_result` 在服务内展开为本文件schema_version:1，再进入既有事务校验。对话手工 `recognition-result` / `practice-result` 保持旧契约，不直接传v2。

原卷text或content二选一；sections引用共享sectionTitle/sharedContext；可信卷身份、日期、原图assets与pending状态由程序恢复。复练question_id必填且完整一一对应，原题字段从canonical恢复。答案字段提示为字符串/null；适配器兼容深度及条数受限的答案数组/对象，保留编号、键名和null对应的未辨认/待确定提示。原始模型结果文件保留，可直接在本地修复格式后校验，无需自动整卷重识别。任何用户确认都不能由模型生成。知识条目采用只读、限量批量查询，保留规则、边界及证据限制；正确题和未匹配候选仍用于整卷报告。

progress由服务器绑定requestId写入，客户端不可伪造。阶段来自实际进程启动、工具读取、输出事件、重连和本地校验保存；最近活动不是模型内部每一步思考的心跳。界面长时间没有新事件不等于已经停止。旧记录没有progress时仍按原有状态展示。

usage.json位于每次独立任务草稿目录，记录真实完成事件中的累计usage及usage_complete；失败缺usage保持null/不完整。字段elapsed_seconds是总耗时，model_elapsed_seconds包含资料准备和模型执行，save_elapsed_seconds为校验保存。多个完成回合按日志累加；缓存是输入子集。程序不自动把故障日志或模型原文暴露为进度，也不自动重复整卷增加模型消耗。


## 学生设置与报告完成规则

首次使用、年级晋升、科目管理、存储位置及数学库路由统一见[学生设置和本地目录](student-settings.md)。设置接口校验当前档案版本和本机请求令牌；网页不可直接改pc_profile绕过验证。历史年级只读原卷/组卷快照，缺失保留未分年级。年级修改只影响后续新材料。

归纳知识点上限3个；超出时按明确年级从高到低，同级按本题核心程度排序。未知年级不以学段估算具体年级，保留待核对；被省略候选名称及原归因证据保留，不能静默丢失。

原卷所有错误/待核对候选均人工确认正误或明确排除无效框，且至少存在一道有效确认，才标记reviewComplete。保存入库不等于人工确认，零候选/全无效框不触发。其余模型判对但未逐题确认的记录仅在报告中以reportResult=correct和reportInferredCorrect展示，明确说明来源。原decision_status/verdict和复练/掌握记录不变。无法判定、旧排除仍待确认，partial只代表可见题目；撤销复核时重新计算。以上不改变复练须逐题完整确认的契约。

## 图片能力与失败边界

网页模型任务返回 `student-scan-v2` 时必须包含 `vision:{status:"readable",pages:[{page:1,status:"readable",observation:"该页真实可见的印刷文字片段或图形特征"}]}`，逐页覆盖全部输入图。这是本次模型自述而非独立验证，不允许用“已看图”通用标记、文件哈希或像素尺寸替代。图像能力明确失败时仅报告 `status:"image_blocked"` 与实际错误，不能提交题目或正误。程序拒绝缺失/阻断报告；后台识别发现读图错误立即停止并给出恢复提示。保留原分组，用户换到可读图环境后明确重试。详见[输入保护](input-safety.md)。


## 圈选补题按需识别

在已识别原卷的结果页，“补充漏题”→圈选完整题面（含选项、图形和所需共用条件）→“识别选中题目”。POST `/api/recognition/supplement` 接收 groupId、pageId、box、requestId，需要本机来源、令牌和当前档案版本；不得把识别状态从普通档案保存接口伪造写入。每组同时一个补题任务，状态 queued/running/completed/failed 保存在 group.supplementTask，刷新后仍可查看。

裁剪使用当前可信原图和用户百分比选框，保留区域像素；模型只接收选区，不重新扫描整卷。只读模型返回一道题，程序恢复原页码/用户题框、校验后追加待复核草稿；不自动确认正误或加入错题本，不改其他题的人工内容与练习。精确相同页码、题号、题干和共用材料的已有题复用其记录，不覆盖已确认判断。新增题会将未经重新核实的全卷覆盖标记为partial，不能维持不再可信的总题数或全卷正确率。

PcScanQuestion.supplemental 表示补充题；预测正确的补充题保持可见直到用户确认。完成时定位结果并提示，失败保留原范围，明确页码及重试入口。重启将未完成任务标失败，用户重试使用新requestId，旧执行结果不得写入新任务。同一requestId不重复调用模型。usage保存于 drafts/supplement-*/usage.json，计量口径与整卷识别相同。

本机网页执行器使用现有Codex登录与模型设置；这项改动不等于已接通WorkBuddy网页调用入口。


## 已完成识别的保存恢复

模型正常结束且完整输出落盘后，`recognition_checkpoint.py` 在同任务目录保存 `input-context.json` / `result-ready.json`，绑定原图字节哈希、页序、卷信息和复练原题快照；原始 `result.json` 不改写。`recognition_recovery.py` 仅做确定性、可审计规范化，输出 `normalized-result.json` 和 `local-repairs.json`，仍须经过 expand_result 与原事务校验。

保存失败设置服务端 `resultRecovery.available`。网页“重试保存”创建新请求ID、默认复用匹配的完整结果，`usage.json` 标注 `model_calls:0` / `reused_result`；上下文失配或结果丢失停止，不偷偷调用AI。用户选择“重新读取整卷（消耗AI额度）”并确认后，使用 `retryMode:recognize` 启动新模型任务。服务端恢复状态和提示不可由网页任意改写，重试方式只能随新请求设置。已识别/人工确认的卷不能被恢复覆盖。旧任务没有可信恢复清单时不自动重放；可在对话中核验修复，不能凭同名卷猜测来源。

允许兼容：可选材料null省略；模型误放的数学skill_id/skill_name移到证据文字；最多8个现存JSON闭合符的确定性替换（不增删内容，不容许重复键）；无效题框移除并注明待定位；不一致的full降partial，保留可用题目与原声称总数。禁止制造缺失vision、页码、答案、正确率、人工确认或复练原题关系。无法安全恢复时提示具体题号/问题，保留结果供修复。网络/登录/额度/模型不兼容与保存失败分别提示，不把程序错误归咎于照片。


## 按需错题识别与整卷报告（DEC-072）

原卷默认先查看全部原图上的批改标记，短定位任务不转写全部题、不验算全部题、不查询知识库。定位出的错误及疑似错误范围裁剪后批量详细识别，仅附必要共用材料；图形题仍遵守干净题面规则。两阶段输出、来源指纹和实际 usage 分别保存。校验/保存失败复用已完成阶段，不重复读卷。复练完整批改规则不变。

没有可靠批改痕迹时，结果状态明确“尚未整卷验算”，保留原图与圈选补题入口，询问是否进行整卷验算；用户拒绝或关闭弹窗不调用模型。任何零候选结果都保持部分覆盖，不能判全对或推满分。

`POST /api/recognition/report` 请求 `{groupId,requestId,consent:true}`，需同源、令牌、档案版本。用户明确确认后创建服务拥有的 `reportTask`，与本组其他识别互斥；刷新/轮询仅查看进度，不自动提交。失败有完整输出先本地恢复；没有完整输出再次启动仍须成本确认。

整卷结果独立保存在 `pc_reports`，逐题结果经严格校验，未覆盖完整卷面仍 partial。已有人工作答、题干、判定、知识点与练习记录保持；可靠匹配后在报告动态投影人工结论，新发现的错误/待定候选追加原卷待复核。首次分析完成后 `reportData` 用于展示，重复查看不新调模型；历史 full 卷直接显示已有报告。新增题或人工修改重新投影本地统计，不自动重读全部原图。没有充分匹配证据时保留待核，不强行覆盖。

报告只在既有“全部候选人工复核完成”条件成立时推定其余预测正确题；未读取的题不参与。没有人工复核样本的空候选卷不能自动算作满分。UI 首次以确认弹窗为主要成本提示，按钮旁可显示短提示；缓存报告无需重复弹窗。
