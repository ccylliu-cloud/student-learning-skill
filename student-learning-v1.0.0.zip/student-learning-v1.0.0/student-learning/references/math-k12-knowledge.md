# 数学知识库与 Skill 接入

版本：`0.6.0-body-review`。数据随 Skill 保存于 [math-unified](knowledge/math-unified/release_manifest.json)，运行时不依赖编制者电脑上的教材，也无需回查原PDF来补充知识正文。

统一内容含585张知识卡、1,297条规则，展开为1,211个可关联考点：小初649、高中562；11项活动单独保留。原小初/高中逻辑库ID继续用于学段选择，数据源统一。

- [完整考点正文](knowledge/math-unified/assessment_points.json)：规则、适用条件、解法、例题、易错点、错因候选、前置及迁移关系、来源。
- [最多四级目录](knowledge/math-unified/hierarchy.json)：三级153个可考查点，四级1,058个可考查点。用 `is_assessable` 判断可否关联，不按固定级数猜测。
- [精简检索](knowledge/math-unified/assessment_catalog.json)与[旧ID映射](knowledge/math-unified/binding_index.json)：只返回正式名称。`resolved`直接读取对应考点；`requires_selection`返回候选，须结合题意选择；活动/专题视图不充当题目考点。

先用 `study.py search '关键词' --subject math` 找候选，再用 `kb_lookup.py --root 档案路径 --subject math --ids ID...` 读取完整规则与条件。每批最多24个，查询只读，不初始化档案。`knowledge ID` 可查看完整存储记录。新题的 `knowledgeIds` 和归因 `knowledge_point_id` 直接保存 `assessment_id`，不保存含多个子项的父分类ID。每个考点只有一个名称，别名不展示。

`rules`/兼容字段 `core_concepts_rules` 是内容块，不是额外目录层；`content_id` 为来源追踪编号，不必等于关联ID。共同背景 `shared_card_context`、跨点例题只提供上下文，必须核对各分项条件。正式错因仍用MATH_E，知识库error标签仅为诊断候选。模型必须读实际作答后判断，不用知识点名称代替归因。

[来源待核说明](knowledge/math-unified/待核来源说明.json)仍有1项：点关于直线的对称点坐标通式为经核验的编辑推导，直接教材出处尚待核，不写成教材原文事实。全库 `release_ready:false` 表示保留内部审校边界，不代表外部教师审校或学生实测；升级部署不会抹去这个状态。

已有题目采用[迁移说明](math-knowledge-migration.md)。历史停用记录仅供旧关联读取，不进入新题候选目录；任何仍无法确定的历史细分关联明确进入待核清单，不自动选子项。英语和语文不变。

小初：1–9年级新题仅选小初649个活跃考点，`MATH-K…`；前置基础可解释但不跨库强加标签。
