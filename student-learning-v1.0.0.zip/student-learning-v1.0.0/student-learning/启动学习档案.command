#!/bin/sh
set -eu
TASK_SKILL_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TASK_PYTHON="$TASK_SKILL_DIR/runtime/venv/bin/python"
if [ ! -x "$TASK_PYTHON" ]; then
  echo '请先按安装说明准备本安装的独立Python环境。'
  exit 1
fi
exec env -u PYTHONPATH -u PYTHONHOME "$TASK_PYTHON" "$TASK_SKILL_DIR/scripts/portable.py" serve --open
