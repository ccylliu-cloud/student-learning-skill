@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
if exist "runtime\venv\Scripts\python.exe" (
  "runtime\venv\Scripts\python.exe" scripts\portable.py serve --open
) else (
  echo 尚未准备本安装的独立环境。请在宿主对话中确认工作区，然后运行：
  echo py -3 scripts\setup_runtime.py --workspace "当前项目绝对目录" --install-deps
  echo 可用 --python 指定已有 Python 3.10+；不会修改系统 Python。
)
echo.
echo 服务已停止或尚未启动。
pause
